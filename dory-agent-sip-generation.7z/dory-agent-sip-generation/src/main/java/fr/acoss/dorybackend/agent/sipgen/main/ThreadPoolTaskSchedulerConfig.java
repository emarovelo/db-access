package fr.acoss.dorybackend.agent.sipgen.main;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;

/**
 * La classe permettant la création du bean ThreadPoolTaskScheduler: planificateur et gestionnaire de tâche
 */
@Configuration
@ComponentScan(basePackages = "fr.acoss.dorybackend.agent.sipgen.main", basePackageClasses = {ThreadPoolTaskSchedulerSipGen.class})
public class ThreadPoolTaskSchedulerConfig {


  @Bean
  public ThreadPoolTaskScheduler threadPoolTaskScheduler() {
    final ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
    threadPoolTaskScheduler.setPoolSize(1);
    threadPoolTaskScheduler.setThreadNamePrefix("ThreadPoolTaskScheduler");
    return threadPoolTaskScheduler;
  }

  @Bean
  public CronTrigger cronTrigger() {
    return new CronTrigger("0 * * ? * *");
  }

}
