package fr.acoss.dorybackend.agent.sipgen.main;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import fr.acoss.dorybackend.agent.sipgen.core.main.SipGenerator;

/**
 * Thread Pool TaskScheduler Sip Generator
 */
@Component
public class ThreadPoolTaskSchedulerSipGen {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(ThreadPoolTaskSchedulerSipGen.class);

  /**
   * The preferences file name.
   */
  static public final String PREFERENCES_FILENAME = "preferences.properties";

  /**
   * Service permettant de generer les SIPs
   */
  @Autowired
  private SipGenerator sipGenerator;


  /**
   * Le planificateur et gestionnaire de tâches
   */
  @Autowired
  private ThreadPoolTaskScheduler taskScheduler;

  /**
   * CronTrigger est utilisé pour planifier une tâche en fonction d’une expression cron.
   */
  @Autowired
  private CronTrigger cronTrigger;


  @PostConstruct
  public void scheduleRunnableWithCronTrigger() {
    /*
     * Nous pouvons maintenant planifier simplement la tâche générateur de SIP pour qu’elle soit exécutée par le planificateur
     */
    taskScheduler.schedule(new RunnableTask("Cron Trigger"), cronTrigger);
  }

  /**
   * L'implémentation de la tâche (générateur de SIP) qui sera exécutée periodiquement par le planificateur de tâche
   */
  class RunnableTask implements Runnable {

    private final String message;

    /**
     * Constructeur
     * 
     * @param message
     */
    public RunnableTask(final String message) {
      this.message = message;
    }

    @Override
    public void run() {
      sipGenerator.doTask();

      LOGGER.info("Exécution de la tâche: Generation de SIP " + message + " sur le thread " + Thread.currentThread().getName());
    }
  }
}
