package fr.acoss.dorybackend.agent.sipgen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
@ComponentScan({
  "fr.acoss.dorybackend.*"

})
@PropertySources({@PropertySource("classpath:application.properties")})
public class Application {


  /**
   * @param args
   */
  public static void main(final String[] args) {
    SpringApplication.run(Application.class, args);

  }

}
