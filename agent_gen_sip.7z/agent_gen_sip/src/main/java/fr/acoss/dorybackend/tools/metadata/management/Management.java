package fr.acoss.dorybackend.tools.metadata.management;

import java.util.LinkedHashMap;

import fr.acoss.dorybackend.tools.metadata.namedtype.ComplexListMetadataKind;
import fr.acoss.dorybackend.tools.metadata.namedtype.ComplexListMetadataMap;
import fr.acoss.dorybackend.tools.metadata.namedtype.ComplexListType;

/**
 * The Class Management.
 * <p>
 * Class for SEDA element Management.
 * <p>
 * A ArchiveUnit metadata.
 * <p>
 * Standard quote: "Métadonnées de gestion applicables à l’ArchiveUnit concernée
 * et à ses héritiers"
 */
public class Management extends ComplexListType {

  /**
   * Init metadata map.
   */
  @ComplexListMetadataMap(isExpandable = true)
  static final public LinkedHashMap<String, ComplexListMetadataKind> metadataMap;
  static {
    metadataMap = new LinkedHashMap<>();
    metadataMap.put("StorageRule", new ComplexListMetadataKind(StorageRule.class, false));
    metadataMap.put("AppraisalRule", new ComplexListMetadataKind(AppraisalRule.class, false));
  }

  /**
   * Instantiates a new Management.
   */
  public Management() {
    super("Management");
  }

}
