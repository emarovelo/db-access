package fr.acoss.dorybackend.tools.utils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.acoss.dorybackend.tools.metadata.namedtype.DataType;

/**
 * Classe utilitaire pour la gestion des métadonnées
 */
public class MetadataHelper {


  /**
   * Metadonnées Utité Archivistique Vitam
   */
  public static enum MetadataVitam {


    METADATA_DescriptionLevel("DescriptionLevel", false),

    METADATA_Title("Title", false),

    // Acoss extensions
    METADATA_CodeRND("CodeRND", true),

    METADATA_IdImageISO("IdImageISO", false),

    METADATA_NumberOfFiles("NumberOfFiles", false),

    METADATA_TypeImageISO("TypeImageISO", false),

    METADATA_CreationDate("CreationDate", false),

    METADATA_IdArchivage("IdArchivage", true);

    private String realeName;

    private final boolean isMandatory;

    MetadataVitam(final String realName, final boolean isMandatory) {
      realeName = realName;
      this.isMandatory = isMandatory;
    }

    /**
     * @return the realeName
     */
    public String getRealeName() {
      return realeName;
    }

    /**
     * @param realeName
     *          the realeName to set
     */
    public void setRealeName(final String realeName) {
      this.realeName = realeName;
    }

    /**
     * @return the isMandatory
     */
    public boolean isMandatory() {
      return isMandatory;
    }

    /**
     * @return
     */
    public static Stream<MetadataVitam> stream() {
      return Stream.of(MetadataVitam.values());
    }

    /**
     * L'enum correspondant au nom spécifié
     * 
     * @param name
     * @return null ou l'enum demandée
     */
    public static Optional<MetadataVitam> findByName(final String name) {
      return name != null ? MetadataVitam.stream().filter(meta -> meta.getRealeName().equalsIgnoreCase(name)).findFirst() : Optional.empty();
    }

    /**
     * Permet de retourner toutes les métadonnées obligatoires
     * 
     * @return
     */
    public static List<MetadataVitam> getAllMandatoryMetadata() {
      return MetadataVitam.stream().filter(meta -> meta.isMandatory()).collect(Collectors.toList());
    }

  }

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(MetadataHelper.class);


  /**
   * @param lstMetadata
   *          : liste des métadonnées
   */

  /**
   * Permet de verifier la présence des différents métadonnées obligatoires.
   * 
   * @param lstMetadata
   *          : liste des métadonnées
   * @return la liste des métadonnées obligatoires non trouvées
   */
  public static List<String> ckeckIfAllMandatoryMetaArePresent(final Map<String, DataType> lstMetadata) {
    // on va stocker dans cette liste les métadonnées obligatoires non trouvée
    final List<String> lstMetadataNotFound = new ArrayList<>();

    if (lstMetadata != null && !lstMetadata.isEmpty()) {
      // on recupère la liste des métadonnées obligatoires
      final List<MetadataVitam> lstManadoryMetadata = MetadataVitam.getAllMandatoryMetadata();

      DataType tmpDataType;
      String tmpDataTypeVelue;
      boolean isMandatoryMetadataFound = false;

      // pour chaque métadonnées obligaoire, on boucle sur la listes des métadonnées à verifier et qui est passée en parametre de cette fonction
      for (final MetadataVitam metadataVitam : lstManadoryMetadata) {
        isMandatoryMetadataFound = false;

        // on verifie si la métadonnée obligatoire est présente dans la liste des métadonnées à verifier
        tmpDataType = lstMetadata.get(metadataVitam.getRealeName());

        if (tmpDataType != null) {
          isMandatoryMetadataFound = true;
          tmpDataTypeVelue = tmpDataType.getValue();

          if (StringUtils.isBlank(tmpDataTypeVelue)) {
            isMandatoryMetadataFound = false;
          }

        }
        if (!isMandatoryMetadataFound) {
          // la metadata n'a pas été trouvée
          lstMetadataNotFound.add(metadataVitam.getRealeName());
        }
      }
    }

    return lstMetadataNotFound;
  }

  /**
   * Methode permettant de transformer les données d'un fichier JSON (qui represente les métadonnées du document)
   * en une map Map<DataTypeName,DataType>
   * 
   * @param jsonFile
   *          File
   * @return List<DataType>
   */
  public static Map<String, DataType> metadataFromJsonFileToLstDataType(final File jsonFile) {
    final Map<String, DataType> lstDataType = new HashMap<>();

    // JSON parser object to parse read file
    final JSONParser jsonParser = new JSONParser();

    try (Reader targetReader = new FileReader(jsonFile)) {
      // Read JSON file
      final Object obj = jsonParser.parse(targetReader);

      final JSONArray dataTypeList = (JSONArray) obj;

      DataType tmpDataType;
      String dataTypeName;

      // on boucle sur les donnees retrouvees
      // On les transforme en objet DataType
      // puis on les ajoute dans la Map<String, DataType>
      for (final Object datatype : dataTypeList) {
        tmpDataType = parseDataTypeObject((JSONObject) datatype);

        if (tmpDataType != null) {
          dataTypeName = tmpDataType.getName();

          if (StringUtils.isNotEmpty(dataTypeName)) {
            // la clé est en lowerCase
            dataTypeName = dataTypeName.trim();
            // recuperation du vrai nom de la metadata
            final Optional<MetadataVitam> optMetadataVitam = MetadataVitam.findByName(dataTypeName);

            if (optMetadataVitam.isPresent()) {
              dataTypeName = optMetadataVitam.get().getRealeName();
              tmpDataType.setName(dataTypeName);
              lstDataType.put(dataTypeName, tmpDataType);
            }
          }
        }
      }
    }
    catch (final IOException | ParseException e) {
      MetadataHelper.LOGGER.error("Erreur lors de la recuperation des métadonnées", e);
    }

    return lstDataType;
  }

  /**
   * Permet de retourner la liste des métadonnées d'un document.
   * 
   * @param parentPath:
   *          le repertoire contenant le fichier (métadonnées + document). Le document et le fichier contenant les métadonées ont le même nom. Seules leur extention qui sont différentes
   * @param metadataFileName:
   *          le nom du fichier contenant les métadonnées
   * @return
   */
  public static Map<String, DataType> getDataTypes(final Path parentDocument) {
    MetadataHelper.LOGGER.info("Recupération des métadonnées associés au fichier :" + parentDocument);
    Map<String, DataType> lstDataType = new HashMap<>();

    if (parentDocument != null) {

      // suppression de l'extention sur le nom du fichier
      final String metadataFileName = FileHelper.removeFileExtension(parentDocument.toString());

      /*
       * construction du path du fichier. Les fichiers contenant les métadonnées ont tous le format .json
       * Pour conaitre le fichier metadonnées liées à un document, il faut juste changer l'extention du document en .json
       */
      final Path metadataPath = Paths.get(metadataFileName + ".json");

      if (StringUtils.isNotEmpty(metadataFileName) && Files.exists(metadataPath)) {
        final File metadataFile = metadataPath.toFile();
        lstDataType = MetadataHelper.metadataFromJsonFileToLstDataType(metadataFile);
      } else {
        MetadataHelper.LOGGER.info("Impossible de recupérer les meétadonnées du document car le fichier suivant est introuvable: " + metadataFileName
                                   + ".json");
      }

    }
    return lstDataType;
  }

  /**
   * Permet de construire un objet DataType à partir d'un JSONObject
   * 
   * @param jsonDataType
   *          JSONObject
   * @return DataType
   */
  private static DataType parseDataTypeObject(final JSONObject jsonDataType) {
    final DataType dataType = new DataType();
    String nodeName = null;

    // get the name of the current node
    for (final Object key : jsonDataType.keySet()) {
      nodeName = (String) key;
      break;
    }

    final JSONObject dataTypeObject = (JSONObject) jsonDataType.get(nodeName);

    if (dataTypeObject != null) {
      // name
      final String name = (String) dataTypeObject.get("name");
      dataType.setName(name);

      // type
      final String type = (String) dataTypeObject.get("type");
      dataType.setType(type);

      // value
      final String value = (String) dataTypeObject.get("value");
      dataType.setValue(value);
    }

    return dataType;
  }

}
