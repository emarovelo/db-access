package fr.acoss.dorybackend.modele.dto;

import java.time.OffsetDateTime;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * LogDocumenType
 */
public class LogDocumenType   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("message")
  private String message = null;

  @JsonProperty("dateCreation")
  private OffsetDateTime dateCreation = null;

  @JsonProperty("dateMaj")
  private OffsetDateTime dateMaj = null;

  public LogDocumenType id(final Long id) {
    this.id = id;
    return this;
  }

  /**
   * Indentifiant du log
   * @return id
   **/
  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  public LogDocumenType message(final String message) {
    this.message = message;
    return this;
  }

  /**
   * message du log
   * @return message
   **/
  public String getMessage() {
    return message;
  }

  public void setMessage(final String message) {
    this.message = message;
  }

  public LogDocumenType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }

  /**
   * Date de creation
   * @return dateCreation
   **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public LogDocumenType dateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
    return this;
  }

  /**
   * Date de derniere mise a jour (obligatoire pour les services de maj)
   * @return dateMaj
   **/
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final LogDocumenType logDocumenType = (LogDocumenType) o;
    return Objects.equals(id, logDocumenType.id) &&
        Objects.equals(message, logDocumenType.message) &&
        Objects.equals(dateCreation, logDocumenType.dateCreation) &&
        Objects.equals(dateMaj, logDocumenType.dateMaj);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, message, dateCreation, dateMaj);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class LogDocumenType {\n");

    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    dateMaj: ").append(toIndentedString(dateMaj)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

