package fr.acoss.dorybackend.database.access.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import fr.acoss.dorybackend.core.layer.metier.DocumentMetier;
import fr.acoss.dorybackend.core.layer.metier.LotVersementMetier;
import fr.acoss.dorybackend.core.layer.metier.SipMetier;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheDocumentType;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheLotVersementType;
import fr.acoss.dorybackend.database.access.DatabaseAccess;
import fr.acoss.dorybackend.metier.FileStorage;
import fr.acoss.dorybackend.metier.SipGenerator;
import fr.acoss.dorybackend.modele.dto.DocumentDto;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.DocumentType;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.LogDocumentType;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.LotVersementType;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.StatutDocumentType;
import fr.acoss.dorybackend.tools.utils.FileHelper;
import fr.acoss.dorybackend.tools.utils.MetadataHelper;

/**
 * Classe permettant la gestion des données depuis la base de donnée
 */
@Service
public class DatabaseAccessImpl implements DatabaseAccess {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(DatabaseAccessImpl.class);

  /**
   * The allow pattern String from preferences.properties file.
   */
  // @Value("${importContext.disk.allowPatternList}")
  // private String allowPatternsString;

  @Value("${sip.taille.documents:200}")
  private int nbMaxDocsDansSip;

  /**
   * The allow patterns.
   */
  // @Value("#{'${importContext.disk.allowPatternList}'.split('\\s*\n\\s*')")
  private List<Pattern> allowPatterns;

  @Value("${importContext.disk.allowPatternList}")
  private String allowPatternsString;

  @Autowired
  private DocumentMetier documentMetier;

  @Autowired
  private LotVersementMetier lotVersementMetier;

  @Autowired
  private SipMetier sipMetier;

  @Autowired
  private FileStorage fileStorage;

  @Autowired
  private SipGenerator sipGenerator;

  // public static final StatutDocumentType statutDocumentType = new ;

  @PostConstruct
  private void postConstruct() {

    if (allowPatterns == null) {
      allowPatterns = new ArrayList<>();
    }

    if (allowPatternsString == null) {
      allowPatternsString = Strings.EMPTY;
    }
    Arrays.asList(allowPatternsString.split("\\s*\n\\s*")).forEach(patternString -> allowPatterns.add(Pattern.compile(patternString)));
  }

  @Override
  public void genererSip() {

    /*
     * Etape 1:
     * récupération des lots de versement dont le statut est HORODATE
     * Etape 2:
     * Pour chaque lot de versement, on va aller chercher les documents à l'etat HORODATE associés
     * Etape 3:
     * On split les documents HORODATE d'un lot de versement HORODATE.
     * Pour chaque lot de document, on verifie s'il peut être intégrer dans un SIP
     * Un document peut être intégrer dans un SIP s'il réuni toutes les conditions suivantes:
     * - le document est présent physiquement
     * - le fichier json correspondant au document est présent physiquement
     * - les métadonnées obligatoires liées au document sont présentes: CODE RND, UUID
     * Si un document réuni les conditions citées ci-dessus:
     * - on change son statut en CREATION_SIP (ce changement de statut est tracé dans la table dédiée à cela)
     * - on l'ajout dans la liste des documents pour être intégrer dans le SIP à créer
     * Si un document ne réuni pas les conditions citées ci-dessus:
     * - on change son statut en ERREUR (ce changement de statut est tracé dans la table dédiée à cela)
     * - On trace aussi dans la table de log
     * Etape 4:
     * On envoie la liste des documents favorable à être intégrer dans un SIP au service de generation de SIP.
     * Le nom ainsi que le repertoire où on va mettre le SIP (fichier .zip) sont aussi envoyés au service de generation de SIP
     */

    final StatutDocumentType statutDocumentTypeErreur = new StatutDocumentType();
    statutDocumentTypeErreur.code("ERREUR");

    final StatutDocumentType statutDocumentTypeCreationSip = new StatutDocumentType();
    statutDocumentTypeCreationSip.code("CREATION_SIP");


    /*--------------------- ETAPE 1 ---------------------------
     * Récupération des lots de versement dont les critères sont les suivants:
     *  - 
     * 
     * */
    final CriteresRechercheLotVersementType criteresRechercheLotVersementType = new CriteresRechercheLotVersementType();
    // la taille max par page est de 100 éléments
    criteresRechercheLotVersementType.setSize(100);

    // recuperer seulement les lots de versement dont le statut est HORODATE
    // TODO
    criteresRechercheLotVersementType.setCodeStatutLotVersement("HORODATE");

    List<LotVersementType> lstLotVersement = new ArrayList<>();

    // on commence par la page 0
    Integer currentPage = new Integer(0);

    // on boucle tant qu'il y a encore de donnée
    while (currentPage > -1) {
      criteresRechercheLotVersementType.setCurrentPage(currentPage);

      // appel de la couche DadabaseAcces pour recuperer les lots de versement
      lstLotVersement = lotVersementMetier.rechercherLots(criteresRechercheLotVersementType);

      // on va compter le nombre de documents associés à chaque lot de versement
      // documentMetier.c

      // ########################## ETAPE 2 ##########################
      for (final LotVersementType lotVersementType : lstLotVersement) {
        if (lotVersementType != null && lotVersementType.getId() != null) {

          // generation des SIP pour le let de versement
          generateDocsFromLotVersement(lotVersementType.getId(), statutDocumentTypeErreur, statutDocumentTypeCreationSip);
        }
      }

      // si la taille de la liste est inférieure à celle qu'on a voulu alors, il ne reste plus de données à recupérer
      if (lstLotVersement != null && lstLotVersement.size() < 100) {
        currentPage = -1;
      } else {
        currentPage++;
      }
    }
  }

  private void generateDocsFromLotVersement(final Long idLotVersement, final StatutDocumentType statutDocumentTypeErreur,
                                            final StatutDocumentType statutDocumentTypeCreationSip) {
    final CriteresRechercheDocumentType criteres = new CriteresRechercheDocumentType();
    /*
     * Critères de recherche:
     * - document appartenant au lot de versement spécifié
     * - document dont le statut est HORODATE
     * - document qui n'est pas encore dans un SIP
     */
    criteres.setIdLotVersement(idLotVersement);
    criteres.setCodeStatutDocument("HORODATE");
    criteres.setSearchForIdSipNull(true);

    // Chaque page doit avoir au max nbMaxDocsDansSip éléments
    // ce qui correspond à la taille max de document dans un SIP
    Integer currentPage = 0;

    criteres.setSize(nbMaxDocsDansSip);

    // Permet de stocker la liste de document dont le statut est HORODATE d'un lot
    List<DocumentType> lstDocumentType = new ArrayList<>();

    // Permet de stocker la liste de document à intégrer dans un SIP
    List<DocumentDto> lstDocumentAIntegrerDansSIP;

    // Permet de stocker la liste de document réellement intégré dans un SIP
    List<DocumentDto> lstDocumentReellementIntegreDansSIP;

    // on boucle tant qu'il y a encore de donnée à recuperer.
    while (currentPage > -1) {
      criteres.setCurrentPage(currentPage);

      // on recupère une partie des documents horodatés du lot
      lstDocumentType = documentMetier.rechercherDocuments(criteres);

      /*
       * On verifie s'il reste encore de documents à récupérés:
       * si la taille de la liste est inférieure à celle qu'on a voulu alors, il ne reste plus de données à recupérer
       */
      if (lstDocumentType != null && lstDocumentType.size() < nbMaxDocsDansSip) {
        currentPage = -1;
      } else {
        currentPage++;
      }

      // on élimine les documents non conforme
      lstDocumentAIntegrerDansSIP = checkAndPrepareDocsBeforeSipGen(lstDocumentType, statutDocumentTypeErreur, statutDocumentTypeCreationSip);

      // ajout gestion des exceptions
      // ajouter un parametre qui represente le nom du sip
      // ajouter un parametre qui represente le path de sorti du SIP
      lstDocumentReellementIntegreDansSIP = sipGenerator.generateSip(lstDocumentAIntegrerDansSIP);


      if (lstDocumentAIntegrerDansSIP != null && lstDocumentReellementIntegreDansSIP != null) {

        // on va recuperer la liste de documents qui n'ont pas été intégrés dans le SIP
        lstDocumentAIntegrerDansSIP.removeAll(lstDocumentReellementIntegreDansSIP);

        // on va mettre le statut des documents non intégrés dans le sip en erreur
        final List<String> lstIdDocumentToErreur = new ArrayList<>();
        lstDocumentAIntegrerDansSIP.forEach(doc -> lstIdDocumentToErreur.add(doc.getUuid()));

        documentMetier.changerStatutDocsTo(lstIdDocumentToErreur, statutDocumentTypeErreur);
        // for (final DocumentDto documentDto : lstDocumentAIntegrerDansSIP) {
        // // mettre le statut à erreur
        // // documentMetier.
        // }

        /*
         * Création du SIP en BDD
         */
        sipMetier.creerSip("nom", "urlDepot", null, toLstDocumentType(lstDocumentReellementIntegreDansSIP));
        // if (lstDocumentReellementIntegreDansSIP != null && !lstDocumentReellementIntegreDansSIP.isEmpty()) {
        //
        // for (final DocumentDto documentDto : lstDocumentReellementIntegreDansSIP) {
        //
        // }
        // }
      }

    }

  }


  /**
   * @param lstDocumentType
   * @return
   */
  private List<DocumentDto> checkAndPrepareDocsBeforeSipGen(final List<DocumentType> lstDocumentType, final StatutDocumentType statutDocumentTypeErreur,
                                                            final StatutDocumentType statutDocumentTypeCreationSip) {
    final List<DocumentDto> lstDocumentDtoResult = new ArrayList<>();

    if (lstDocumentType != null) {

      final List<DocumentDto> lstDocumentDtoToCheck = toLstDocumentDto(lstDocumentType);
      List<LogDocumentType> lstLogDocument;
      final List<String> lstIdArchivageDocErreur = new ArrayList<>();
      final List<String> lstIdArchivageDocCreationSip = new ArrayList<>();


      for (final DocumentDto documentDto : lstDocumentDtoToCheck) {
        lstLogDocument = checkDataDocument(documentDto);

        // ici, si la liste lstLogDocument est vide, alors le document est intégrable dans un sip
        if (lstLogDocument.isEmpty()) {
          documentDto.setArchiveUnitProfile("APP-"
              + documentDto.getLstMetadonnees().get(MetadataHelper.MetadataVitam.METADATA_CodeRND.getRealeName()).getValue());
          lstDocumentDtoResult.add(documentDto);

          // ici mettre le statut du document en CREATION_SIP
          lstIdArchivageDocCreationSip.add(documentDto.getUuid());

        } else {
          // ici mettre le statut du document en ERREUR
          lstIdArchivageDocErreur.add(documentDto.getUuid());
        }

        LogDocumentType tmpLogDocument;
        // on verifie la présence de la donnée hash Scelle
        if (documentDto.getHashScelle() == null || documentDto.getHashScelle().trim().isEmpty()) {
          DatabaseAccessImpl.LOGGER.info("Integration d'un document dans un SIP dont la donnée Hash Scelle n'est pas présente: " + documentDto);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("Integration d'un document dans un SIP dont la donnée Hash Scelle n'est pas présente: " + documentDto);
          lstLogDocument.add(tmpLogDocument);
        }

        // on verifie la présence de la donnée horodate
        if (documentDto.getBlocHorodate() == null || documentDto.getBlocHorodate().trim().isEmpty()) {
          DatabaseAccessImpl.LOGGER.info("Integration d'un document dans un SIP dont la donnée Horodatage n'est pas présente: " + documentDto);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("Integration d'un document dans un SIP dont la donnée Horodatage n'est pas présente: " + documentDto);
          lstLogDocument.add(tmpLogDocument);
        }

        // MAJ BDD
        documentMetier.addLogsToDocument(documentDto.getUuid(), lstLogDocument);

      }

      documentMetier.changerStatutDocsTo(lstIdArchivageDocErreur, statutDocumentTypeErreur);

      documentMetier.changerStatutDocsTo(lstIdArchivageDocCreationSip, statutDocumentTypeCreationSip);
    }

    return lstDocumentDtoResult;
  }

  private List<LogDocumentType> checkDataDocument(final DocumentDto documentDto) {
    final List<LogDocumentType> lstLogDocument = new ArrayList<>();
    if (documentDto != null) {

      LogDocumentType tmpLogDocument;
      final String documentFileName = documentDto.getPathDocument();

      // vérifier la presence de l'UUID
      if (documentDto.getUuid() == null || documentDto.getUuid().trim().isEmpty()) {
        DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car la donnée UUID n'est pas présente: " + documentDto);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car la donnée UUID n'est pas présente: " + documentDto);
        lstLogDocument.add(tmpLogDocument);
      }

      // on vérifie si le document est vraiment présent physiquement
      if (documentFileName == null || !fileStorage.exists(documentFileName)) {
        DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le document n'est pas présent physiquement: "
            + documentFileName);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le document n'est pas présent physiquement: "
            + documentFileName);
        lstLogDocument.add(tmpLogDocument);
      } else {
        // on vérifie si le fichier des métadonnées est présent physiquement
        String pathMetadataFile = FileHelper.removeFileExtension(documentFileName);
        pathMetadataFile += ".json";

        if (!fileStorage.exists(pathMetadataFile)) {
          DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le fichier des métadonnées n'est pas présent physiquement: "
              + pathMetadataFile);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le fichier des métadonnées n'est pas présent physiquement: "
              + pathMetadataFile);
          lstLogDocument.add(tmpLogDocument);
        } else {
          // vérification des métadonnées obligatoires

          final Path documentPath = Paths.get(documentFileName);
          documentDto.setLstMetadonnees(MetadataHelper.getDataTypes(documentPath));

          // on verifie la presence des métadonnées obligatoire
          final List<String> lstMandatoryMetadataNotFound = MetadataHelper.ckeckIfAllMandatoryMetaArePresent(documentDto.getLstMetadonnees());

          /*
           * On boucle sur la liste des métadonnées obligatoires non trouvée.
           * Puis on les loggue en base
           */
          if (lstMandatoryMetadataNotFound != null && !lstMandatoryMetadataNotFound.isEmpty()) {
            for (final String metadataName : lstMandatoryMetadataNotFound) {
              DatabaseAccessImpl.LOGGER.info("La métadonnée obligatoire " + metadataName + " n'est pas renseignée.");
              tmpLogDocument = new LogDocumentType();
              tmpLogDocument.setMessage("La métadonnée obligatoire " + metadataName + " n'est pas renseignée.");
              lstLogDocument.add(tmpLogDocument);
            }
          }
        }
      }

      // on vérifie si le format du document fait parti de la liste des formats de document autorisé
      if (documentFileName != null && !mustBeAllowed(documentFileName.substring(documentFileName.lastIndexOf(File.separator) + 1))) {
        DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le format du fichier ne fait par parti de la liste des formats autorisés: "
            + allowPatterns);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le format du fichier ne fait parti de la liste des formats autorisés: "
            + allowPatterns);
        lstLogDocument.add(tmpLogDocument);
      }

      // on vérifier si le document n'est pas un répertoire
      if (documentFileName != null) {
        final Path documentPath = Paths.get(documentFileName);
        if (Files.isDirectory(documentPath, java.nio.file.LinkOption.NOFOLLOW_LINKS)) {

          DatabaseAccessImpl.LOGGER.info("impossible d'intégrer ce document car c'est un répertoire: "
              + documentFileName);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("impossible d'intégrer ce document car c'est un répertoire: "
              + documentFileName);
          lstLogDocument.add(tmpLogDocument);

        }

      }

    }

    return lstLogDocument;
  }

  private List<DocumentDto> toLstDocumentDto(final List<DocumentType> lstDocumentType) {
    final List<DocumentDto> lstDocumentDto = new ArrayList<>();

    if (lstDocumentType != null) {
      DocumentDto tmpDocumentDto;
      for (final DocumentType documentType : lstDocumentType) {
        tmpDocumentDto = new DocumentDto();
        tmpDocumentDto.setBlocHorodate(documentType.getBlocHorodate());
        tmpDocumentDto.setHashScelle(documentType.getHashScelle());
        tmpDocumentDto.setPathDocument(documentType.getPathDocument());
        tmpDocumentDto.setUuid(documentType.getUuid());
        tmpDocumentDto.setId(documentType.getId());

        lstDocumentDto.add(tmpDocumentDto);

      }
    }

    return lstDocumentDto;
  }

  private List<DocumentType> toLstDocumentType(final List<DocumentDto> lstDocumentDto) {

    final List<DocumentType> lstDocumentType = new ArrayList<>();

    if (lstDocumentDto != null) {
      DocumentType documentType;

      for (final DocumentDto documentDto : lstDocumentDto) {
        documentType = new DocumentType();
        documentType.setBlocHorodate(documentDto.getBlocHorodate());
        documentType.setHashNonScelle(documentDto.getHashScelle());
        documentType.setPathDocument(documentDto.getPathDocument());
        documentType.setUuid(documentDto.getUuid());
        documentType.setId(documentDto.getId());

        lstDocumentType.add(documentType);

      }
    }
    return lstDocumentType;
  }

  /**
   * Test if a file name is compliant to one of allow patterns.
   *
   * @param fileName
   *          the file name string to test
   */
  private boolean mustBeAllowed(final String fileName) {
    boolean doMatch = false;
    for (final Pattern p : allowPatterns) {
      if (p.matcher(fileName).matches()) {
        doMatch = true;
        break;
      }
    }
    return doMatch;
  }
}
