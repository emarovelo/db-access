package fr.acoss.dorybackend.tools.metadata.namedtype;

public class ComplexListMetadataKind {
  /**
   * The c.
   */
  public Class<?> metadataClass;

  /**
   * The many.
   */
  public boolean many;

  /**
   * Instantiates a new metadata item.
   *
   * @param metadataClass the metadata class
   * @param many          the many
   */
  public ComplexListMetadataKind(final Class<?> metadataClass, final boolean many) {
    this.metadataClass = metadataClass;
    this.many = many;
  }
}
