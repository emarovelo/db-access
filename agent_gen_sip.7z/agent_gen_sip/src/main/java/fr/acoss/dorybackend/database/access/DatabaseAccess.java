package fr.acoss.dorybackend.database.access;

public interface DatabaseAccess {

  void genererSip();
}
