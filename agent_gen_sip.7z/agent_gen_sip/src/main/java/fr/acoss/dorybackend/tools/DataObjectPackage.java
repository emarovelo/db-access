package fr.acoss.dorybackend.tools;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.acoss.dorybackend.tools.content.Content;
import fr.acoss.dorybackend.tools.utils.SEDALibException;
import fr.acoss.dorybackend.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class DataObjectPackage
 * <p>
 * Class for the SEDA SIP DataObjectPackage. It contains all the elements
 * in tree structure ArchiveUnits and DataObjects.
 * <p>
 * It has also a specific exportMetadataList field which define the list
 * of descriptive metadata elements kept in export to XML manifest or csv metadata file. This is used to restrict
 *  to the set of metadata that an archiving system can handle. This export filter do not apply to any other XML
 *  or csv format function (for example toString, toSedaXMLFragments, toCsvList...).
 */
public class DataObjectPackage {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(DataObjectPackage.class);
  // SEDA elements
  /**
   * The map of all the ArchiveUnits by inDataPackageObjectId.
   */
  private HashMap<String, ArchiveUnit> auInDataObjectPackageIdMap;

  /**
   * The map of all the DataObjectGroups by inDataPackageObjectId.
   */
  private HashMap<String, DataObjectGroup> dogInDataObjectPackageIdMap;

  /**
   * The map of all the BinaryDataObjects by inDataPackageObjectId.
   */
  private HashMap<String, BinaryDataObject> bdoInDataObjectPackageIdMap;

  /**
   * The management metadata xml data.
   */
  private String managementMetadataXmlData;

  /**
   * The "ghost" root ArchiveUnit containing as childs the ArchiveUnits at root
   * level.
   */
  private ArchiveUnit ghostRootAu;

  // Inner objects

  /**
   * The kept metadata list for export.
   */
  private List<String> exportMetadataList;

  /**
   * The counter used to generate inArchiveTransferIds.
   */
  private int idCounter;

  /**
   * The counter used to generate RefID in XML.
   */
  private int refIdCounter;

  /**
   * The counter of in/out events used for progress log.
   */
  private int inOutCounter;

  /**
   * The map used to accumulate the touched ArchiveUnits or DataObjects
   * inArchiveTransferIds during a treatment. It's useful to touch only one time
   * all ArchiveUnits or DataObjects in the graph, or to count the time they are
   * touched.
   */
  private final HashMap<String, Integer> touchedInDataObjectPackageIdMap;




  // Constructors

  /**
   * Instantiates a new archive transfer. Used for json deserialization.
   */
  public DataObjectPackage() {
    auInDataObjectPackageIdMap = new HashMap<>();
    dogInDataObjectPackageIdMap = new HashMap<>();

    bdoInDataObjectPackageIdMap = new HashMap<>();
    ghostRootAu = new ArchiveUnit();
    final Content c = new Content();
    try {
      c.addNewMetadata("Title", "GhostRootAu");
    } catch (final SEDALibException ignored) {
    }
    ghostRootAu.setDataObjectPackage(this);

    exportMetadataList=null;
    resetIdCounter();
    resetRefIdCounter();
    resetInOutCounter();
    touchedInDataObjectPackageIdMap = new HashMap<>();
  }

  // Methods

  /**
   * Checks if is inDataPackageObjectId already known in this DataObjectPackage.
   *
   * @param inDataPackageObjectId the id in DataObjectPackage
   * @return true, if the id is used in DataObjectPackage
   */
  private boolean isInDataObjectPackageIdUsed(final String inDataPackageObjectId) {
    if (auInDataObjectPackageIdMap.containsKey(inDataPackageObjectId)) {
      return true;
    }
    if (dogInDataObjectPackageIdMap.containsKey(inDataPackageObjectId)) {
      return true;
    }
    if (bdoInDataObjectPackageIdMap.containsKey(inDataPackageObjectId)) {
      return true;
    }
    return false;
  }

  /**
   * Adds an ArchiveUnit as an DataObjectPackage element, defining a uniqID if not
   * already defined (null).
   * <p>
   * This is only useful when you create an ArchiveUnit without giving an outer
   * DataObjectPackage in constructor, for example during json deserialization.
   *
   * @param au the ArchiveUnit
   * @throws SEDALibException when the ArchiveUnit has a defined UniqId which is
   *                          already in the DataObjectPackage
   */
  public void addArchiveUnit(final ArchiveUnit au) throws SEDALibException {
    if (au.inDataPackageObjectId == null) {
      au.inDataPackageObjectId = getNextInDataObjectPackageID();
    }
    if (isInDataObjectPackageIdUsed(au.inDataPackageObjectId)) {
      throw new SEDALibException(
                                 "Deux objets ne peuvent avoir la même référence [" + au.inDataPackageObjectId + "]");
    }
    auInDataObjectPackageIdMap.put(au.inDataPackageObjectId, au);
    au.setDataObjectPackage(this);
  }

  /**
   * Adds a data object group as an ArchiveTransfer element, defining a uniqID if
   * not already defined (null).
   * <p>
   * This is only useful when you create a DataObjectGroup without giving an outer
   * DataObjectPackage in constructor, for example during json deserialization.
   *
   * @param dog the DataObjectGroup
   * @throws SEDALibException when the DataObjectGroup has a defined UniqId which
   *                          is already in the DataObjectPackage
   */
  public void addDataObjectGroup(final DataObjectGroup dog) throws SEDALibException {
    if (dog.inDataPackageObjectId == null) {
      dog.inDataPackageObjectId = getNextInDataObjectPackageID();
    }
    if (isInDataObjectPackageIdUsed(dog.inDataPackageObjectId)) {
      throw new SEDALibException(
                                 "Deux objets ne peuvent avoir la même référence [" + dog.inDataPackageObjectId + "]");
    }
    dogInDataObjectPackageIdMap.put(dog.inDataPackageObjectId, dog);
    dog.setDataObjectPackage(this);
  }

  /**
   * Adds a binary data object as an ArchiveTransfer element, defining a uniqID if
   * not already defined (null).
   * <p>
   * This is only useful when you create a BinaryDataObject without giving an
   * outer DataObjectPackage in constructor, for example during json
   * deserialization.
   *
   * @param bdo the BinaryDataObject
   * @throws SEDALibException when the BinaryDataObject has a defined UniqId which
   *                          is already in the DataObjectPackage
   */
  public void addBinaryDataObject(final BinaryDataObject bdo) throws SEDALibException {
    if (bdo.inDataPackageObjectId == null) {
      bdo.inDataPackageObjectId = getNextInDataObjectPackageID();
    }
    if (isInDataObjectPackageIdUsed(bdo.inDataPackageObjectId)) {
      throw new SEDALibException(
                                 "Deux objets ne peuvent avoir la même référence [" + bdo.inDataPackageObjectId + "]");
    }
    bdoInDataObjectPackageIdMap.put(bdo.inDataPackageObjectId, bdo);
    bdo.setDataObjectPackage(this);
  }

  /**
   * Reset the touched ArchiveUnit or DataObject inDataPackageObjectId Map, the
   * Map is then empty and ready to use.
   */
  public void resetTouchedInDataObjectPackageIdMap() {
    touchedInDataObjectPackageIdMap.clear();
  }

  /**
   * Checks if the ArchiveUnit or DataObject with given inDataPackageObjectId has
   * been touched.
   *
   * @param inDataObjectPackageId the id in DataObjectPackage
   * @return true, if has been touched
   */
  public boolean isTouchedInDataObjectPackageId(final String inDataObjectPackageId) {
    return touchedInDataObjectPackageIdMap.containsKey(inDataObjectPackageId);
  }

  /**
   * Adds the ArchiveUnit or DataObject inDataPackageObjectId in the touched map,
   * with a count value set to 1.
   * <p>
   * This is used when going through all the ArchiveUnits of the graph so has to
   * be sure to treat them only one time, for example when exporting to XML or
   * when searching for the list of roots after an import from xml
   *
   * @param inDataObjectPackageId the id in DataObjectPackage
   */
  public void addTouchedInDataObjectPackageId(final String inDataObjectPackageId) {
    touchedInDataObjectPackageIdMap.put(inDataObjectPackageId, 1);
  }

  /**
   * Increment the ArchiveUnit or DataObject inDataPackageObjectId value in the
   * touched map, if touched for the first time the count value is set to 1.
   *
   * @param inDataObjectPackageId the id in DataObjectPackage
   */
  public void incTouchedInDataObjectPackageId(final String inDataObjectPackageId) {
    final Integer value = touchedInDataObjectPackageIdMap.get(inDataObjectPackageId);
    if (value == null) {
      touchedInDataObjectPackageIdMap.put(inDataObjectPackageId, 1);
    } else {
      touchedInDataObjectPackageIdMap.put(inDataObjectPackageId, value + 1);
    }
  }

  /**
   * Gets the count value for a touched id in DataObjectPackage.
   *
   * @param inDataObjectPackageId the id in DataObjectPackage
   * @return the count value for the touched id in DataObjectPackage, or null if
   * not touched
   */
  public Integer getTouchedInDataObjectPackageId(final String inDataObjectPackageId) {
    return touchedInDataObjectPackageIdMap.get(inDataObjectPackageId);
  }

  /**
   * Gets the ArchiveUnits count.
   *
   * @return the ArchiveUnits count
   */
  public int getArchiveUnitCount() {
    return auInDataObjectPackageIdMap.size();
  }

  /**
   * Gets the DataObjectGroups count.
   *
   * @return the DataObjectGroups count
   */
  public int getDataObjectGroupCount() {
    return dogInDataObjectPackageIdMap.size();
  }

  /**
   * Gets the BinaryDataObjects count.
   *
   * @return the BinaryDataObjects count
   */
  public int getBinaryDataObjectCount() {
    return bdoInDataObjectPackageIdMap.size();
  }

  /**
   * Gets the BinaryDataObjects total size in bytes.
   *
   * @return the BinaryDataObjects total size
   */
  public long getDataObjectsTotalSize() {
    long result = 0;
    for (final Map.Entry<String, BinaryDataObject> pair : bdoInDataObjectPackageIdMap.entrySet()) {
      result += pair.getValue().size;
    }
    return result;
  }

  /**
   * Gets the ArchiveUnit by inDataObjectPackageId.
   *
   * @param inDataObjectPackageId the ArchiveUnit id in DataObjectPackage
   * @return the ArchiveUnit or null if not found
   */
  public ArchiveUnit getArchiveUnitById(final String inDataObjectPackageId) {
    return auInDataObjectPackageIdMap.get(inDataObjectPackageId);
  }

  /**
   * Gets the DataObjectGroup by inDataObjectPackageId.
   *
   * @param inDataObjectPackageId the DataObjectGroup id in DataObjectPackage
   * @return the DataObjectGroup or null if not found
   */
  public DataObjectGroup getDataObjectGroupById(final String inDataObjectPackageId) {
    return dogInDataObjectPackageIdMap.get(inDataObjectPackageId);
  }

  /**
   * Gets the DataObject (group, binary or physical) by inDataPackageObjectId.
   *
   * @param inDataObjectPackageId the DataObject id in DataObjectPackage
   * @return the DataObject or null if not found
   */
  public DataObject getDataObjectById(final String inDataObjectPackageId) {
    DataObject dataObject;

    dataObject = dogInDataObjectPackageIdMap.get(inDataObjectPackageId);
    if (dataObject != null) {
      return dataObject;
    }
    dataObject = bdoInDataObjectPackageIdMap.get(inDataObjectPackageId);
    if (dataObject != null) {
      return dataObject;
    }

    return null;
  }

  /**
   * Gets the next ID to use in DataObjectPackage.
   * <p>
   * It uses the idCounter to generate an ID in the "IDxxx" form. It tests if this
   * ID is already used, and if so increment idCounter till the ID is uniq.
   *
   * @return the next ID in DataObjectPackage
   */
  public String getNextInDataObjectPackageID() {
    String id = "ID" + Integer.toString(idCounter++);
    while (auInDataObjectPackageIdMap.containsKey(id) || dogInDataObjectPackageIdMap.containsKey(id)
        || bdoInDataObjectPackageIdMap.containsKey(id)) {
      id = "ID" + Integer.toString(idCounter++);
    }
    return id;
  }

  /**
   * Gets the next RefID to use in ArchiveTransfer.
   * <p>
   * It uses the refIdCounter to generate an ID in the "RefIDxxx" form.
   *
   * @return the next RefID in ArchiveTransfer
   */
  public String getNextRefID() {
    return "RefID" + Integer.toString(refIdCounter++);
  }

  /**
   * Reset refID counter to value 1.
   * <p>
   * This counter is used to generate the RefIDs in the manifest during export
   */
  public void resetRefIdCounter() {
    refIdCounter = 1;
  }

  /**
   * Reset ID counter to value 10.
   * <p>
   * This counter is used to generate the IDs in the manifest during import. It
   * begins at 10 to prevent an id collision with those used in headers of SEDA
   * messages
   */
  public void resetIdCounter() {
    idCounter = 10;
  }

  /**
   * Human readable file size, using the best scale (B, kB, MB, GB or TB) in bytes
   *
   * @param size the size
   * @return the size in human readable string format
   */
  private static String readableFileSize(final long size) {
    if (size <= 0) {
      return "0";
    }
    final String[] units = new String[]{"B", "kB", "MB", "GB", "TB"};
    final int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
    return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
  }

  /**
   * Gets the summary description of DataObjectPackage.
   * <p>
   * It list the number of ArchiveUnits, DataObjectGroup, BinaryDataObject (with
   * size in bytes) and PhysicalDatObject
   *
   * @return the description String
   */
  public String getDescription() {
    String result;

    result = "  - " + getArchiveUnitCount() + " ArchiveUnit(s)\n  - " + getDataObjectGroupCount()
    + " DataObjectGroup(s)\n  - " + getBinaryDataObjectCount() + " BinaryDataObject(s) ("
        + readableFileSize(getDataObjectsTotalSize()) + ")";

    return result;
  }

  /**
   * Sets the all references by objects.
   * <p>
   * In {@link DataObjectRefList} and {@link ArchiveUnitRefList} the objects can
   * be kept by reference or (exclusive) by Id. When it's needed to work on Ids,
   * and to change them, this function permit to be sure that all lists use the
   * object reference form.
   */
  private void setAllReferencesByObjects() {
    // These calls guaranty that the references lists use objects as references and
    // not inArchiveTransferID, as the ids will be changed during the process
    for (final Map.Entry<String, ArchiveUnit> pair : getAuInDataObjectPackageIdMap().entrySet()) {
      pair.getValue().getChildrenAuList().getArchiveUnitList();
      pair.getValue().getDataObjectRefList().getDataObjectList();
    }
    getGhostRootAu().getChildrenAuList().getArchiveUnitList();
  }


  /**
   * Regenerate ArchiveUnit id and maintain an ordered list of DataObjectGroup to
   * reindex.
   *
   * @param archiveUnit                the archive unit
   * @param orderedDataObjectGroupList the ordered data object group list
   */
  private void regenerateArchiveUnitId(final ArchiveUnit archiveUnit, final List<DataObjectGroup> orderedDataObjectGroupList) {
    if (archiveUnit.inDataPackageObjectId == null) {
      final DataObjectGroup dog = archiveUnit.getDataObjectRefList().getNormalizedDataObjectGroup();
      if (dog != null) {
        orderedDataObjectGroupList.add(dog);
      }
      try {
        addArchiveUnit(archiveUnit);
      } catch (final SEDALibException e) {
        // impossible
      }
      for (final ArchiveUnit childAu : archiveUnit.getChildrenAuList().getArchiveUnitList()) {
        regenerateArchiveUnitId(childAu, orderedDataObjectGroupList);
      }
    }
  }

  /**
   * Regenerate DataObjectGroup id and all contained DataObjects.
   *
   * @param dataObjectGroup the DataObjectGroup
   */
  private void regenerateDataObjectGroup(final DataObjectGroup dataObjectGroup) {
    if (dataObjectGroup.inDataPackageObjectId == null) {
      try {
        addDataObjectGroup(dataObjectGroup);
      } catch (final SEDALibException e) {
        // impossible
      }
      for (final BinaryDataObject bdo : dataObjectGroup.getBinaryDataObjectList()) {
        bdo.inDataPackageObjectId = null;
        try {
          addBinaryDataObject(bdo);
        } catch (final SEDALibException e) {
          // impossible
        }
      }
    }
  }

  /**
   * Removes the archive unit and data object group ids before regeneration.
   */
  private void removeArchiveUnitAndDataObjectGroupId() {
    for (final Map.Entry<String, ArchiveUnit> pair : auInDataObjectPackageIdMap.entrySet()) {
      pair.getValue().setInDataObjectPackageId(null);
    }
    for (final Map.Entry<String, DataObjectGroup> pair : dogInDataObjectPackageIdMap.entrySet()) {
      pair.getValue().setInDataObjectPackageId(null);
    }
  }

  /**
   * Regenerate all IDs of ArchiveUnits, DataObjectGroup, BinaryDataObject and
   * PhysicalDataObject in incremented IDxxx form.
   */
  public void regenerateContinuousIds() {
    setAllReferencesByObjects();
    removeArchiveUnitAndDataObjectGroupId();
    resetIdCounter();

    auInDataObjectPackageIdMap = new HashMap<>();
    dogInDataObjectPackageIdMap = new HashMap<>();
    bdoInDataObjectPackageIdMap = new HashMap<>();

    resetInOutCounter();
    final List<DataObjectGroup> orderedDataObjectGroupList = new ArrayList<>(
        dogInDataObjectPackageIdMap.size());
    for (final ArchiveUnit root : ghostRootAu.getChildrenAuList().getArchiveUnitList()) {
      regenerateArchiveUnitId(root, orderedDataObjectGroupList);
    }

    resetInOutCounter();
    for (final DataObjectGroup zdo : orderedDataObjectGroupList) {
      regenerateDataObjectGroup(zdo);
    }
  }

  // SEDA XML exporter

  /**
   * The ID comparator to sort elements by inDataPackageObjectId.
   */
  private static Comparator<String> IDComparator = (ID1, ID2) -> {
    int num1, num2;
    if (ID1.toLowerCase().startsWith("id") && ID2.toLowerCase().startsWith("id")) {
      try {
        num1 = Integer.parseInt(ID1.substring(2));
        num2 = Integer.parseInt(ID2.substring(2));
        return num1 - num2;
      } catch (final Exception e) {
        // forget it
      }
    }
    return ID1.compareTo(ID2);
  };

  /**
   * Export data object package, DataObjects part, of SEDA DataObjectPackage XML.
   *
   * @param xmlWriter             the SEDAXMLStreamWriter generating the SEDA manifest
   * @throws InterruptedException if export process is interrupted
   * @throws SEDALibException     if the XML can't be written
   */
  public void exportDataObjectPackageObjects(final SEDAXMLStreamWriter xmlWriter)
      throws InterruptedException, SEDALibException {
    try {
      xmlWriter.writeStartElement("DataObjectPackage");
      DataObjectGroup dog;
      BinaryDataObject bdo;
      String[] tempArray;

      resetTouchedInDataObjectPackageIdMap();
      // first write all DataObjectGroup
      final Set<String> dogSet = dogInDataObjectPackageIdMap.keySet();
      tempArray = dogSet.toArray(new String[0]);
      Arrays.sort(tempArray);
      for (final String s : tempArray) {
        dog = dogInDataObjectPackageIdMap.get(s);
        dog.toSedaXml(xmlWriter);
        for (final BinaryDataObject b : dog.getBinaryDataObjectList()) {
          addTouchedInDataObjectPackageId(b.inDataPackageObjectId);
        }
      }

      // then all alone BinaryDataObject
      final Set<String> bdoSet = bdoInDataObjectPackageIdMap.keySet();
      tempArray = bdoSet.toArray(new String[0]);
      Arrays.sort(tempArray);
      for (final String s : tempArray) {
        bdo = bdoInDataObjectPackageIdMap.get(s);
        if (!isTouchedInDataObjectPackageId(bdo.inDataPackageObjectId)) {
          bdo.toSedaXml(xmlWriter);
        }
      }

    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML des métadonnées des DataObjects\n->" + e.getMessage());
    }
    DataObjectPackage.LOGGER.info(Integer.toString(getNextInOutCounter()) + " DataObject (métadonnées) exportées");

  }

  /**
   * Export data object package, ArchiveUnits and global metadata part, of SEDA
   * ArchiveTransfer XML.
   *
   * @param xmlWriter             the SEDAXMLStreamWriter generating the SEDA manifest
   * @param imbricateFlag         indicates if the manifest ArchiveUnits are to be
   *                              exported in imbricate mode (true) or in flat mode
   *                              (false)
   * @throws SEDALibException     if the XML can't be written
   * @throws InterruptedException if export process is interrupted
   */
  public void exportDataObjectPackageMetadata(final SEDAXMLStreamWriter xmlWriter, final boolean imbricateFlag) throws SEDALibException, InterruptedException {
    try {
      resetTouchedInDataObjectPackageIdMap();
      xmlWriter.writeStartElement("DescriptiveMetadata");
      if (!imbricateFlag) {
        final Set<String> auSet = auInDataObjectPackageIdMap.keySet();
        final String[] tempArray = auSet.toArray(new String[0]);
        Arrays.sort(tempArray, IDComparator);
        for (final String s : tempArray) {
          auInDataObjectPackageIdMap.get(s).toSedaXml(xmlWriter, false);
        }
      } else {
        final List<String> roots = ghostRootAu.getChildrenAuList().getInDataObjectPackageIdList();
        if (roots != null) {
          final String[] tempArray = roots.toArray(new String[0]);
          Arrays.sort(tempArray, IDComparator);
          for (final String s : tempArray) {
            auInDataObjectPackageIdMap.get(s).toSedaXml(xmlWriter, true);
          }
        }
      }
      xmlWriter.writeEndElement();
      xmlWriter.writeRawXMLBlockIfNotEmpty(managementMetadataXmlData);
      xmlWriter.writeEndElement();
    } catch (XMLStreamException | SEDALibException e) {
      throw new SEDALibException("Erreur d'écriture XML des métadonnées des ArchiveUnits\n->" + e.getMessage());
    }

    DataObjectPackage.LOGGER.info(Integer.toString(getNextInOutCounter()) +
        " ArchiveUnit exportés");

  }

  /**
   * Export the whole structure in XML SEDA Manifest.
   *
   * @param xmlWriter             the SEDAXMLStreamWriter generating the SEDA manifest
   * @param imbricateFlag         indicates if the manifest ArchiveUnits are to be
   *                              exported in imbricate mode (true) or in flat mode
   *                              (false)
   * @throws SEDALibException     if the XML can't be written
   * @throws InterruptedException if export process is interrupted
   */
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter, final boolean imbricateFlag)
      throws SEDALibException, InterruptedException {
    resetRefIdCounter();
    resetInOutCounter();
    exportDataObjectPackageObjects(xmlWriter);
    resetInOutCounter();
    exportDataObjectPackageMetadata(xmlWriter, imbricateFlag);
  }

  // Getters and setters

  /**
   * Gets the BinaryDataObject in inDataPackageObjectId map.
   *
   * @return the BinaryDataObject in inDataPackageObjectId map
   */
  public HashMap<String, BinaryDataObject> getBdoInDataObjectPackageIdMap() {
    return bdoInDataObjectPackageIdMap;
  }

  /**
   * Sets the BinaryDataObject in inDataPackageObjectId map.
   *
   * @param bdoInDataObjectPackageIdMap the BinaryDataObject in
   *                                    inDataPackageObjectId map
   */
  public void setBdoInDataObjectPackageIdMap(final HashMap<String, BinaryDataObject> bdoInDataObjectPackageIdMap) {
    this.bdoInDataObjectPackageIdMap = bdoInDataObjectPackageIdMap;
  }

  /**
   * Gets the DataObjectGroup in inDataPackageObjectId map.
   *
   * @return the DataObjectGroup in inDataPackageObjectId map
   */
  public HashMap<String, DataObjectGroup> getDogInDataObjectPackageIdMap() {
    return dogInDataObjectPackageIdMap;
  }

  /**
   * Sets the DataObjectGroup in inDataPackageObjectId map.
   *
   * @param dogInDataObjectPackageIdMap the DataObjectGroup in
   *                                    inDataPackageObjectId map
   */
  public void setDogInDataObjectPackageIdMap(final HashMap<String, DataObjectGroup> dogInDataObjectPackageIdMap) {
    this.dogInDataObjectPackageIdMap = dogInDataObjectPackageIdMap;
  }

  /**
   * Gets the ArchiveUnit in inDataPackageObjectId map.
   *
   * @return the ArchiveUnit in inDataPackageObjectId map
   */
  public HashMap<String, ArchiveUnit> getAuInDataObjectPackageIdMap() {
    return auInDataObjectPackageIdMap;
  }

  /**
   * Sets the ArchiveUnit in inDataPackageObjectId map.
   *
   * @param auInDataObjectPackageIdMap the ArchiveUnit in inDataPackageObjectId
   *                                   map
   */
  public void setAuInDataObjectPackageIdMap(final HashMap<String, ArchiveUnit> auInDataObjectPackageIdMap) {
    this.auInDataObjectPackageIdMap = auInDataObjectPackageIdMap;
  }

  /**
   * Gets the "ghost" root ArchiveUnit, it's children being the root ArchiveUnits
   * of the ArchiveTransfer.
   *
   * @return the root ArchiveUnits list
   */
  public ArchiveUnit getGhostRootAu() {
    return ghostRootAu;
  }

  /**
   * Adds the root au.
   *
   * @param au the au
   */
  public void addRootAu(final ArchiveUnit au) {
    ghostRootAu.getChildrenAuList().add(au);
  }

  /**
   * Removes the root au.
   *
   * @param au the au
   */
  public void removeRootAu(final ArchiveUnit au) {
    ghostRootAu.getChildrenAuList().getArchiveUnitList().remove(au);
  }

  /**
   * Sets the root au list.
   *
   * @param ghostRootAu the new ghost root au
   */
  public void setGhostRootAu(final ArchiveUnit ghostRootAu) {
    this.ghostRootAu = ghostRootAu;
  }

  /**
   * Gets the next special counter increment.
   *
   * @return the next special counter
   */
  public int getNextInOutCounter() {
    return inOutCounter++;
  }

  /**
   * Reset special counter.
   */
  public void resetInOutCounter() {
    inOutCounter = 0;
  }

  /**
   * Gets the in out counter.
   *
   * @return the in out counter
   */
  public int getInOutCounter() {
    return inOutCounter;
  }

  /**
   * Gets the ManagementMetadata xml data.
   *
   * @return the ManagementMetadata xml data
   */
  public String getManagementMetadataXmlData() {
    return managementMetadataXmlData;
  }

  /**
   * Sets the ManagementMetadata xml data.
   *
   * @param managementMetadataXmlData the new ManagementMetadata xml data
   */
  public void setManagementMetadataXmlData(final String managementMetadataXmlData) {
    this.managementMetadataXmlData = managementMetadataXmlData;
  }

  /**
   * Gets export metadata list.
   *
   * @return the export metadata list
   */
  public List<String> getExportMetadataList() {
    return exportMetadataList;
  }

  /**
   * Sets export metadata list.
   *
   * @param exportMetadataList the export metadata list
   */
  public void setExportMetadataList(final List<String> exportMetadataList) {
    this.exportMetadataList = exportMetadataList;
  }
}