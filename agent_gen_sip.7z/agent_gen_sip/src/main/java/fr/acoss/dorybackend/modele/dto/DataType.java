package fr.acoss.dorybackend.modele.dto;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DataType
 */
public class DataType   {
  @JsonProperty("name")
  private String name = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("value")
  private String value = null;

  public DataType name(final String name) {
    this.name = name;
    return this;
  }

  /**
   * Le nom du metadata
   * @return name
   **/
  public String getName() {
    return name;
  }

  public void setName(final String name) {
    this.name = name;
  }

  public DataType type(final String type) {
    this.type = type;
    return this;
  }

  /**
   * Le type du metadata
   * @return type
   **/
  public String getType() {
    return type;
  }

  public void setType(final String type) {
    this.type = type;
  }

  public DataType value(final String value) {
    this.value = value;
    return this;
  }

  /**
   * La valeur du metadata
   * @return value
   **/
  public String getValue() {
    return value;
  }

  public void setValue(final String value) {
    this.value = value;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final DataType dataType = (DataType) o;
    return Objects.equals(name, dataType.name) &&
        Objects.equals(type, dataType.type) &&
        Objects.equals(value, dataType.value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, type, value);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class DataType {\n");

    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

