package fr.acoss.dorybackend.tools.importer;



import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.acoss.dorybackend.modele.dto.DocumentDto;
import fr.acoss.dorybackend.tools.ArchiveUnit;
import fr.acoss.dorybackend.tools.BinaryDataObject;
import fr.acoss.dorybackend.tools.DataObjectGroup;
import fr.acoss.dorybackend.tools.DataObjectPackage;
import fr.acoss.dorybackend.tools.metadata.ArchiveUnitProfile;
import fr.acoss.dorybackend.tools.metadata.management.AppraisalRule;
import fr.acoss.dorybackend.tools.metadata.management.Management;
import fr.acoss.dorybackend.tools.metadata.namedtype.DataType;
import fr.acoss.dorybackend.tools.utils.MetadataHelper;
import fr.acoss.dorybackend.tools.utils.SEDALibException;

/**
 * The Class DiskToDataObjectPackageImporter.
 * <p>
 * Class for on disk hierarchy import in DataObjectPackage object.
 * <p>
 * The general principles are:
 * <ul>
 * <li>the directory imported contains all the directories and files that
 * represent one root ArchiveUnit in the ArchiveTransfer</li>
 * <li>each sub-directory in the hierarchy represent an ArchiveUnit</li>
 * <li>each file represent an ArchiveUnit containing a BinaryDataObject for the
 * file itself, being the BinaryMaster_1 and with format identification
 * compliant to PRONOM register</li>
 * <li>the title of ArchiveUnit is the directory/file name, if no other metadata
 * is defined</li>
 * </ul>
 * For example, if you import this disk hierarchy:
 * <p>
 * RootDir
 * <p>
 * |---TestDir1
 * <p>
 * |---NodeFile1.1.jpg
 * <p>
 * |---NodeFile2.pdf
 * <p>
 * the ArchiveTransfer will contain:
 * <p>
 * ArchiveUnit (Title="TestDir1")
 * <p>
 * |---ArchiveUnit (Title="NodeFile1.1.jpg")
 * <p>
 * ---|---BinaryDataObject(DataObjectVersion="BinaryMaster_1"
 * FileName="NodeFile1.1.jpg"...)
 * <p>
 * |--- ArchiveUnit (Title="NodeFile2.pdf")
 * <p>
 * ---|---BinaryDataObject(DataObjectVersion="BinaryMaster_1"
 * FileName="NodeFile2.pdf"...)
 * <p>
 * but for adding metadata definitions, link to ArchiveUnits and
 * DataobjectGroups... there are two models of description that's better to use
 * exclusively.
 * <p>
 * Model V1-Historical GenerateurSEDA model
 * <ul>
 * <li>in a directory when there is a ArchiveUnitContent.xml file, it's used to
 * define the generated ArchiveUnit metadata described in the Content XML
 * element</li>
 * <li>in a directory when there is a ArchiveUnitManagement.xml file, it's used
 * to define the generated ArchiveUnit metadata described in the Management XML
 * element</li>
 * <li>in a directory when a file begins by __USAGE_VERSION_, USAGE being any
 * String and VERSION any integer, this file is directly considered to be a
 * BinaryDataObject with USAGE_VERSION as DataObjectVersion and then is not used
 * for generating an ArchiveUnit</li>
 * <li>a windows shortcut to a target existing directory or file, which is in
 * the imported hierarchy, is considered as a reference to the ArchiveUnit
 * represented by the target</li>
 * </ul>
 * <p>
 * Model V2-Extended model
 * <ul>
 * <li>in a directory when there is a __ArchiveUnitMetadata.xml file, it's used to
 * define the generated ArchiveUnit metadata. At root level you can have one or
 * more XML elements that define metadata but not structure that is to say
 * &gt;ArchiveUnitProfile&lt;, &gt;Management&lt; or &gt;Content&lt;</li>
 * <li>in a directory when a file is named like
 * __USAGE_VERSION__PhysicalDataObjectMetadata.xml, USAGE being any String and
 * VERSION any integer, this file is directly considered to be a
 * PhysicalDataObject metadata with USAGE_VERSION as DataObjectVersion and then
 * is not used for generating an ArchiveUnit</li>
 * <li>in a directory when a file is named like
 * __USAGE_VERSION__BinaryDataObjectMetadata.xml, USAGE being any String and
 * VERSION any integer, this file is directly considered to define the
 * BinaryDataObject with USAGE_VERSION as DataObjectVersion metadata. It needs
 * to also have a content file named __USAGE_VERSION__XXXX. The filename in
 * metadata file is overriding the derivation from file name to define FileName
 * in BinaryDataObject</li>
 * <li>a directory named like "##xxxxx##" is used to explicitly define a
 * DataObjectGroup, so that a reference can be made</li>
 * <li>a windows shortcut or windows/linux symbolic link to a target existing
 * directory or file, which is in the imported hierarchy, is considered as a
 * reference to the ArchiveUnit or the DataObjectGroup represented by the
 * target</li>
 * </ul>
 * There are also two options in any model, that can be added to the constructors:
 * <ul>
 * <li>noLinkFlag: determine if the windows shortcut or windows/linux symbolic link are ignored (default false)</li>
 * <li>extractTitleFromFileNameFunction: define the function used to extract Title from file name (default simple copy)</li>
 * </ul>
 */
public class DiskToDataObjectPackageImporter {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(DiskToDataObjectPackageImporter.class);

  /**
   * The list of DocumentDto to integrate in the Sip
   */
  private List<DocumentDto> documentsToSip;

  /**
   * The on disk root paths.
   */
  private final List<Path> onDiskRootPaths;

  /**
   * The archive transfer.
   */
  private DataObjectPackage dataObjectPackage;

  /**
   * The allow patterns.
   */
  private final List<Pattern> allowPatterns;

  /**
   * The ArchiveUnit path string map, used to manage symbolic and shortcut links.
   */
  private final HashMap<String, ArchiveUnit> auPathStringMap;

  /**
   * The DataObjectGroup path string map, used to manage symbolic and shortcut
   * links.
   */
  private final HashMap<String, DataObjectGroup> dogPathStringMap;


  /**
   * The model version, V1 or V2.
   */
  private final int modelVersion;

  /**
   * The inCounter, used for ArchiveUnit process count.
   */
  private int inCounter;

  /**
   * The start and end instants, for duration computation.
   */
  private Instant start, end;


  /**
   * The function used to extract Title from filename.
   */
  private Function<String, String> extractTitleFromFileNameFunction;

  /**
   * The simpleCopy function used by default to extract Title from file name.
   */
  static public Function<String, String> simpleCopy = s -> s;


  private DiskToDataObjectPackageImporter(final Function<String, String> extractTitleFromFileNameFunction) {
    onDiskRootPaths = new ArrayList<>();
    dataObjectPackage = null;
    allowPatterns = new ArrayList<>();
    // isWindows = System.getProperty("os.name").toLowerCase().contains("win");
    auPathStringMap = new HashMap<>();
    dogPathStringMap = new HashMap<>();
    modelVersion = 0;
    // this.noLinkFlag = noLinkFlag;
    if (extractTitleFromFileNameFunction != null) {
      this.extractTitleFromFileNameFunction = extractTitleFromFileNameFunction;
    } else {
      this.extractTitleFromFileNameFunction = simpleCopy;
    }

    inCounter = 0;
  }

  /**
   * Instantiates a new DataObjectPackage importer from a list of documents.
   * <p>
   * It will consider each document in this list as a root
   * ArchiveUnit or the management metadata file
   * <p>
   * It will take into account two options:
   * <ul>
   * <li>noLinkFlag: determine if the windows shortcut or windows/linux symbolic link are ignored</li>
   * <li>extractTitleFromFileNameFunction: define the function used to extract Title from file name (if null simpleCopy is used)</li>
   * </ul>
   *
   * @param paths
   *          the paths
   * @param extractTitleFromFileNameFunction
   *          the extract title from file name function
   */
  public DiskToDataObjectPackageImporter(final List<DocumentDto> documents, final Function<String, String> extractTitleFromFileNameFunction) {
    this(extractTitleFromFileNameFunction);
    documentsToSip = documents;
    dataObjectPackage = new DataObjectPackage();
  }

  /**
   * Adds the allow pattern.
   *
   * @param patternString
   *          the pattern string
   */
  public void addAllowPattern(final String patternString) {
    allowPatterns.add(Pattern.compile(patternString));
  }


  /**
   * Test if a file name is compliant to one of allow patterns.
   *
   * @param fileName
   *          the file name string to test
   */
  private boolean mustBeAllowed(final String fileName) {
    boolean doMatch = false;
    for (final Pattern p : allowPatterns) {
      if (p.matcher(fileName).matches()) {
        doMatch = true;
        break;
      }
    }
    return doMatch;
  }

  /**
   * Process the document by calling methods convenient for the path of document nature, and then
   * generate the represented ArchiveUnit.
   * 
   * @param document
   * @return the ArchiveUnit generated from path
   * @throws SEDALibException
   *           any import exception
   * @throws InterruptedException
   *           if import process is interrupted
   */
  private ArchiveUnit processPath(final DocumentDto document) throws SEDALibException, InterruptedException {
    ArchiveUnit au = null;
    final Path documentPath = Paths.get(document.getPathDocument());

    // test if already analyzed
    au = getArchiveUnit(documentPath);
    if (au != null) {
      return au;
    }

    if (document != null && document.getPathDocument() != null) {

      if (Files.isDirectory(documentPath, java.nio.file.LinkOption.NOFOLLOW_LINKS)) {
        // au = processDirectory(document);
      } else {
        au = processFile(document, true);
      }
    }

    return au;
  }

  /**
   * Process the file.
   * <p>
   * When a file is imported
   * <p>
   * - an ArchiveUnit is created with the name of the file as title and empty
   * description
   * <p>
   * - the file is defined as BinaryMaster_1 BinaryDataObject
   *
   * @param document
   * @param testIgnorePatterns
   * @return the archive unit
   * @throws SEDALibException
   *           any import exception
   * @throws InterruptedException
   *           if import process is interrupted
   */
  private ArchiveUnit processFile(final DocumentDto document, final boolean testIgnorePatterns) throws SEDALibException, InterruptedException {
    String fileName;
    ArchiveUnit au = null;
    DataObjectGroup dog;
    BinaryDataObject bdo;

    if (document != null) {
      fileName = document.getPathDocument();
      final Path documentPath = Paths.get(fileName);

      // test if already analyzed
      au = getArchiveUnit(documentPath);
      if (au != null) {
        return au;
      }

      // verify not to be ignored
      if (testIgnorePatterns && !mustBeAllowed(fileName.substring(fileName.lastIndexOf(File.separator) + 1))) {
        return null;
      }

      inCounter++;

      DiskToDataObjectPackageImporter.LOGGER.info("ArchiveUnits importées");

      dog = new DataObjectGroup(dataObjectPackage, documentPath);
      bdo = new BinaryDataObject(dataObjectPackage, documentPath, null, "BinaryMaster_1");
      bdo.documentDto = document;
      au = new ArchiveUnit(dataObjectPackage);
      au.setOnDiskPath(documentPath);
      au.setDefaultContent(extractTitleFromFileNameFunction.apply(fileName), "Item");

      // Add additional content from metadata file here
      final Map<String, DataType> lstMetadataFromFile = document.getLstMetadonnees(); // MetadataHelper.getDataTypes(documentPath);
      final Iterator<Map.Entry<String, DataType>> iterator = lstMetadataFromFile.entrySet().iterator();
      DataType dataType;
      String dataTypeName;
      String codeRNDMetadata = null;
      while (iterator.hasNext()) {
        final Map.Entry<String, DataType> entry = iterator.next();
        dataTypeName = entry.getKey();
        dataType = entry.getValue();

        if (dataType != null && StringUtils.isNotEmpty(dataTypeName)) {
          au.getContent().addNewMetadata(dataTypeName, dataType.getValue());

          // récupération de la valeur du CODE RND
          if (MetadataHelper.MetadataVitam.METADATA_CodeRND.getRealeName().equals(dataTypeName)) {
            codeRNDMetadata = dataType.getValue();
          }
        }
      }

      // add Management & ArchiveUnitProfile
      if (StringUtils.isNotEmpty(document.getArchiveUnitProfile())) {
        final String archiveUniteProfile = document.getArchiveUnitProfile();
        final Management management = new Management();
        final AppraisalRule appraisalRule = new AppraisalRule(archiveUniteProfile, LocalDate.now(), "Destroy");
        management.addMetadata(appraisalRule);
        au.setManagement(management);

        final ArchiveUnitProfile archiveUnitProfile = new ArchiveUnitProfile();
        archiveUnitProfile.setValue(archiveUniteProfile);
        au.setArchiveUnitProfile(archiveUnitProfile);
      }

      auPathStringMap.put(au.getOnDiskPath().toString(), au);
      dogPathStringMap.put(dog.getOnDiskPath().toString(), dog);
      dog.addDataObject(bdo);
      au.addDataObjectById(dog.getInDataObjectPackageId());

    }
    return au;
  }

  /**
   * Do import the disk structure to DataObjectPackage. It will import from a
   * from a list of documents:
   * <ul>
   * <li>ManagementMetadata XML element at the end of DataObjectPackage from the
   * __ManagementMetadata.xml file</li>
   * <li>each root ArchiveUnit from a document, and recursively all the
   * DataObjectPackage structure (see {@link DiskToDataObjectPackageImporter} for
   * details)</li>
   * </ul>
   *
   * @throws SEDALibException
   *           any import exception
   * @throws InterruptedException
   *           if export process is interrupted
   */
  public void doImport() throws SEDALibException, InterruptedException {
    Iterator<DocumentDto> documentIterator;
    DocumentDto nextDocument = null;
    ArchiveUnit au;
    start = Instant.now();

    try (Stream<DocumentDto> sp = documentsToSip.stream()) {
      documentIterator = sp.iterator();
      while (documentIterator.hasNext()) {
        nextDocument = documentIterator.next();

        au = processPath(nextDocument);
        if (au != null) {
          dataObjectPackage.addRootAu(au);
        }
      }
      DiskToDataObjectPackageImporter.LOGGER.info(Integer.toString(inCounter) + " ArchiveUnits importées");

    } catch (final SEDALibException e) {
      throw new SEDALibException("Impossible d'importer les ressources du répertoire ["
          + nextDocument.toString() + "]\n->" + e.getMessage());
    }

    inCounter = 0;
    for (final Map.Entry<String, BinaryDataObject> pair : dataObjectPackage.getBdoInDataObjectPackageIdMap().entrySet()) {
      if (pair.getValue().fileInfo.lastModified == null) {
        pair.getValue().extractTechnicalElements();
      }
      inCounter++;
      DiskToDataObjectPackageImporter.LOGGER.info(Integer.toString(inCounter) + " BinaryDataObject analysés");
    }
    DiskToDataObjectPackageImporter.LOGGER.info(Integer.toString(inCounter) + " BinaryDataObject analysés");

    end = Instant.now();
  }

  /**
   * Gets the DataObjectPackage.
   *
   * @return the DataObjectPackage
   */
  public DataObjectPackage getDataObjectPackage() {
    return dataObjectPackage;
  }

  /**
   * Gets the model version.
   *
   * @return the model version
   */
  public int getModelVersion() {
    return modelVersion;
  }

  /**
   * Gets the archive unit.
   *
   * @param path the path
   * @return the archive unit
   */
  private ArchiveUnit getArchiveUnit(final Path path) {
    return auPathStringMap.get(path.toAbsolutePath().normalize().toString());
  }


  /**
   * Gets the summary of the import process.
   *
   * @return the summary
   */
  public String getSummary() {
    String result = "Import d'une structure d'archives depuis une hiérarchie sur disque\n";
    result += "en [";
    boolean first = true;
    for (final Path path : onDiskRootPaths) {
      if (first) {
        first = false;
      } else {
        result += ",\n";
      }
      result += path.toString();
    }
    result += "]\n";
    result += dataObjectPackage.getDescription() + "\n";
    switch (getModelVersion()) {
    case 0:
      result += "encodé selon un modèle neutre de la structure\n";
      break;
    case 1:
      result += "encodé selon un modèle V1 de la structure\n";
      break;
    case 2:
      result += "encodé selon un modèle V2 de la structure\n";
      break;
    case 3:
      result += "encodé selon un modèle hybride V1/V2 de la structure\n";
      break;
    }
    if (start != null && end != null) {
      result += "chargé en " + Duration.between(start, end).toString().substring(2) + "\n";
    }
    return result;
  }
}
