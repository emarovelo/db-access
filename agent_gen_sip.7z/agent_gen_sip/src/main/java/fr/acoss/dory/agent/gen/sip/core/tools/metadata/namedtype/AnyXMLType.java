package fr.acoss.dory.agent.gen.sip.core.tools.metadata.namedtype;


import java.util.LinkedHashMap;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLEventReader;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class AnyXMLType.
 * <p>
 * For abstract not determined SEDA metadata, take all the xml block
 */
public class AnyXMLType extends NamedTypeMetadata {

  /** The raw xml. */
  private String rawXml;

  /**
   * Instantiates a new XML block type.
   */
  public AnyXMLType() {
    this(null, (String) null);
  }

  /**
   * Instantiates a new XML block type.
   *
   * @param elementName the XML element name
   */
  public AnyXMLType(final String elementName) {
    this(elementName, (String) null);
  }

  /**
   * Instantiates a new XML block type.
   *
   * @param elementName the XML element name
   * @param rawXml       the raw Xml String
   */
  public AnyXMLType(final String elementName, final String rawXml) {
    super(elementName);
    this.rawXml = rawXml;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toSedaXml(fr.gouv.vitam.
   * tools.sedalib.xml.SEDAXMLStreamWriter)
   */
  @Override
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeRawXMLBlockIfNotEmpty(rawXml);
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML dans un élément de type AnyXMLType ["+getXmlElementName()+"]\n->" + e.getMessage());
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toCsvList()
   */
  @Override
  public LinkedHashMap<String, String> toCsvList() throws SEDALibException {
    final LinkedHashMap<String, String> result = new LinkedHashMap<>();
    result.put("",rawXml);
    return result;
  }

  /**
   * Import the metadata content in XML expected form from the SEDA Manifest.
   *
   * @param xmlReader       the SEDAXMLEventReader reading the SEDA manifest
   * @return true, if it finds something convenient, false if not
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not respected, for example
   */
  public boolean fillFromSedaXml(final SEDAXMLEventReader xmlReader) throws SEDALibException {
    try {
      final XMLEvent event = xmlReader.peekUsefullEvent();
      elementName = event.asStartElement().getName().getLocalPart();
      rawXml = xmlReader.nextBlockAsStringIfNamed(elementName);
    } catch (XMLStreamException | IllegalArgumentException e) {
      throw new SEDALibException(
                                 "Erreur de lecture XML dans un élément de type AnyXMLType\n->" + e.getMessage());
    }
    return true;
  }

  // Getters and setters

  /**
   * Gets raw xml.
   *
   * @return the raw xml
   */
  public String getRawXml() {
    return rawXml;
  }

  /**
   * Sets raw xml.
   *
   * @param rawXml the raw xml
   */
  public void setRawXml(final String rawXml) {
    this.rawXml = rawXml;
  }
}
