package fr.acoss.dory.agent.sip.generator.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.agent.sip.generator.model.persistance.Document;
import fr.acoss.dory.agent.sip.generator.model.persistance.StatutDocument;

/**
 * Interface DAO de gestion de document
 */
public interface DocumentDao extends JpaRepository<Document, Long> {

  /**
   * Recherche d'un document par son uuid
   * 
   * @param uuid
   *          String
   * @return Optional<Document>
   */
  Optional<Document> findByUuid(String uuid);

  /**
   * Recherche de document par son statut
   * 
   * @param statut
   *          Statut
   * @return List<Document>
   */
  List<Document> findAllByStatut(StatutDocument statut);

}
