package fr.acoss.dory.agent.gen.sip.database.access;

public interface DatabaseAccess {

  void genererSip();
}
