package fr.acoss.dory.agent.gen.sip.core.metier;

/**
 * Gestion de fichier(access,...)
 */
public interface FileStorage {

  /**
   * Permet de savoir l'existance d'un fichier
   * 
   * @param strPath
   *          String
   * @return boolean
   */
  boolean exists(String strPath);

}
