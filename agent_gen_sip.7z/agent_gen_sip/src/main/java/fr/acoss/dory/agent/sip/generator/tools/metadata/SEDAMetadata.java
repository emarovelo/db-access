package fr.acoss.dory.agent.sip.generator.tools.metadata;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import org.apache.commons.lang3.reflect.ConstructorUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import fr.acoss.dory.agent.sip.generator.tools.utils.SEDALibException;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLEventReader;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class SEDAMetadata.
 * <p>
 * Abstract class for SEDA element metadata.
 */
public abstract class SEDAMetadata {

  /**
   * Export the metadata in XML expected form for the SEDA Manifest.
   *
   * @param xmlWriter the SEDAXMLStreamWriter generating the SEDA manifest
   * @throws SEDALibException if the XML can't be written
   */
  public abstract void toSedaXml(SEDAXMLStreamWriter xmlWriter) throws SEDALibException;

  /**
   * Export the metadata to csv List for the csv metadata file.
   * <p>
   * In the HashMap result, the key is a metadata path of a leaf and the value is the leaf of the metadata value.
   *
   * @return the linked hash map with header title as key and metadata value as value
   * @throws SEDALibException if the XML can't be written
   */
  public abstract LinkedHashMap<String,String> toCsvList() throws SEDALibException;

  /**
   * Return the indented XML export form as the String representation.
   *
   * @return the indented XML form String
   */
  @Override
  public String toString() {
    String result = null;
    try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SEDAXMLStreamWriter xmlWriter = new SEDAXMLStreamWriter(baos, 2)) {
      toSedaXml(xmlWriter);
      xmlWriter.flush();
      result = baos.toString("UTF-8");
      if (result.startsWith("\n")) {
        result = result.substring(1);
      }
    } catch (XMLStreamException | IOException | SEDALibException e) {
      if (result == null) {
        result = super.toString();
      }
    }
    return result;
  }

  /**
   * Fill a SEDAMetadata subtype from SEDA XML content.
   *
   * @param xmlReader the xml reader
   * @return true if the SEDAMetadata has been generated, false if not
   * @throws SEDALibException the seda lib exception
   */
  public abstract boolean fillFromSedaXml(SEDAXMLEventReader xmlReader) throws SEDALibException;


  /**
   * Return the SEDAMetadata object from an XML event reader.
   *
   * @param xmlReader the xml reader
   * @param target    the target sub-class of SEDAMetadata
   * @return the read SEDAMetadata object
   * @throws SEDALibException if XML read exception or inappropriate sub-class
   */
  static public SEDAMetadata fromSedaXml(final SEDAXMLEventReader xmlReader, final Class<?> target) throws SEDALibException {
    try {
      final boolean needName = target.getName().contains(".namedtype.");
      SEDAMetadata sm;
      if (needName) {
        final XMLEvent event = xmlReader.peekUsefullEvent();
        sm = (SEDAMetadata) ConstructorUtils.invokeConstructor(target, event.asStartElement().getName().getLocalPart());
      } else {
        sm = (SEDAMetadata) ConstructorUtils.invokeConstructor(target);
      }
      if (sm.fillFromSedaXml(xmlReader)) {
        return sm;
      }
      final Method method = target.getMethod("fromSedaXml", SEDAXMLEventReader.class);
      return (SEDAMetadata) method.invoke(null, xmlReader);
    } catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException
        | SecurityException | InstantiationException e) {
      throw new SEDALibException("Erreur de construction du " + target.getSimpleName() + "\n->" + e.getMessage());
    } catch (final InvocationTargetException te) {
      throw new SEDALibException("Erreur de construction du " + target.getSimpleName() + "\n->" + te.getTargetException().getMessage());
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur de lecture XML dans un élément de type "+target.getSimpleName()+"\n->" + e.getMessage());
    }
  }

  /**
   * Return the SEDAMetadata object from an XML the String representation.
   *
   * @param xmlData the xml data
   * @param target  the target sub-class of SEDAMetadata
   * @return the SEDAMetadata object
   * @throws SEDALibException if XML read exception or inappropriate sub-class
   */
  static public SEDAMetadata fromString(final String xmlData, final Class<?> target) throws SEDALibException {
    SEDAMetadata result;

    try (ByteArrayInputStream bais = new ByteArrayInputStream(xmlData.getBytes("UTF-8"));
        SEDAXMLEventReader xmlReader = new SEDAXMLEventReader(bais, true)) {
      // jump StartDocument
      xmlReader.nextUsefullEvent();
      result = fromSedaXml(xmlReader, target);
      final XMLEvent event = xmlReader.xmlReader.peek();
      if (!event.isEndDocument()) {
        throw new SEDALibException("Il y a des champs illégaux");
      }
    } catch (XMLStreamException | SEDALibException | IOException e) {
      throw new SEDALibException("Erreur de lecture du " + target.getSimpleName() + "\n->" + e.getMessage());
    }

    return result;
  }

  /**
   * Gets the xml element name (local form) in SEDA XML messages.
   *
   * @return the xml element name
   */
  @JsonIgnore
  public abstract String getXmlElementName();
}
