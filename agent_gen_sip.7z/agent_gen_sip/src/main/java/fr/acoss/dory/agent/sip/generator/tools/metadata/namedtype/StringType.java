package fr.acoss.dory.agent.sip.generator.tools.metadata.namedtype;


import java.util.LinkedHashMap;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import fr.acoss.dory.agent.sip.generator.tools.utils.SEDALibException;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLEventReader;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class StringType.
 * <p>
 * For abstract String formatted SEDA metadata
 */
public class StringType extends NamedTypeMetadata {

  /** The value. */
  private String value;

  /**
   * Instantiates a new string.
   */
  public StringType() {
    this(null, (String) null);
  }

  /**
   * Instantiates a new string.
   *
   * @param elementName the XML element name
   */
  public StringType(final String elementName) {
    this(elementName, (String) null);
  }

  /**
   * Instantiates a new string.
   *
   * @param elementName the XML element name
   * @param value       the value
   */
  public StringType(final String elementName, final String value) {
    super(elementName);
    this.value = value;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toSedaXml(fr.gouv.vitam.
   * tools.sedalib.xml.SEDAXMLStreamWriter)
   */
  @Override
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeElementValue(elementName, value);
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML dans un élément de type StringType ["+getXmlElementName()+"]\n->" + e.getMessage());
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toCsvList()
   */
  @Override
  public LinkedHashMap<String, String> toCsvList() throws SEDALibException {
    final LinkedHashMap<String, String> result = new LinkedHashMap<>();
    result.put("",value);
    return result;
  }

  /**
   * Import the metadata content in XML expected form from the SEDA Manifest.
   *
   * @param xmlReader       the SEDAXMLEventReader reading the SEDA manifest
   * @return true, if it finds something convenient, false if not
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not respected, for example
   */
  public boolean fillFromSedaXml(final SEDAXMLEventReader xmlReader) throws SEDALibException {
    try {
      if (xmlReader.peekBlockIfNamed(elementName)) {
        xmlReader.nextUsefullEvent();
        XMLEvent event = xmlReader.nextUsefullEvent();
        if (event.isCharacters()) {
          value = event.asCharacters().getData();
          event = xmlReader.nextUsefullEvent();
        } else {
          value = "";
        }
        if (!event.isEndElement()
            || !elementName.equals(event.asEndElement().getName().getLocalPart())) {
          throw new SEDALibException("Elément " + elementName + " mal terminé");
        }
      } else {
        return false;
      }
    } catch (XMLStreamException | IllegalArgumentException | SEDALibException e) {
      throw new SEDALibException("Erreur de lecture XML dans un élément de type StringType\n->" + e.getMessage());
    }
    return true;
  }

  // Getters and setters

  /**
   * Get the value
   *
   * @return the value
   */
  public String getValue() {
    return value;
  }

  /**
   * Sets value.
   *
   * @param value the value
   */
  public void setValue(final String value) {
    this.value = value;
  }
}
