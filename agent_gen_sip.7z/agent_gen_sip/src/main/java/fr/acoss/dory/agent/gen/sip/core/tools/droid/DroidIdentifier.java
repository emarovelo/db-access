package fr.acoss.dory.agent.gen.sip.core.tools.droid;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;
import uk.gov.nationalarchives.droid.container.ContainerSignatureDefinitions;
import uk.gov.nationalarchives.droid.container.TriggerPuid;
import uk.gov.nationalarchives.droid.core.BinarySignatureIdentifier;
import uk.gov.nationalarchives.droid.core.SignatureParseException;
import uk.gov.nationalarchives.droid.core.interfaces.IdentificationRequest;
import uk.gov.nationalarchives.droid.core.interfaces.IdentificationResult;
import uk.gov.nationalarchives.droid.core.interfaces.IdentificationResultCollection;
import uk.gov.nationalarchives.droid.core.interfaces.RequestIdentifier;
import uk.gov.nationalarchives.droid.core.interfaces.resource.FileSystemIdentificationRequest;
import uk.gov.nationalarchives.droid.core.interfaces.resource.RequestMetaData;
import uk.gov.nationalarchives.droid.core.signature.FileFormat;
import uk.gov.nationalarchives.droid.core.signature.FileFormatCollection;
import uk.gov.nationalarchives.droid.core.signature.droid6.FFSignatureFile;

/**
 * The Class DroidIdentifier.
 * <p>
 * Singleton class for managing the DROID identifications
 */
public class DroidIdentifier {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(DroidIdentifier.class);

  /** Singleton. */
  private static DroidIdentifier instance = null;

  /** The config directory. */
  private final String configDir;

  /** DROID structures used for format identification. */
  private FFSignatureFile binarySignatureFile;

  /** The container signature definitions. */
  private ContainerSignatureDefinitions containerSignatureDefinitions;

  /** The binary signature identifier. */
  private BinarySignatureIdentifier binarySignatureIdentifier;

  /** The container content identifier map. */
  private HashMap<String, ContainerDroidIdentifier> containerContentIdentierMap;

  /**
   * Instantiates a new DROID identifier.
   *
   * @param configDir
   *          the config dir
   * @throws SEDALibException
   *           if the identifier can't be initialised, may be due to wrong signatures files
   */
  private DroidIdentifier(final String configDir) throws SEDALibException {
    this.configDir = configDir;
    initSignatureDroid();

  }

  /**
   * Initialises the single instance of DroidIdentifier.
   *
   * @param configDir
   *          the config dir
   * @return single instance of DroidIdentifier
   * @throws SEDALibException
   *           if the identifier can't be initialised, may be due to wrong signatures files
   */
  static public DroidIdentifier init(final String configDir) throws SEDALibException {
    instance = new DroidIdentifier(configDir);
    return instance;
  }

  /**
   * Gets the single instance of DroidIdentifier.
   *
   * @return single instance of DroidIdentifier
   */
  static public DroidIdentifier getInstance() {
    if (instance == null) {
      try {
        instance = new DroidIdentifier("./config");
      } catch (final SEDALibException e) {
        DroidIdentifier.LOGGER.error(e.getMessage());
      }
    }
    return instance;
  }

  /**
   * Gets the binary signature file name.
   * <p>
   * Search for a DROID_SignatureFileVxxx.xml in "config" directory or extract it
   * from resources to the "config" directory.
   *
   * @return the binary signature file name
   * @throws SEDALibException
   *           if unable to get signature file from disk and from
   *           resources
   */
  // search for a DROID_SignatureFile or extract from resources
  private String getBinarySignatureFileName() throws SEDALibException {
    String result = null;

    final FilenameFilter droidFilter = (dir, name) -> {
      if (name.startsWith("DROID_SignatureFile_V") && name.endsWith(".xml")) {
        final String serial = name.substring(21, name.lastIndexOf(".xml"));
        try {
          Integer.parseInt(serial);
        } catch (final NumberFormatException e) {
          return false;
        }
        return true;
      }
      return false;
    };

    final File dir = new File(configDir);
    if (dir.isFile()) {
      throw new SEDALibException("Panic! Can't create config directory");
    } else if (!dir.exists()) {
      // noinspection ResultOfMethodCallIgnored
      dir.mkdirs();
    }
    final String[] fileList = dir.list(droidFilter);
    if (fileList == null || fileList.length == 0) {
      DroidIdentifier.LOGGER.info("Can't find a DROID signature file, copy from ressource to file DROID_SignatureFile_V88.xml");

      try (InputStream is = Thread.currentThread()
          .getContextClassLoader()
          .getResourceAsStream("DROID_SignatureFile_V88.xml")) {
        final File targetFile = new File(
                                         "." + File.separator + "config" + File.separator + "DROID_SignatureFile_V88.xml");
        System.out.println("is=" + is + " toPath=" + targetFile.toPath());
        java.nio.file.Files.copy(is, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
      } catch (final IOException e) {
        throw new SEDALibException("Panic! Can't extract a DROID signature file, stop");
      }
      result = "DROID_SignatureFile_V88.xml";
    } else {
      int serialNum = -1;
      for (final String name : fileList) {
        final int j = Integer.parseInt(name.substring(21, name.lastIndexOf(".xml")));
        if (j > serialNum) {
          serialNum = j;
          result = name;
        }
      }
    }
    return "." + File.separator + "config" + File.separator + result;
  }

  /**
   * Inits the signature identifier context.
   *
   * @throws SEDALibException
   *           if unable to parse the signature file
   */
  private void initSignatureDroid() throws SEDALibException {
    binarySignatureIdentifier = new BinarySignatureIdentifier();

    final String sigFileName = getBinarySignatureFileName();
    binarySignatureIdentifier.setSignatureFile(sigFileName);
    try {
      binarySignatureIdentifier.init();
    } catch (final SignatureParseException x) {
      System.err.println("Panic: Can't parse file: '" + sigFileName + "'");
      System.exit(1);
    }
    binarySignatureFile = binarySignatureIdentifier.getSigFile();
  }


  /**
   * Gets the TriggerPuid by puid, or null if no match.
   * <p>
   * TriggerPuid gives the link between container identifier and puid of outer
   * format
   *
   * @param puid
   *          the puid
   * @return the TriggerPuid by puid
   */
  // get the container ID for the given PUID if any
  public TriggerPuid getTriggerPuidByPuid(final String puid) {
    for (final TriggerPuid tp : containerSignatureDefinitions.getTiggerPuids()) {
      if (tp.getPuid().equals(puid)) {
        return tp;
      }
    }
    return null;
  }

  /**
   * Can use container identification.
   *
   * @return true, if successful
   */
  public boolean canAnalyzeContainer() {
    return containerSignatureDefinitions != null;
  }

  /**
   * Gets the identification result.
   *
   * @param path
   *          the path of file to identify
   * @return the identification result
   * @throws SEDALibException
   *           if the file can't be read
   */
  public IdentificationResult getIdentificationResult(final Path path) throws SEDALibException {
    List<IdentificationResult> irl;
    final String filename = path.normalize().toString();
    FileSystemIdentificationRequest request;

    RequestMetaData metaData;
    try {
      metaData = new RequestMetaData(Files.size(path), Files.getLastModifiedTime(path).toMillis(), filename);
      final RequestIdentifier identifier = new RequestIdentifier(path.toUri());
      identifier.setParentId(1L);
      request = new FileSystemIdentificationRequest(metaData, identifier);
      request.open(path);
    } catch (final IOException e) {
      throw new SEDALibException("Impossible d'accéder au fichier [" + filename + "]");
    }

    final IdentificationResultCollection resultsSignatureCollection = getSignatureResults(request);
    IdentificationResultCollection resultsContainerCollection;
    try {
      resultsContainerCollection = getContainerResults(resultsSignatureCollection, request);
    } catch (final SEDALibException e) {
      try {
        request.close();
      } catch (final IOException e1) {
        // ignored
      }
      throw new SEDALibException("Erreur dans l'identification par container du fichier [" + filename + "]");
    }

    if (resultsContainerCollection != null && !resultsContainerCollection.getResults().isEmpty()) {
      irl = resultsContainerCollection.getResults();
    } else if (!resultsSignatureCollection.getResults().isEmpty()) {
      irl = resultsSignatureCollection.getResults();
    } else {
      irl = getExtensionResults(request).getResults();
    }

    try {
      request.close();
    } catch (final IOException e) {
      throw new SEDALibException("Erreur dans l'identification droid du fichier [" + filename + "], impossible de fermer la requête");
    }

    if (irl != null && !irl.isEmpty()) {
      String fileExtension = "";
      if (filename.lastIndexOf('.') != -1) {
        fileExtension = filename.substring(filename.lastIndexOf('.') + 1);
      }
      return selectBestResult(irl, fileExtension);
    } else {
      return null;
    }
  }

  /**
   * Gets the signature (no container) format identification if any.
   *
   * @param request
   *          the request
   * @return the signature results
   */
  public IdentificationResultCollection getSignatureResults(
                                                            @SuppressWarnings("rawtypes") final IdentificationRequest request) {

    final IdentificationResultCollection results = binarySignatureIdentifier.matchBinarySignatures(request);
    binarySignatureIdentifier.checkForExtensionsMismatches(results, request.getExtension());
    return results;
  }

  /**
   * Gets the extension format identification if any.
   *
   * @param request
   *          the request
   * @return the extension results
   */
  public IdentificationResultCollection getExtensionResults(
                                                            @SuppressWarnings("rawtypes") final IdentificationRequest request) {

    return binarySignatureIdentifier.matchExtensions(request, true);
  }

  /**
   * Gets the container format identification if any, for any type of container.
   *
   * @param signatureResults
   *          the signature results
   * @param request
   *          the request
   * @return the container results
   * @throws SEDALibException
   *           the SEDALibException
   */
  public IdentificationResultCollection getContainerResults(final IdentificationResultCollection signatureResults,
                                                            @SuppressWarnings("rawtypes") final IdentificationRequest request)
                                                                throws SEDALibException {
    IdentificationResultCollection containerResults = new IdentificationResultCollection(request);

    if (!signatureResults.getResults().isEmpty() && canAnalyzeContainer()) {
      for (final IdentificationResult identResult : signatureResults.getResults()) {
        final String filePuid = identResult.getPuid();
        if (filePuid != null) {
          final TriggerPuid containerPuid = getTriggerPuidByPuid(filePuid);
          if (containerPuid != null) {

            final String containerType = containerPuid.getContainerType();

            final ContainerDroidIdentifier cci = containerContentIdentierMap.get(containerType);
            if (cci != null) {
              try {
                containerResults = cci.getContainerIdentification(request.getSourceInputStream(),
                                                                  containerResults);
              } catch (final IOException e) { // go on after problems
                throw new SEDALibException(
                                           "Impossible d'analyser en conteneur le format du fichier [" + request.getFileName() + "]");
              }
            }
          }
        }
      }
    }
    return containerResults;
  }

  /**
   * Select best identification result.
   * <p>
   * Use the signature file priorities to sort the different formats, and the
   * extension to select the best format if there are more than one with no
   * priority at the higher level.
   *
   * @param irl
   *          the list of all identification results
   * @param fileExtension
   *          the file extension of original file
   * @return the best identification result, or null if the list was empty
   */
  // use the signature file priorities and the extension to select the best format
  protected IdentificationResult selectBestResult(final List<IdentificationResult> irl, final String fileExtension) {
    // special quick return cases
    int numResults = irl.size();
    if (numResults == 0) {
      return null;
    } else if (numResults == 1) {
      return irl.get(0);
    }

    // Build a set of format ids the results have priority over:
    final FileFormatCollection allFormats = binarySignatureFile.getFileFormatCollection();
    final Set<Integer> lowerPriorityIDs = new HashSet<>();
    for (int i = 0; i < numResults; i++) {
      final IdentificationResult result = irl.get(i);
      final String resultPUID = result.getPuid();
      final FileFormat format = allFormats.getFormatForPUID(resultPUID);
      lowerPriorityIDs.addAll(format.getFormatIdsHasPriorityOver());
    }

    // if a result has an id in this set, add it to the remove list
    final List<IdentificationResult> lowerPriorityResults = new ArrayList<>();
    for (int i = 0; i < numResults; i++) {
      final IdentificationResult tmp = irl.get(i);
      final String resultPUID = tmp.getPuid();
      final FileFormat format = allFormats.getFormatForPUID(resultPUID);
      if (lowerPriorityIDs.contains(format.getID())) {
        lowerPriorityResults.add(tmp);
      }
    }

    // now remove any lower priority results from the list
    numResults = lowerPriorityResults.size();
    for (int i = 0; i < numResults; i++) {
      irl.remove(lowerPriorityResults.get(i));
    }

    // different return cases
    numResults = irl.size();
    if (numResults == 0) {
      return null;
    } else if (numResults == 1) {
      return irl.get(0);
    } else {
      // if multiple results use extension to choose
      for (int i = 0; i < numResults; i++) {
        final FileFormat format = allFormats.getFormatForPUID(irl.get(i).getPuid());
        if (format.hasMatchingExtension(fileExtension)) {
          return irl.get(i);
        }
      }
      // if no matching extension choose the first in the list
      return irl.get(0);
    }
  }
}
