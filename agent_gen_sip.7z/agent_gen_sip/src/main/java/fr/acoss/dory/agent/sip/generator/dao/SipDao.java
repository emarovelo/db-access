package fr.acoss.dory.agent.sip.generator.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.agent.sip.generator.model.persistance.Sip;
import fr.acoss.dory.agent.sip.generator.model.persistance.StatutSip;

/**
 * Interface DAO de gestion de sip
 */
public interface SipDao extends JpaRepository<Sip, Long> {

  /**
   * Recherche de sip par son statut
   * 
   * @param statut
   *          StatutSip
   * @return List<Sip>
   */
  List<Sip> findAllByStatut(StatutSip statut);
}
