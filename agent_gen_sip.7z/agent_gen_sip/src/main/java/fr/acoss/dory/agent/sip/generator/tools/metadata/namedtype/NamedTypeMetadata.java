package fr.acoss.dory.agent.sip.generator.tools.metadata.namedtype;

import fr.acoss.dory.agent.sip.generator.tools.metadata.SEDAMetadata;

public abstract class NamedTypeMetadata extends SEDAMetadata {

  protected String elementName;

  /**
   * Instantiates a named type SEDAMetadata.
   *
   * @param elementName the XML element name
   */
  public NamedTypeMetadata(final String elementName) {
    this.elementName = elementName;
  }

  @Override
  public String getXmlElementName() {
    return elementName;
  }
}
