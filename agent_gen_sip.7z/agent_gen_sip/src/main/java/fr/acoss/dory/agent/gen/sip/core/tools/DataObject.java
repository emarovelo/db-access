package fr.acoss.dory.agent.gen.sip.core.tools;

import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Interface DataObject.
 * <p>
 * Interface for SEDA elements BinaryDataObject, PhysicalDataObject and
 * DataObjectGroup that can be managed the same way in export and import for
 * edition, and linked to ArchiveUnit.
 */
public interface DataObject {

  // SEDA XML exporter

  /**
   * Export in XML expected form for the SEDA Manifest.
   *
   * @param xmlWriter             the SEDAXMLStreamWriter generating the SEDA manifest
   * @throws InterruptedException if export process is interrupted
   * @throws SEDALibException     if the XML can't be written
   */
  void toSedaXml(SEDAXMLStreamWriter xmlWriter)
      throws InterruptedException, SEDALibException;

  /**
   * Export the elements that can be edited without changing the structure. This
   * is in XML expected form for the SEDA Manifest but in String.
   *
   * @return the XML elements in String format
   * @throws SEDALibException if the XML can't be written
   */
  String toSedaXmlFragments() throws SEDALibException;

  // SEDA XML importer

  /**
   * Import the elements that can be edited without changing the structure. This
   * is in XML expected form for the SEDA Manifest but in String.
   *
   * @param fragments the XML elements in String format
   * @throws SEDALibException if the XML can't be read or don't have expected
   *                          mandatory field - Content
   */
  void fromSedaXmlFragments(String fragments) throws SEDALibException;

  // Getters and setters

  /**
   * Gets the id in DataObjectPackage.
   *
   * @return the id in DataObjectPackage
   */
  String getInDataObjectPackageId();

  /**
   * Gets the DataObjectGroup.
   *
   * @return the DataObjectGroup
   */
  DataObjectGroup getDataObjectGroup();
}
