package fr.acoss.dory.agent.gen.sip.core.tools.metadata.namedtype;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ComplexListMetadataMap {
  boolean isExpandable() default false;
}
