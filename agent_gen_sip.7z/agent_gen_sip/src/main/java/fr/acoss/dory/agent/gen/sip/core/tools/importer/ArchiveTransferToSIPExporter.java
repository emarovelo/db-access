package fr.acoss.dory.agent.gen.sip.core.tools.importer;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.stream.XMLStreamException;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.acoss.dory.agent.gen.sip.core.tools.ArchiveTransfer;
import fr.acoss.dory.agent.gen.sip.core.tools.BinaryDataObject;
import fr.acoss.dory.agent.gen.sip.core.tools.DataObjectGroup;
import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.IndentXMLTool;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class ArchiveTransferToSIPExporter.
 * <p>
 * Class for ArchiveTransfer object export in a SEDA Submission Information
 * Packet (SIP).
 */
public class ArchiveTransferToSIPExporter {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(ArchiveTransferToSIPExporter.class);

  /** The archiveTransfer. */
  protected ArchiveTransfer archiveTransfer;

  /** The export path. */
  private Path exportPath;

  /** The parameters flag for manifest generation. */
  private boolean hierarchicalFlag, indentedFlag;

  /** The xml writer. */
  protected SEDAXMLStreamWriter xmlWriter;

  /** The start and end instants, for duration computation. */
  private Instant start, end;

  /** The export mode. */
  private boolean manifestOnly;

  /**
   * Instantiates a new ArchiveTransfer to SIP exporter.
   *
   * @param archiveTransfer the ArchiveTransfer
   */
  public ArchiveTransferToSIPExporter(final ArchiveTransfer archiveTransfer) {
    this.archiveTransfer = archiveTransfer;
  }

  /**
   * Export SEDA XML manifest output stream.
   *
   * @param os               the OutputStream
   * @param hierarchicalFlag the hierarchical flag
   * @param indentedFlag         the indentedFlag
   * @throws SEDALibException     if writing has failed
   * @throws InterruptedException if export process is interrupted
   */
  public void exportManifestOutputStream(final OutputStream os, final boolean hierarchicalFlag, final boolean indentedFlag)
      throws SEDALibException, InterruptedException {
    try (SEDAXMLStreamWriter ixsw = new SEDAXMLStreamWriter(os, indentedFlag ? IndentXMLTool.STANDARD_INDENT : 0)) {
      xmlWriter = ixsw;
      archiveTransfer.toSedaXml(xmlWriter, hierarchicalFlag);
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Echec d'écriture XML du manifest", e);
    }
  }

  /**
   * Do export the ArchiveTransfer to SEDA Submission Information Packet (SIP).
   *
   * @param fileName         the file name
   * @param hierarchicalFlag the hierarchical flag
   * @param indentedFlag         the indentedFlag
   * @throws SEDALibException     if writing has failed
   * @throws InterruptedException if export process is interrupted
   */
  public void doExportToSEDASIP(final String fileName, final boolean hierarchicalFlag, final boolean indentedFlag)
      throws SEDALibException, InterruptedException {
    int counter = 0;
    final Date d = new Date();
    start = Instant.now();
    String log = "Début de l'export d'un ArchiveTransfer dans un SIP\n";
    log += "en [" + fileName + "]";
    log += " date=" + DateFormat.getDateTimeInstance().format(d);

    ArchiveTransferToSIPExporter.LOGGER.info(log);
    exportPath = Paths.get(fileName);
    this.hierarchicalFlag = hierarchicalFlag;
    this.indentedFlag = indentedFlag;
    manifestOnly = false;

    try {
      Files.createDirectories(Paths.get(fileName).getParent());
    } catch (final IOException e1) {
      throw new SEDALibException("Impossible de créer le répertoire [" + Paths.get(fileName).getParent().toString() + "]", e1);
    }
    try (ZipOutputStream zipout = new ZipOutputStream(new FileOutputStream(fileName))) {
      ZipEntry e = new ZipEntry("manifest.xml");
      // manifest
      zipout.putNextEntry(e);
      exportManifestOutputStream(zipout, hierarchicalFlag, indentedFlag);
      zipout.closeEntry();

      ArchiveTransferToSIPExporter.LOGGER.info(Integer.toString(archiveTransfer.getDataObjectPackage().getInOutCounter())
                                               + " ArchiveUnit/DataObject (métadonnées) exportés\n" + archiveTransfer.getDescription());

      // all binary objects
      if (archiveTransfer.getDataObjectPackage().getDataObjectGroupCount() > 0) {
        for (final Map.Entry<String, DataObjectGroup> pair : archiveTransfer.getDataObjectPackage()
            .getDogInDataObjectPackageIdMap().entrySet()) {
          final DataObjectGroup og = pair.getValue();
          if (og.getBinaryDataObjectList() != null) {
            for (final BinaryDataObject bo : og.getBinaryDataObjectList()) {
              e = new ZipEntry(bo.uri);
              zipout.putNextEntry(e);
              final FileInputStream fis = new FileInputStream(bo.getOnDiskPath().toFile());
              IOUtils.copy(fis, zipout);
              fis.close();
              zipout.closeEntry();
              counter++;

              ArchiveTransferToSIPExporter.LOGGER.info(
                                                       Integer.toString(counter) + " BinaryDataObject (fichiers) exportés");
            }
          }
        }
      }
    } catch (IOException | SEDALibException e) {
      throw new SEDALibException("Echec de l'export du SIP dans le fichier [" + fileName + "]", e);
    }

    ArchiveTransferToSIPExporter.LOGGER.info(Integer.toString(counter) +
        " BinaryDataObject (fichiers) exportés");

    end = Instant.now();
  }

  /**
   * Gets the summary of the export process.
   *
   * @return the summary String
   */
  public String getSummary() {
    String result = "Export d'un ArchiveTransfer dans un ";
    if (manifestOnly) {
      result += "manifest SEDA\n";
    } else {
      result += "SIP\n";
    }
    result += "en [" + exportPath + "]\n";
    if (hierarchicalFlag) {
      result += "avec une structure imbriquée ";
    } else {
      result += "avec une structure à plat ";
    }
    if (indentedFlag) {
      result += "en XML identé\n";
    } else {
      result += "en XML continu\n";
    }

    if (start != null && end != null) {
      result += "effectué en " + Duration.between(start, end).toString().substring(2) + "\n";
    }
    return result;
  }
}
