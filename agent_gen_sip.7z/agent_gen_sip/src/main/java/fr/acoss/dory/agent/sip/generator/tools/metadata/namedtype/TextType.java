package fr.acoss.dory.agent.sip.generator.tools.metadata.namedtype;

import java.util.LinkedHashMap;

import javax.xml.XMLConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import fr.acoss.dory.agent.sip.generator.tools.utils.SEDALibException;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLEventReader;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class TextType.
 * <p>
 * For abstract String formatted with optional language SEDA metadata
 */
public class TextType extends NamedTypeMetadata {

  /**
   * The value.
   */
  private String value;

  /**
   * The lang.
   */
  private String lang;

  /**
   * Instantiates a new string with language attribute.
   */
  public TextType() {
    this(null, null, null);
  }

  /**
   * Instantiates a new string with language attribute.
   *
   * @param elementName the XML element name
   */
  public TextType(final String elementName) {
    this(elementName, null, null);
  }

  /**
   * Instantiates a new string with language attribute.
   *
   * @param elementName the XML element name
   * @param value       the value
   */
  public TextType(final String elementName, final String value) {
    this(elementName, value, null);
  }

  /**
   * Instantiates a new string with language attribute.
   *
   * @param elementName the XML element name
   * @param value       the value
   * @param lang        the language
   */
  public TextType(final String elementName, final String value, final String lang) {
    super(elementName);
    this.value = value;
    this.lang = lang;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toSedaXml(fr.gouv.vitam.
   * tools.sedalib.xml.SEDAXMLStreamWriter)
   */
  @Override
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeStartElement(elementName);
      if (lang != null) {
        xmlWriter.writeAttribute("xml:lang", lang);
      }
      xmlWriter.writeCharactersIfNotEmpty(value);
      xmlWriter.writeEndElement();
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML dans un élément de type TextType [" + getXmlElementName() + "]\n->" + e.getMessage());
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toCsvList()
   */
  @Override
  public LinkedHashMap<String, String> toCsvList() throws SEDALibException {
    final LinkedHashMap<String, String> result = new LinkedHashMap<>();
    if (value != null) {
      result.put("", value);
      if (lang != null) {
        result.put("attr", "xml:lang=\""+lang+"\"");
      }
    }
    return result;
  }

  /**
   * Import the metadata content in XML expected form from the SEDA Manifest.
   *
   * @param xmlReader the SEDAXMLEventReader reading the SEDA manifest
   * @return true, if it finds something convenient, false if not
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not respected, for example
   */
  public boolean fillFromSedaXml(final SEDAXMLEventReader xmlReader) throws SEDALibException {
    try {
      if (xmlReader.peekBlockIfNamed(elementName)) {
        lang = xmlReader.peekAttribute(XMLConstants.XML_NS_URI,"lang");
        xmlReader.nextUsefullEvent();
        XMLEvent event = xmlReader.nextUsefullEvent();
        if (event.isCharacters()) {
          value = event.asCharacters().getData();
          event = xmlReader.nextUsefullEvent();
        } else {
          value = "";
        }
        if (!event.isEndElement() || !elementName.equals(event.asEndElement().getName().getLocalPart())) {
          throw new SEDALibException("Elément " + elementName + " mal terminé");
        }
      } else {
        return false;
      }
    } catch (XMLStreamException | IllegalArgumentException | SEDALibException e) {
      throw new SEDALibException("Erreur de lecture XML dans un élément de type StringType\n->" + e.getMessage());
    }
    return true;
  }

  // Getters and setters

  /**
   * Get the lang
   *
   * @return the lang
   */
  public String getLang() {
    return lang;
  }

  /**
   * Get the value
   *
   * @return the value
   */
  public String getValue() {
    return value;
  }

  /**
   * Sets value.
   *
   * @param value the value
   */
  public void setValue(final String value) {
    this.value = value;
  }

  /**
   * Sets lang.
   *
   * @param lang the lang
   */
  public void setLang(final String lang) {
    this.lang = lang;
  }


}
