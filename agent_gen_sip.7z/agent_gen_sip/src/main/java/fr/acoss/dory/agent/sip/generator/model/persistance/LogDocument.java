package fr.acoss.dory.agent.sip.generator.model.persistance;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Version;

/**
 * Classe de persistance de la table logdocument
 * .
 * Clef technique
 * id : séquence autoincrementé
 */
@Entity(name = "log_document")
public class LogDocument extends AbstractPersistanceMere implements Serializable {

  private static final long serialVersionUID = -8586679090747349037L;

  /** Champ id. */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String message;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "id_document")
  private Document document;

  /** Champ date creation. */
  @Column(name = "dt_creation", updatable = false)
  private OffsetDateTime dateCreation;

  /**
   * Champ date maj.
   * Utilisé pour gérer les accès concurrents.
   * 
   * @See fr.recouv.appliblanche.technique.layer.dao.AbstractGenericDaoImpl.java#findByChampForUpdate()
   */
  @Column(name = "dt_maj")
  @Version
  private OffsetDateTime dateMaj;

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * @param message
   *          the message to set
   */
  public void setMessage(final String message) {
    this.message = message;
  }

  /**
   * @return the document
   */
  public Document getDocument() {
    return document;
  }

  /**
   * @param document
   *          the document to set
   */
  public void setDocument(final Document document) {
    this.document = document;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (dateCreation == null ? 0 : dateCreation.hashCode());
    result = prime * result + (dateMaj == null ? 0 : dateMaj.hashCode());
    result = prime * result + (document == null ? 0 : document.hashCode());
    result = prime * result + (id == null ? 0 : id.hashCode());
    result = prime * result + (message == null ? 0 : message.hashCode());
    return result;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final LogDocument other = (LogDocument) obj;
    if (dateCreation == null) {
      if (other.dateCreation != null) {
        return false;
      }
    } else if (!dateCreation.equals(other.dateCreation)) {
      return false;
    }
    if (dateMaj == null) {
      if (other.dateMaj != null) {
        return false;
      }
    } else if (!dateMaj.equals(other.dateMaj)) {
      return false;
    }
    if (document == null) {
      if (other.document != null) {
        return false;
      }
    } else if (!document.equals(other.document)) {
      return false;
    }
    if (id == null) {
      if (other.id != null) {
        return false;
      }
    } else if (!id.equals(other.id)) {
      return false;
    }
    if (message == null) {
      if (other.message != null) {
        return false;
      }
    } else if (!message.equals(other.message)) {
      return false;
    }
    return true;
  }

}
