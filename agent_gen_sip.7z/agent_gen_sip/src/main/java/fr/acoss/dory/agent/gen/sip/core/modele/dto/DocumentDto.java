package fr.acoss.dory.agent.gen.sip.core.modele.dto;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DocumentType
 */
public class DocumentDto   {

  @JsonProperty("id")
  private Long id;

  @JsonProperty("uuid")
  private String uuid = null;

  @JsonProperty("pathDocument")
  private String pathDocument = null;


  @JsonProperty("hashScelle")
  private String hashScelle = null;

  @JsonProperty("blocHorodate")
  private String blocHorodate = null;


  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  public DocumentDto uuid(final String uuid) {
    this.uuid = uuid;
    return this;
  }

  /**
   * uuid du document
   * @return uuid
   **/
  public String getUuid() {
    return uuid;
  }

  public void setUuid(final String uuid) {
    this.uuid = uuid;
  }

  public DocumentDto pathDocument(final String pathDocument) {
    this.pathDocument = pathDocument;
    return this;
  }

  /**
   * L url de depot du document
   * @return pathDocument
   **/
  public String getPathDocument() {
    return pathDocument;
  }

  public void setPathDocument(final String pathDocument) {
    this.pathDocument = pathDocument;
  }

  public DocumentDto hashScelle(final String hashScelle) {
    this.hashScelle = hashScelle;
    return this;
  }

  /**
   * Hash scellé du document
   * @return hashScelle
   **/
  public String getHashScelle() {
    return hashScelle;
  }

  public void setHashScelle(final String hashScelle) {
    this.hashScelle = hashScelle;
  }

  public DocumentDto blocHorodate(final String blocHorodate) {
    this.blocHorodate = blocHorodate;
    return this;
  }

  /**
   * Bloc horodate du document
   * @return blocHorodate
   **/
  public String getBlocHorodate() {
    return blocHorodate;
  }

  public void setBlocHorodate(final String blocHorodate) {
    this.blocHorodate = blocHorodate;
  }

  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final DocumentDto documentType = (DocumentDto) o;
    return Objects.equals(uuid, documentType.uuid) &&
        Objects.equals(pathDocument, documentType.pathDocument) &&
        Objects.equals(hashScelle, documentType.hashScelle) &&
        Objects.equals(blocHorodate, documentType.blocHorodate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, pathDocument, hashScelle, blocHorodate);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class DocumentType {\n");

    sb.append("    uuid: ").append(toIndentedString(uuid)).append("\n");
    sb.append("    pathDocument: ").append(toIndentedString(pathDocument)).append("\n");
    sb.append("    hashScelle: ").append(toIndentedString(hashScelle)).append("\n");
    sb.append("    blocHorodate: ").append(toIndentedString(blocHorodate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

