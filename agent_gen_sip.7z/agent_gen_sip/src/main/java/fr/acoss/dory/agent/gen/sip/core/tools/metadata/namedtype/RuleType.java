package fr.acoss.dory.agent.gen.sip.core.tools.metadata.namedtype;


import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.stream.XMLStreamException;

import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLEventReader;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class RuleType.
 * <p>
 * For abstract Rule type SEDA metadata
 */
public class RuleType extends NamedTypeMetadata {

  /**
   * The rules.
   */
  private final List<String> rules;

  /**
   * The start dates.
   */
  private final List<LocalDate> startDates;

  /**
   * The prevent inheritance.
   */
  private Boolean preventInheritance;

  /**
   * The ref non rule ids.
   */
  private final List<String> refNonRuleIds;

  /**
   * The final action.
   */
  private String finalAction;

  /**
   * Instantiates a new rule Type.
   */
  public RuleType() {
    this(null);
  }

  /**
   * Instantiates a new rule Type.
   *
   * @param elementName the element name
   */
  public RuleType(final String elementName) {
    super(elementName);
    rules = new ArrayList<>();
    startDates = new ArrayList<>();
    preventInheritance = null;
    refNonRuleIds = new ArrayList<>();
  }

  /**
   * Instantiates a new rule Type, with one rule and a date.
   *
   * @param elementName the element name
   * @param rule        the rule
   * @param startDate   the start date
   */
  public RuleType(final String elementName, final String rule, final LocalDate startDate) {
    this(elementName);
    rules.add(rule);
    startDates.add(startDate);
  }

  /**
   * Instantiates a new rule Type, with one rule and a date.
   *
   * @param elementName the element name
   * @param rule        the rule
   * @param startDate   the start date
   * @param finalAction the final action
   * @throws SEDALibException if the FinalAction field or value is not expected in
   *                          this kind of rule
   */
  public RuleType(final String elementName, final String rule, final LocalDate startDate, final String finalAction) throws SEDALibException {
    this(elementName);
    rules.add(rule);
    startDates.add(startDate);
    setFinalAction(finalAction);
  }

  /**
   * Adds the rule.
   *
   * @param rule the rule
   */
  public void addRule(final String rule) {
    rules.add(rule);
    startDates.add(null);
  }

  /**
   * Adds the rule.
   *
   * @param rule      the rule
   * @param startDate the start date
   */
  public void addRule(final String rule, final LocalDate startDate) {
    rules.add(rule);
    startDates.add(startDate);
  }

  /**
   * Sets the prevent inheritance.
   *
   * @param preventInheritance the new prevent inheritance
   */
  public void setPreventInheritance(final boolean preventInheritance) {
    this.preventInheritance = preventInheritance;
  }

  /**
   * Adds the ref non rule id.
   *
   * @param rule the rule
   */
  public void addRefNonRuleId(final String rule) {
    refNonRuleIds.add(rule);
  }

  /**
   * Set final action.
   *
   * @param finalAction the final action
   * @throws SEDALibException if the FinalAction field or value is not expected in
   *                          this kind of rule
   */
  public void setFinalAction(final String finalAction) throws SEDALibException {
    final List<String> finalValues = getFinalActionList();
    if (finalValues == null) {
      throw new SEDALibException("Le type de règle [" + elementName + "] n'a pas de FinalAction");
    }
    if (!finalValues.contains(finalAction)) {
      throw new SEDALibException(
                                 "Le type de règle [" + elementName + "] n'accepte pas la FinalAction [" + finalAction + "]");
    }
    this.finalAction = finalAction;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toSedaXml(fr.gouv.vitam.
   * tools.sedalib.xml.SEDAXMLStreamWriter)
   */
  @Override
  @SuppressWarnings("static-access")
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeStartElement(elementName);
      for (int i = 0; i < rules.size(); i++) {
        xmlWriter.writeElementValue("Rule", rules.get(i));
        if (startDates.get(i) != null) {
          xmlWriter.writeElementValue("StartDate", SEDAXMLStreamWriter.getStringFromDate(startDates.get(i)));
        }
      }
      if (preventInheritance != null) {
        xmlWriter.writeElementValue("PreventInheritance", preventInheritance.toString());
      }
      for (final String refNonRuleId : refNonRuleIds) {
        xmlWriter.writeElementValue("RefNonRuleId", refNonRuleId);
      }
      if (getFinalActionList()!=null && finalAction!=null) {
        xmlWriter.writeElementValue("FinalAction", finalAction);
      }
      xmlWriter.writeEndElement();
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML dans un élément RuleType\n->" + e.getMessage());
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toCsvList()
   */
  @Override
  public LinkedHashMap<String, String> toCsvList() throws SEDALibException {
    final LinkedHashMap<String, String> result = new LinkedHashMap<>();
    for (int i = 0; i < rules.size(); i++) {
      result.put("Rule." + i, rules.get(i));
      if (startDates.get(i) != null) {
        result.put("StartDate." + i, SEDAXMLStreamWriter.getStringFromDate(startDates.get(i)));
      }
    }
    if (preventInheritance != null) {
      result.put("PreventInheritance", preventInheritance.toString());
    }
    int count = 0;
    for (final String refNonRuleId : refNonRuleIds) {
      result.put("RefNonRuleId." + count, refNonRuleId);
      count++;
    }
    if (getFinalActionList()!=null && finalAction!=null) {
      result.put("FinalAction", finalAction);
    }
    return result;
  }

  /**
   * Import the metadata content in XML expected form from the SEDA Manifest.
   *
   * @param xmlReader       the SEDAXMLEventReader reading the SEDA manifest
   * @return true, if it finds something convenient, false if not
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not respected, for example
   */
  @Override
  public boolean fillFromSedaXml(final SEDAXMLEventReader xmlReader) throws SEDALibException {
    String tmp, tmpDate;
    LocalDate startDate;
    try {
      if (xmlReader.nextBlockIfNamed(elementName)) {
        tmp = xmlReader.nextValueIfNamed("Rule");
        while (tmp != null) {
          tmpDate = xmlReader.nextValueIfNamed("StartDate");
          if (tmpDate == null) {
            startDate = null;
          } else {
            try {
              startDate = SEDAXMLEventReader.getDateFromString(tmpDate);
            } catch (final DateTimeParseException e) {
              throw new SEDALibException("La date est mal formatée");
            }
          }
          addRule(tmp, startDate);
          tmp = xmlReader.nextValueIfNamed("Rule");
        }
        preventInheritance = xmlReader.nextBooleanValueIfNamed("PreventInheritance");
        tmp = xmlReader.nextValueIfNamed("RefNonRuleId");
        while (tmp != null) {
          addRefNonRuleId(tmp);
          tmp = xmlReader.nextValueIfNamed("RefNonRuleId");
        }
        if (getFinalActionList() != null) {
          finalAction = xmlReader.nextValueIfNamed("FinalAction");
        }
        xmlReader.endBlockNamed(elementName);
      } else {
        return false;
      }
    } catch (XMLStreamException | IllegalArgumentException | SEDALibException e) {
      throw new SEDALibException("Erreur de lecture XML dans un élément de type RuleType\n->" + e.getMessage());
    }
    return true;
  }

  /**
   * Gets the final action value list or null if final action is not authorized.
   *
   * @return the final action list
   */
  public List<String> getFinalActionList(){return null;}
}
