package fr.acoss.dory.agent.gen.sip.core.tools.metadata.data;

import java.util.LinkedHashMap;

import javax.xml.stream.XMLStreamException;

import fr.acoss.dory.agent.gen.sip.core.tools.metadata.SEDAMetadata;
import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLEventReader;
import fr.acoss.dory.agent.gen.sip.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class FormatIdentification.
 * <p>
 * Class for SEDA element FormatIdentification. It's filled with
 * <a href="https://www.nationalarchives.gov.uk/PRONOM">PRONOM</a> (the TNA
 * format register) information.
 * <p>
 * A BinaryDataObject metadata.
 * <p>
 * Standard quote: "Identification du format de l'objet-données"
 */
public class FormatIdentification extends SEDAMetadata {

  // SEDA elements

  /** The format litteral. */
  public String formatLitteral;

  /** The mime type. */
  public String mimeType;

  /** The format id. */
  public String formatId;

  /** The encoding. */
  public String encoding;

  // Constructors

  /**
   * Instantiates a new FormatIdentification.
   */
  public FormatIdentification() {
    this(null, null, null, null);
  }

  /**
   * Instantiates a new FormatIdentification.
   *
   * @param formatLitteral the format litteral
   * @param mimeType       the mime type
   * @param formatId       the format id
   * @param encoding       the encoding
   */
  public FormatIdentification(final String formatLitteral, final String mimeType, final String formatId, final String encoding) {
    this.formatLitteral = formatLitteral;
    this.mimeType = mimeType;
    this.formatId = formatId;
    this.encoding = encoding;
  }

  @Override
  public String getXmlElementName() {
    return "FormatIdentification";
  }

  @Override
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeStartElement("FormatIdentification");
      xmlWriter.writeElementValueIfNotEmpty("FormatLitteral", formatLitteral);
      xmlWriter.writeElementValueIfNotEmpty("MimeType", mimeType);
      xmlWriter.writeElementValueIfNotEmpty("FormatId", formatId);
      xmlWriter.writeElementValueIfNotEmpty("Encoding", encoding);
      xmlWriter.writeEndElement();
    } catch (final XMLStreamException e) {
      throw new SEDALibException(
                                 "Erreur d'écriture XML dans un élément FormatIdentification\n->" + e.getMessage());
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toCsvList()
   */
  @Override
  public LinkedHashMap<String, String> toCsvList() throws SEDALibException {
    throw new SEDALibException("Not implemented");
  }

  /**
   * Import the metadata content in XML expected form from the SEDA Manifest.
   *
   * @param xmlReader       the SEDAXMLEventReader reading the SEDA manifest
   * @return true, if it finds something convenient, false if not
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not respected, for example
   */
  @Override
  public boolean fillFromSedaXml(final SEDAXMLEventReader xmlReader) throws SEDALibException {
    try {
      if (xmlReader.nextBlockIfNamed("FormatIdentification")) {
        formatLitteral = xmlReader.nextValueIfNamed("FormatLitteral");
        mimeType = xmlReader.nextValueIfNamed("MimeType");
        formatId = xmlReader.nextValueIfNamed("FormatId");
        encoding = xmlReader.nextValueIfNamed("Encoding");
        xmlReader.endBlockNamed("FormatIdentification");
      } else {
        return false;
      }
    } catch (XMLStreamException | IllegalArgumentException | SEDALibException e) {
      throw new SEDALibException("Erreur de lecture XML dans un élément de type FormatIdentification\n->" + e.getMessage());
    }
    return true;
  }
}
