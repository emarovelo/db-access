package fr.acoss.dory.agent.gen.sip.core.metier.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import fr.acoss.dory.agent.gen.sip.core.data.Work;
import fr.acoss.dory.agent.gen.sip.core.metier.SipGenerator;
import fr.acoss.dory.agent.gen.sip.core.modele.dto.DocumentDto;
import fr.acoss.dory.agent.gen.sip.core.tools.ArchiveTransfer;
import fr.acoss.dory.agent.gen.sip.core.tools.importer.ArchiveTransferToSIPExporter;
import fr.acoss.dory.agent.gen.sip.core.tools.importer.DiskToDataObjectPackageImporter;
import fr.acoss.dory.agent.gen.sip.core.tools.parameters.DiskImportContext;
import fr.acoss.dory.agent.gen.sip.core.tools.parameters.ExportContext;
import fr.acoss.dory.agent.gen.sip.core.tools.parameters.Prefs;
import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;

/**
 * Couche métier de gestion de SIP
 */
@Service
public class SipGeneratorImpl implements SipGenerator {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(SipGeneratorImpl.class);

  /*
   * The preferences file name.
   */
  static public final String PREFERENCES_FILENAME = "preferences.properties";

  @Autowired
  private ResourceLoader resourceLoader;

  /*
   * Le path du fichier preferences.properties
   */
  private Path preferencePath;


  @PostConstruct
  private void postConstruct() {
    final Resource preferenceFileResource = resourceLoader.getResource("classpath:" + PREFERENCES_FILENAME);
    try {
      final File preferenceFile = preferenceFileResource.getFile();
      preferencePath = preferenceFile != null ? preferenceFile.toPath() : preferencePath;
    } catch (final IOException e1) {
    }
  }

  /**
   * Méthode appelee par le scheduler et qui permet de generer des SIP
   * Ces SIP sont créés à partir des documents qui sont préalablement déposés par doribackend et dont le statut est HOROTATE
   */
  public void generateSipe(final List<Path> lstPathDocument) {

    //    if (documentMetier != null) {
    //      final CriteresRechercheDocumentType criteresRecherche = new CriteresRechercheDocumentType();
    //      //criteresRecherche.setIdArchivage("a0ab4215-ef95-40fe-b1a1-ad3641ff3dd6");
    //      final List<DocumentType> result = documentMetier.rechercherDocuments(criteresRecherche);
    //      System.out.println(result);
    //
    //
    //      if (result != null) {
    //        final LotVersementType lotVersementType = new LotVersementType();
    //        lotVersementType.setNom("Lot 1");
    //        lotVersementType.setUrlDepot("test");
    //        lotVersementMetier.creerLot(lotVersementType, result);
    //      }
    //    }

    // on recupere tous les Lots
    // pour chaque lot, on recupère tous les documents horodate
    //    - scrutation du rep physique, si le document ou fichier de metadonnées n'existe plus => logger une erreur en base de données signalant l'absence d'un ou des deux fichiers.
    //    - Lecture du fichier JSON de metadonnées accompagnant le document
    //        - controle des métadonnées Obligatoire : CODE RND, UUID (en base)







    // if (documentDao != null) {
    //
    // final List<Document> lstDocument = documentDao.findAll();
    //
    // LotVersement lot1 = new LotVersement();
    // lot1.setNom("lot 1");
    // lot1.setUrlDepot("test");
    // lot1 = lotVersementDao.save(lot1);
    //
    // for (final Document document : lstDocument) {
    // document.setLot(lot1);
    // documentDao.save(document);
    // }
    //
    // }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void generateSip(final List<DocumentDto> lstDocumentDto) {
    if (preferencePath != null && lstDocumentDto != null && !lstDocumentDto.isEmpty()) {

      final Work work = new Work(null, new DiskImportContext(Prefs.getInstance(preferencePath)), null);

      final DiskImportContext dic = (DiskImportContext) work.getCreationContext();
      final DiskToDataObjectPackageImporter di = new DiskToDataObjectPackageImporter(lstDocumentDto, null);

      for (final String ip : dic.getAllowPatternList()) {
        di.addAllowPattern(ip);
      }

      try {
        di.doImport();
      } catch (final SEDALibException e) {
        e.printStackTrace();
      } catch (final InterruptedException e) {
        e.printStackTrace();
      }

      final Path pathOut = Paths.get("C:\\workspace_dory\\Docs\\arbo1_V20.zip");
      final ExportContext newExportContext = new ExportContext(Prefs.getInstance(preferencePath));
      work.setExportContext(newExportContext);
      work.getExportContext().setOnDiskOutput(pathOut.toString());

      work.setDataObjectPackage(di.getDataObjectPackage());

      work.getDataObjectPackage().regenerateContinuousIds();
      final ArchiveTransfer archiveTransfer = new ArchiveTransfer();

      work.getDataObjectPackage().setManagementMetadataXmlData(work.getExportContext().getManagementMetadataXmlData());
      archiveTransfer.setDataObjectPackage(work.getDataObjectPackage());
      archiveTransfer.setGlobalMetadata(work.getExportContext().getArchiveTransferGlobalMetadata());

      final ArchiveTransferToSIPExporter smm = new ArchiveTransferToSIPExporter(archiveTransfer);
      try {
        smm.doExportToSEDASIP(work.getExportContext().getOnDiskOutput(),
                              work.getExportContext().isHierarchicalArchiveUnits(),
                              work.getExportContext().isIndented());
      } catch (final SEDALibException | InterruptedException e) {
        SipGeneratorImpl.LOGGER.error(e.getMessage());
      }

    }

  }

}



