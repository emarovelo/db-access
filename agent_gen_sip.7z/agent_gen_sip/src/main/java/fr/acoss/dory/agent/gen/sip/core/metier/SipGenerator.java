package fr.acoss.dory.agent.gen.sip.core.metier;

import java.util.List;

import fr.acoss.dory.agent.gen.sip.core.modele.dto.DocumentDto;

/**
 * SIP generator class
 */
public interface SipGenerator {

  /**
   * @param lstDocumentDto
   *          : la liste des documents à intégrer dans le SIP
   */
  void generateSip(List<DocumentDto> lstDocumentDto);

}
