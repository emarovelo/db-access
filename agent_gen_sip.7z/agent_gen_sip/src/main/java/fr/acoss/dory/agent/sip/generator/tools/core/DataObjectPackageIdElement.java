package fr.acoss.dory.agent.sip.generator.tools.core;

import java.nio.file.Path;
import java.nio.file.Paths;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;

/**
 * The Class DataObjectPackageIdElement.
 * <p>
 * Class for SEDA elements objects in DataObjectPackage with an
 * inDataPackageObjectId (ArchiveUnit, DataObjectGroup...). This Id is used in XML
 * as SEDA elements attribute.
 * <p>These elements also can have on disk representation kept in onDiskPath if any.
 */
public class DataObjectPackageIdElement extends DataObjectPackageElement {

  /**
   * The id in DataObjectPackage.
   */
  protected String inDataPackageObjectId;

  /**
   * The on disk path.
   */
  protected Path onDiskPath;

  /**
   * Instantiates a new DataObjectPackage id element.
   */
  public DataObjectPackageIdElement() {
    this(null);
  }

  /**
   * Instantiates a new DataObjectPackage id element.
   *
   * @param dataObjectPackage the DataObjectPackage
   */
  public DataObjectPackageIdElement(final DataObjectPackage dataObjectPackage) {
    super(dataObjectPackage);
    inDataPackageObjectId = null;
  }

  /**
   * Gets the inDataPackageObjectId.
   *
   * @return the inDataPackageObjectId
   */
  public String getInDataObjectPackageId() {
    return inDataPackageObjectId;
  }

  /**
   * Sets the inDataPackageObjectId.
   *
   * @param inDataObjectPackageId the new inDataPackageObjectId
   */
  public void setInDataObjectPackageId(final String inDataObjectPackageId) {
    inDataPackageObjectId = inDataObjectPackageId;
  }

  /**
   * Gets the disk path where the DataObjectPackageIdElement is described or null.
   *
   * @return the disk path
   */
  @JsonIgnore
  public Path getOnDiskPath() {
    return onDiskPath;
  }

  /**
   * Sets the disk Path where the DataObjectPackageIdElement is described.
   *
   * @param onDiskPath the new on disk path
   */
  @JsonIgnore
  public void setOnDiskPath(final Path onDiskPath) {
    if (onDiskPath == null) {
      this.onDiskPath = null;
    } else {
      this.onDiskPath = onDiskPath.toAbsolutePath().normalize();
    }
  }

  /**
   * Gets the onDiskPath to string.
   *
   * @return the onDiskPath in String form
   */
  @JsonGetter("onDiskPath")
  public String getOnDiskPathToString() {
    if (onDiskPath == null) {
      return null;
    } else {
      return onDiskPath.toString();
    }
  }

  /**
   * Sets the onDiskPath from string.
   *
   * @param onDiskPathString the new onDiskPath in String form
   */
  @JsonSetter("onDiskPath")
  public void setOnDiskPathFromString(final String onDiskPathString) {
    if (onDiskPathString == null) {
      onDiskPath = null;
    } else {
      onDiskPath = Paths.get(onDiskPathString).toAbsolutePath().normalize();
    }
  }


}
