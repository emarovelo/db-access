package fr.acoss.dory.agent.gen.sip.core.metier.impl;

import java.io.File;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import fr.acoss.dory.agent.gen.sip.core.metier.FileStorage;

/**
 * Gestion de fichier(access,...)
 */
@Service
public class FileStorageImpl implements FileStorage {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(FileStorageImpl.class);

  /**
   * Permet de savoir si le fichier existe vraiment physiquement.
   * {@inheritDoc}
   */
  @Override
  public boolean exists(final String strPath) {
    FileStorageImpl.LOGGER.trace("verification de l'existance du fichier: " + strPath);
    boolean exists = false;

    if (strPath != null && !strPath.trim().isEmpty()) {

      try {
        final Path filePath = Paths.get(strPath);
        final File file = filePath.toFile();

        if (file != null && file.length() > 0) {
          exists = true;
        }

      } catch (final InvalidPathException | UnsupportedOperationException e) {
        FileStorageImpl.LOGGER.error("", e);
      }
    }
    return exists;
  }

}
