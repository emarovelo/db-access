package fr.acoss.dory.agent.sip.generator.taskscheduler;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import fr.acoss.dory.agent.sip.generator.metier.SipGenerator;

/**
 * Agent permettant la création de SIP
 */
@Component
public class ThreadPoolTaskSchedulerSipGen {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(ThreadPoolTaskSchedulerSipGen.class);

  /**
   * The preferences file name.
   */
  static public final String PREFERENCES_FILENAME = "preferences.properties";

  @Autowired
  private SipGenerator sipGenerator;

  @Autowired
  private ThreadPoolTaskScheduler taskScheduler;

  @Autowired
  private CronTrigger cronTrigger;

  /**
   * Initialisation du scheduler
   */
  @PostConstruct
  public void scheduleRunnableWithCronTrigger() {
    taskScheduler.schedule(new RunnableTask("Cron Trigger"), cronTrigger);
  }

  /**
   * La classe Runnable qui est appelee à chaque exceution du scheduler
   */
  class RunnableTask implements Runnable {

    private final String message;

    /**
     * Constructeur
     * 
     * @param message
     */
    public RunnableTask(final String message) {
      this.message = message;
    }

    @Override
    public void run() {

      final List<Path> lstPathDocument = new ArrayList<>();
      Path source = Paths.get("C:\\workspace_dory\\Docs\\arbo1\\user_story_0001.docx");
      lstPathDocument.add(source);
      source = Paths.get("C:\\workspace_dory\\Docs\\arbo1\\user_story_0004.docx");
      lstPathDocument.add(source);
      source = Paths.get("C:\\workspace_dory\\Docs\\arbo1\\user_story_0028.docx");
      lstPathDocument.add(source);
      sipGenerator.generateSip(lstPathDocument);

      LOGGER.info("Runnable Agent Generation SIP with " + message + " on thread " + Thread.currentThread().getName());
    }
  }
}
