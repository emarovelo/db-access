package fr.acoss.dory.agent.sip.generator.metier.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.acoss.dory.agent.sip.generator.data.Work;
import fr.acoss.dory.agent.sip.generator.metier.SipGenerator;
import fr.acoss.dory.agent.sip.generator.tools.core.ArchiveTransfer;
import fr.acoss.dory.agent.sip.generator.tools.importer.ArchiveTransferToSIPExporter;
import fr.acoss.dory.agent.sip.generator.tools.importer.DiskToDataObjectPackageImporter;
import fr.acoss.dory.agent.sip.generator.tools.parameters.DiskImportContext;
import fr.acoss.dory.agent.sip.generator.tools.parameters.ExportContext;
import fr.acoss.dory.agent.sip.generator.tools.parameters.Prefs;
import fr.acoss.dory.agent.sip.generator.tools.utils.SEDALibException;

/**
 * Couche métier de gestion de SIP
 */
@Service
public class SipGeneratorImpl implements SipGenerator {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(SipGeneratorImpl.class);

  /*
   * The preferences file name.
   */
  static public final String PREFERENCES_FILENAME = "preferences.properties";

  @Autowired
  private ResourceLoader resourceLoader;

  /*
   * Le path du fichier preferences.properties
   */
  private Path preferencePath;


  @PostConstruct
  private void postConstruct() {
    final Resource preferenceFileResource = resourceLoader.getResource("classpath:" + PREFERENCES_FILENAME);
    try {
      final File preferenceFile = preferenceFileResource.getFile();
      preferencePath = preferenceFile != null ? preferenceFile.toPath() : preferencePath;
    } catch (final IOException e1) {
    }
  }

  /**
   * Méthode appelee par le scheduler et qui permet de generer des SIP
   * Ces SIP sont créés à partir des documents qui sont préalablement déposés par doribackend et dont le statut est HOROTATE
   */
  @Override
  @Transactional
  public void generateSip(final List<Path> lstPathDocument) {

    if (preferencePath != null && lstPathDocument != null && !lstPathDocument.isEmpty()) {
      final Work work = new Work(null, new DiskImportContext(Prefs.getInstance(preferencePath)), null);

      final DiskImportContext dic = (DiskImportContext) work.getCreationContext();
      final DiskToDataObjectPackageImporter di = new DiskToDataObjectPackageImporter(lstPathDocument, null);
      for (final String ip : dic.getAllowPatternList()) {
        di.addAllowPattern(ip);
      }
      try {
        di.doImport();
      } catch (final SEDALibException e) {
        e.printStackTrace();
      } catch (final InterruptedException e) {
        e.printStackTrace();
      }

      final Path pathOut = Paths.get("C:\\workspace_dory\\Docs\\arbo1_V19.zip");
      final ExportContext newExportContext = new ExportContext(Prefs.getInstance(preferencePath));
      work.setExportContext(newExportContext);
      work.getExportContext().setOnDiskOutput(pathOut.toString());

      work.setDataObjectPackage(di.getDataObjectPackage());

      work.getDataObjectPackage().regenerateContinuousIds();
      final ArchiveTransfer archiveTransfer = new ArchiveTransfer();

      work.getDataObjectPackage().setManagementMetadataXmlData(work.getExportContext().getManagementMetadataXmlData());
      archiveTransfer.setDataObjectPackage(work.getDataObjectPackage());
      archiveTransfer.setGlobalMetadata(work.getExportContext().getArchiveTransferGlobalMetadata());

      final ArchiveTransferToSIPExporter smm = new ArchiveTransferToSIPExporter(archiveTransfer);
      try {
        smm.doExportToSEDASIP(work.getExportContext().getOnDiskOutput(),
                              work.getExportContext().isHierarchicalArchiveUnits(),
                              work.getExportContext().isIndented());
      } catch (final SEDALibException | InterruptedException e) {
        SipGeneratorImpl.LOGGER.error(e.getMessage());
      }
    }

  }



}
