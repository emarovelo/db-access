package fr.acoss.dory.agent.gen.sip.core.tools.metadata.namedtype;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

/**
 * Classe DataType
 */
@Validated
public class DataType   {
  private String name = null;

  private String type = null;

  private String value = null;

  /**
   * Le nom du metadata
   * @return name
   **/
  public String getName() {
    return name;
  }

  /**
   * Modifie le nom du metadata
   * 
   * @param name
   */
  public void setName(final String name) {
    this.name = name;
  }

  /**
   * Le type du metadata
   * @return type
   **/
  public String getType() {
    return type;
  }

  /**
   * Modifie le type du metadata
   * 
   * @param type
   */
  public void setType(final String type) {
    this.type = type;
  }

  /**
   * La valeur du metadata
   * @return value
   **/
  public String getValue() {
    return value;
  }

  /**
   * Modifie la valeur du metadata
   * 
   * @param value
   */
  public void setValue(final String value) {
    this.value = value;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final DataType dataType = (DataType) o;
    return Objects.equals(name, dataType.name) &&
        Objects.equals(type, dataType.type) &&
        Objects.equals(value, dataType.value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, type, value);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class DataType {\n");

    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

