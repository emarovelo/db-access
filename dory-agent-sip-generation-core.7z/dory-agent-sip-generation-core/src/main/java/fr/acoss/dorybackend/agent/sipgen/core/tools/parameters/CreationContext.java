package fr.acoss.dorybackend.agent.sipgen.core.tools.parameters;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 * The Class CreationContext.
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({@JsonSubTypes.Type(value = DiskImportContext.class, name = "DiskImportContext")})
public class CreationContext {

  /**
   * The on disk input.
   */
  String onDiskInput;


  /**
   * Instantiates a new creation context.
   */
  public CreationContext() {
    this(null, null);
  }

  /**
   * Instantiates a new creation context from preferences.
   */
  public CreationContext(final Prefs prefs) {
    onDiskInput = null;
  }

  /**
   * Instantiates a new creation context.
   *
   * @param onDiskInput the on disk input
   * @param workDir     the work dir
   */
  public CreationContext(final String onDiskInput, final String workDir) {
    this.onDiskInput = onDiskInput;
  }

  // Getters and setters
  /**
   * Gets the on disk input.
   *
   * @return the on disk input
   */
  public String getOnDiskInput() {
    return onDiskInput;
  }

  /**
   * Sets the on disk input.
   *
   * @param onDiskInput the new on disk input
   */
  public void setOnDiskInput(final String onDiskInput) {
    this.onDiskInput = onDiskInput;
  }
}