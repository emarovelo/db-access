package fr.acoss.dorybackend.agent.sipgen.core.tools;

import javax.xml.stream.XMLStreamException;

import com.fasterxml.jackson.annotation.JsonIgnore;

import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.SEDALibException;
import fr.acoss.dorybackend.agent.sipgen.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class ArchiveTransfer
 * <p>
 * Class for the SEDA SIP manifest (document XML ArchiveTransfer in SEDA
 * standard) content management. It contains all the elements declared in
 * manifest, but also objects to manage the structure.
 * <p>
 * It uses the generic DataObjectPackage class for DataObjet and ArchiveUnit
 * structure.
 */
public class ArchiveTransfer {

  // SEDA elements
  /**
   * The archive transfer global metadata.
   */
  private GlobalMetadata globalMetadata;

  /**
   * The inner DataObjects and ArchiveUnit structure.
   */
  private DataObjectPackage dataObjectPackage;

  // Constructors

  /**
   * Instantiates a new archive transfer. Used for json deserialization.
   */
  public ArchiveTransfer() {
    globalMetadata = null;
    setDataObjectPackage(new DataObjectPackage());
  }

  // Methods

  /**
   * Gets the summary description of ArchiveTransfer. It list the number of
   * ArchiveUnits, DataObjectGroup, BinaryDataObject (with size in bytes) and
   * PhysicalDatObject
   *
   * @return the description String
   */
  @JsonIgnore
  public String getDescription() {
    return "ArchiveTransfer\n" + getDataObjectPackage().getDescription();
  }

  // SEDA XML exporter

  /**
   * Export start document of SEDA ArchiveTransfer XML.
   *
   * @param xmlWriter the SEDAXMLStreamWriter generating the SEDA manifest
   * @throws SEDALibException if the XML can't be written
   */

  private void exportStartDocument(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeStartDocument();
      xmlWriter.writeStartElement("ArchiveTransfer");
      xmlWriter.writeNamespace("xlink", "http://www.w3.org/1999/xlink");
      xmlWriter.writeNamespace("pr", "info:lc/xmlns/premis-v2");
      xmlWriter.writeDefaultNamespace("fr:gouv:culture:archivesdefrance:seda:v2.1");
      xmlWriter.writeNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
      xmlWriter.writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "schemaLocation",
          "fr:gouv:culture:archivesdefrance:seda:v2.1 seda-2.1-main.xsd");
      xmlWriter.setXmlId(true);
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML du début du manifest\n->" + e.getMessage());
    }
  }

  /**
   * Export header, with global metadata, of SEDA ArchiveTransfer XML.
   *
   * @param xmlWriter the SEDAXMLStreamWriter generating the SEDA manifest
   * @throws SEDALibException if the XML can't be written
   */

  private void exportHeader(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeElementValueIfNotEmpty("Comment", globalMetadata.comment);
      if (globalMetadata.isNowFlag()) {
        globalMetadata.date = SEDAXMLStreamWriter.getStringFromDateTime(null);
      }
      xmlWriter.writeElementValueIfNotEmpty("Date", globalMetadata.date);
      xmlWriter.writeElementValueIfNotEmpty("MessageIdentifier", globalMetadata.messageIdentifier);
      xmlWriter.writeElementValueIfNotEmpty("ArchivalAgreement", globalMetadata.archivalAgreement);
      xmlWriter.writeRawXMLBlockIfNotEmpty(globalMetadata.codeListVersionsXmlData);
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML d'entête du manifest\n->" + e.getMessage());
    }
  }

  /**
   * Export footer of manifest, after ArchiveTransfer.
   *
   * @param xmlWriter the SEDAXMLStreamWriter generating the SEDA manifest
   * @throws SEDALibException if the XML can't be written
   */

  private void exportFooter(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeElementValueIfNotEmpty("TransferRequestReplyIdentifier",
                                            globalMetadata.transferRequestReplyIdentifier);
      xmlWriter.writeStartElement("ArchivalAgency");
      xmlWriter.writeElementValue("Identifier", globalMetadata.archivalAgencyIdentifier);
      xmlWriter.writeRawXMLBlockIfNotEmpty(globalMetadata.transferringAgencyOrganizationDescriptiveMetadataXmlData);
      xmlWriter.writeEndElement();
      xmlWriter.writeStartElement("TransferringAgency");
      xmlWriter.writeElementValue("Identifier", globalMetadata.transferringAgencyIdentifier);
      xmlWriter.writeRawXMLBlockIfNotEmpty(globalMetadata.transferringAgencyOrganizationDescriptiveMetadataXmlData);
      xmlWriter.writeEndElement();
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML de la fin du manifest\n->" + e.getMessage());
    }
  }

  /**
   * Export end document.
   *
   * @param xmlWriter the SEDAXMLStreamWriter generating the SEDA manifest
   * @throws SEDALibException if the XML can't be written
   */
  private void exportEndDocument(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeEndElement();
      xmlWriter.writeEndDocument();
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML de la cloture du manifest\n->" + e.getMessage());
    }
  }

  /**
   * Export the whole structure in XML SEDA Manifest.
   *
   * @param xmlWriter             the SEDAXMLStreamWriter generating the SEDA manifest
   * @param imbricateFlag         indicates if the manifest ArchiveUnits are to be
   *                              exported in imbricate mode (true) or in flat mode
   *                              (false)
   * @throws SEDALibException     if the XML can't be written
   * @throws InterruptedException if export process is interrupted
   */
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter, final boolean imbricateFlag)
      throws SEDALibException, InterruptedException {
    exportStartDocument(xmlWriter);
    exportHeader(xmlWriter);
    dataObjectPackage.toSedaXml(xmlWriter, imbricateFlag);
    exportFooter(xmlWriter);
    exportEndDocument(xmlWriter);

  }

  // Getters and setters

  /**
   * Gets the SIP context.
   *
   * @return the archiveTransfer context GlobalMetadata
   */
  public GlobalMetadata getGlobalMetadata() {
    return globalMetadata;
  }

  /**
   * Sets the SIP context.
   *
   * @param globalMetadata the archiveTransfer context GlobalMetadata
   */
  public void setGlobalMetadata(final GlobalMetadata globalMetadata) {
    this.globalMetadata = globalMetadata;
  }

  /**
   * Gets the DataObjectPackage.
   *
   * @return the DataObjectPackage
   */
  public DataObjectPackage getDataObjectPackage() {
    return dataObjectPackage;
  }

  /**
   * Sets the DataObjectPackage.
   *
   * @param dataObjectPackage the new DataObjectPackage
   */
  public void setDataObjectPackage(final DataObjectPackage dataObjectPackage) {
    this.dataObjectPackage = dataObjectPackage;
  }
}