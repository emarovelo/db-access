package fr.acoss.dorybackend.agent.sipgen.core.tools;

import org.springframework.beans.factory.annotation.Value;

/**
 * The Class GlobalMetadata.
 * <p>
 * Class for the global metadata read from or used to generate a SEDA SIP
 * Manifest (MessageIdentifier, Comment...). These metadata are either in the
 * header before the DataObjectPackage or at the end of the ArchiveTransfer.
 */
public class GlobalMetadata {

  // SEDA elements
  // Before DataObjectPackage

  /**
   * The comment.
   */
  @Value("${exportContext.globalMetadata.comment}")
  public String comment;

  /**
   * The date.
   */
  @Value("${exportContext.globalMetadata.date}")
  public String date;

  /**
   * The message identifier.
   */
  @Value("${exportContext.globalMetadata.messageIdentifier}")
  public String messageIdentifier;

  /**
   * The now flag.
   */
  @Value("${exportContext.globalMetadata.nowFlag:true}")
  public boolean nowFlag;



  // Signature
  // - signature of xml content not supported

  /**
   * The archival agreement.
   */
  @Value("${exportContext.globalMetadata.archivalAgreement}")
  public String archivalAgreement;

  /**
   * The code list versions xml data.
   */
  @Value("${exportContext.globalMetadata.codeListVersionsXmlData}")
  public String codeListVersionsXmlData;

  // After DataObjectPackage

  // RelatedTransferReference
  // - reference to other transfers not supported

  /**
   * The transfer request reply identifier.
   */
  @Value("${exportContext.globalMetadata.transferRequestReplyIdentifier}")
  public String transferRequestReplyIdentifier;

  /**
   * The archival agency identifier.
   */
  @Value("${exportContext.globalMetadata.archivalAgencyIdentifier}")
  public String archivalAgencyIdentifier;

  /**
   * The archival agency organization descriptive metadata.
   */
  @Value("${exportContext.globalMetadata.archivalAgencyOrganizationDescriptiveMetadataXmlData}")
  public String archivalAgencyOrganizationDescriptiveMetadataXmlData;

  /**
   * The transferring agency identifier.
   */
  @Value("${exportContext.globalMetadata.transferringAgencyIdentifier}")
  public String transferringAgencyIdentifier;

  /**
   * The transferring agency organization descriptive metadata.
   */
  @Value("${exportContext.globalMetadata.transferringAgencyOrganizationDescriptiveMetadataXmlData}")
  public String transferringAgencyOrganizationDescriptiveMetadataXmlData;

  // Constructors

  /**
   * Instantiates a new global metadata.
   */
  public GlobalMetadata() {
  }

  /**
   * Checks if is now flag.
   *
   * @return true, if is now flag
   */
  public boolean isNowFlag() {
    return nowFlag;
  }

  /**
   * Sets the now flag.
   *
   * @param nowFlag the new now flag
   */
  public void setNowFlag(final boolean nowFlag) {
    this.nowFlag = nowFlag;
  }
}
