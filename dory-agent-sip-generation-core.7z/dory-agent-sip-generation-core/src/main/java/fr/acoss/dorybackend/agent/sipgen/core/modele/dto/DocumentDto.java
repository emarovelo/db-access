package fr.acoss.dorybackend.agent.sipgen.core.modele.dto;

import java.util.Map;
import java.util.Objects;

import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.DataType;

/**
 * DocumentDto : classe qui represente un Document utilisé par le Core du generateur de SIP
 */
public class DocumentDto   {

  /*
   * Identifiant du document
   */
  private Long id;

  /**
   * Le UUID du document
   */
  private String uuid = null;

  /**
   * Le chemin du fichier où se trouve le document
   */
  private String pathDocument = null;

  /**
   * Le hash scellé du document
   */
  private String hashScelle = null;

  /**
   * Le bloc horodaté du document
   */
  private String blocHorodate = null;

  /**
   * Le profil d'archive unit du document
   */
  private String archiveUnitProfile = null;

  /**
   * La valeur de l'élément AppraisalRule
   */
  private String appraisalRule = null;

  /**
   * Les métadonnées associées au document
   */
  Map<String, DataType> lstMetadonnees = null;


  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  public DocumentDto uuid(final String uuid) {
    this.uuid = uuid;
    return this;
  }

  /**
   * uuid du document
   * @return uuid
   **/
  public String getUuid() {
    return uuid;
  }

  public void setUuid(final String uuid) {
    this.uuid = uuid;
  }

  public DocumentDto pathDocument(final String pathDocument) {
    this.pathDocument = pathDocument;
    return this;
  }

  /**
   * L url de depot du document
   * @return pathDocument
   **/
  public String getPathDocument() {
    return pathDocument;
  }

  public void setPathDocument(final String pathDocument) {
    this.pathDocument = pathDocument;
  }

  public DocumentDto hashScelle(final String hashScelle) {
    this.hashScelle = hashScelle;
    return this;
  }

  /**
   * Hash scellé du document
   * @return hashScelle
   **/
  public String getHashScelle() {
    return hashScelle;
  }

  public void setHashScelle(final String hashScelle) {
    this.hashScelle = hashScelle;
  }

  public DocumentDto blocHorodate(final String blocHorodate) {
    this.blocHorodate = blocHorodate;
    return this;
  }

  /**
   * Bloc horodate du document
   * @return blocHorodate
   **/
  public String getBlocHorodate() {
    return blocHorodate;
  }

  public void setBlocHorodate(final String blocHorodate) {
    this.blocHorodate = blocHorodate;
  }

  /**
   * @return the lstMetadonnees
   */
  public Map<String, DataType> getLstMetadonnees() {
    return lstMetadonnees;
  }

  /**
   * @param lstMetadonnees
   *          the lstMetadonnees to set
   */
  public void setLstMetadonnees(final Map<String, DataType> lstMetadonnees) {
    this.lstMetadonnees = lstMetadonnees;
  }

  /**
   * @return the archiveUnitProfile
   */
  public String getArchiveUnitProfile() {
    return archiveUnitProfile;
  }


  /**
   * @param archiveUnitProfile
   *          the archiveUnitProfile to set
   */
  public void setArchiveUnitProfile(final String archiveUnitProfile) {
    this.archiveUnitProfile = archiveUnitProfile;
  }

  /**
   * @return the appraisalRule
   */
  public String getAppraisalRule() {
    return appraisalRule;
  }

  /**
   * @param appraisalRule
   *          the appraisalRule to set
   */
  public void setAppraisalRule(final String appraisalRule) {
    this.appraisalRule = appraisalRule;
  }

  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final DocumentDto documentType = (DocumentDto) o;
    return Objects.equals(uuid, documentType.uuid) &&
        Objects.equals(pathDocument, documentType.pathDocument) &&
        Objects.equals(hashScelle, documentType.hashScelle) &&
        Objects.equals(blocHorodate, documentType.blocHorodate) &&
        Objects.equals(archiveUnitProfile, documentType.archiveUnitProfile);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, pathDocument, hashScelle, blocHorodate, archiveUnitProfile);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class DocumentType {\n");

    sb.append("    uuid: ").append(toIndentedString(uuid)).append("\n");
    sb.append("    pathDocument: ").append(toIndentedString(pathDocument)).append("\n");
    sb.append("    hashScelle: ").append(toIndentedString(hashScelle)).append("\n");
    sb.append("    blocHorodate: ").append(toIndentedString(blocHorodate)).append("\n");
    sb.append("    archiveUnitProfile: ").append(toIndentedString(archiveUnitProfile)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

