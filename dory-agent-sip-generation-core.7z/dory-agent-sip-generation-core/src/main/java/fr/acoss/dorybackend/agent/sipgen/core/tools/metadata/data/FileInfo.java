package fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.data;

import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.LinkedHashMap;

import javax.xml.bind.DatatypeConverter;
import javax.xml.stream.XMLStreamException;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;

import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.SEDAMetadata;
import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.SEDALibException;
import fr.acoss.dorybackend.agent.sipgen.core.tools.xml.SEDAXMLEventReader;
import fr.acoss.dorybackend.agent.sipgen.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class FileInfo.
 * <p>
 * Class for SEDA element FileInfo.
 * <p>
 * A BinaryDataObject metadata.
 * <p>
 * Standard quote: "Propriétés techniques génériques du fichier (nom d’origine,
 * logiciel de création, système d’exploitation de création)"
 */
public class FileInfo extends SEDAMetadata {

  // SEDA elements

  /**
   * The filename.
   */
  public String filename;

  /**
   * The creating application name.
   */
  public String creatingApplicationName;

  /**
   * The creating application version.
   */
  public String creatingApplicationVersion;

  /**
   * The creation date by application.
   */
  public LocalDateTime dateCreatedByApplication;

  /**
   * The creating os.
   */
  public String creatingOs;

  /**
   * The creating os version.
   */
  public String creatingOsVersion;

  /**
   * The last modified.
   */
  public FileTime lastModified;

  // Constructors

  /**
   * Instantiates a new file info.
   */
  public FileInfo() {
    this(null, null, null, null, null, null, null);
  }

  /**
   * Instantiates a new file info.
   *
   * @param filename                   the filename
   * @param creatingApplicationName    the creating application name
   * @param creatingApplicationVersion the creating application version
   * @param dateCreatedByApplication   the creation date by application
   * @param creatingOs                 the creating os
   * @param creatingOsVersion          the creating os version
   * @param lastModified               the last modified
   */
  public FileInfo(final String filename, final String creatingApplicationName, final String creatingApplicationVersion,
                  final LocalDateTime dateCreatedByApplication, final String creatingOs, final String creatingOsVersion, final FileTime lastModified) {
    this.filename = filename;
    this.creatingApplicationName = creatingApplicationName;
    this.creatingApplicationVersion = creatingApplicationVersion;
    this.dateCreatedByApplication = dateCreatedByApplication;
    this.creatingOs = creatingOs;
    this.creatingOsVersion = creatingOsVersion;
    this.lastModified = lastModified;
  }

  @Override
  public String getXmlElementName() {
    return "FileInfo";
  }

  /* (non-Javadoc)
   * @see fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toSedaXml(fr.gouv.vitam.tools.sedalib.xml.SEDAXMLStreamWriter)
   */
  @SuppressWarnings("static-access")
  @Override
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      xmlWriter.writeStartElement("FileInfo");
      xmlWriter.writeElementValueIfNotEmpty("Filename", filename);
      xmlWriter.writeElementValueIfNotEmpty("CreatingApplicationName", creatingApplicationName);
      xmlWriter.writeElementValueIfNotEmpty("CreatingApplicationVersion", creatingApplicationVersion);
      if (dateCreatedByApplication != null) {
        xmlWriter.writeElementValue("DateCreatedByApplication", SEDAXMLStreamWriter.getStringFromDateTime(dateCreatedByApplication));
      }
      xmlWriter.writeElementValueIfNotEmpty("CreatingOs", creatingOs);
      xmlWriter.writeElementValueIfNotEmpty("CreatingOsVersion", creatingOsVersion);
      if (lastModified != null) {
        xmlWriter.writeElementValueIfNotEmpty("LastModified", lastModified.toString());
      }
      xmlWriter.writeEndElement();
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML dans un élément FileInfo\n->" + e.getMessage());
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toCsvList()
   */
  @Override
  public LinkedHashMap<String, String> toCsvList() throws SEDALibException {
    throw new SEDALibException("Not implemented");
  }

  /**
   * Import the metadata content in XML expected form from the SEDA Manifest.
   *
   * @param xmlReader the SEDAXMLEventReader reading the SEDA manifest
   * @return true, if it finds something convenient, false if not
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not respected, for example
   */
  @Override
  public boolean fillFromSedaXml(final SEDAXMLEventReader xmlReader) throws SEDALibException {
    String tmp;
    try {
      if (xmlReader.nextBlockIfNamed("FileInfo")) {
        filename = xmlReader.nextMandatoryValue("Filename");
        creatingApplicationName = xmlReader.nextValueIfNamed("CreatingApplicationName");
        creatingApplicationVersion = xmlReader.nextValueIfNamed("CreatingApplicationVersion");
        tmp = xmlReader.nextValueIfNamed("DateCreatedByApplication");
        if (tmp != null) {
          dateCreatedByApplication = SEDAXMLEventReader.getDateTimeFromString(tmp);
        }
        creatingOs = xmlReader.nextValueIfNamed("CreatingOs");
        creatingOsVersion = xmlReader.nextValueIfNamed("CreatingOsVersion");
        tmp = xmlReader.nextValueIfNamed("LastModified");
        if (tmp != null) {
          final Calendar cal = DatatypeConverter.parseDateTime(tmp);
          lastModified = FileTime.fromMillis(cal.toInstant().toEpochMilli());
        }
        xmlReader.endBlockNamed("FileInfo");
      } else {
        return false;
      }
    } catch (XMLStreamException | IllegalArgumentException | SEDALibException e) {
      throw new SEDALibException("Erreur de lecture XML dans un élément de type FileInfo\n->" + e.getMessage());
    }
    return true;
  }

  // Getters and setters

  /**
   * Gets the last modified in long.
   *
   * @return the last modified in long
   */
  @JsonGetter("lastModified")
  public long getLastModifiedInLong() {
    if (lastModified != null) {
      return lastModified.toMillis();
    } else {
      return 0;
    }
  }

  /**
   * Sets the last modified from long.
   *
   * @param fileLastModifiedTimeLong the new last modified from long
   */
  @JsonSetter("lastModified")
  public void setLastModifiedFromLong(final long fileLastModifiedTimeLong) {
    if (fileLastModifiedTimeLong == 0) {
      lastModified = null;
    } else {
      lastModified = FileTime.fromMillis(fileLastModifiedTimeLong);
    }
  }
}
