package fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.management;

import java.util.ArrayList;
import java.util.List;

import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.RuleType;

/**
 * The Class StorageRule.
 * <p>
 * Class for SEDA element StorageRule
 * <p>
 * A management ArchiveUnit metadata.
 * <p>
 * Standard quote: "Gestion de la durée d’utilité courante"
 */
public class StorageRule extends RuleType {

  /** The final action list. */
  static protected List<String> finalActionList;

  static {
    finalActionList = new ArrayList<>();
    finalActionList.add("RestrictAccess");
    finalActionList.add("Transfer");
    finalActionList.add("Copy");
  }

  @Override
  public List<String> getFinalActionList() {
    return finalActionList;
  }
}
