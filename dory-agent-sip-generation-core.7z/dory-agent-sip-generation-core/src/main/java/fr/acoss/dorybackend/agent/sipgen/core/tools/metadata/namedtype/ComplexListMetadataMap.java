package fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ComplexListMetadataMap {
  boolean isExpandable() default false;
}
