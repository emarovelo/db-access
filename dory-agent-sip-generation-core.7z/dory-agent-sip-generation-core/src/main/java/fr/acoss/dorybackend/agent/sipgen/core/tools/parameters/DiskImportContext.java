package fr.acoss.dorybackend.agent.sipgen.core.tools.parameters;

/**
 * The Class DiskImportContext.
 */
public class DiskImportContext extends CreationContext {



  /**
   * The No link flag.
   */
  private boolean noLinkFlag;

  /**
   * Instantiates a new disk import context.
   *
   * @param prefs
   *          the prefs
   */
  public DiskImportContext(final Prefs prefs) {
    super(prefs);
    noLinkFlag = Boolean.parseBoolean(prefs.getPrefProperties().getProperty("importContext.disk.noLinkFlag", "false"));
  }

  // Getters and setters

  /**
   * Is no link flag boolean.
   *
   * @return the boolean
   */
  public boolean isNoLinkFlag() {
    return noLinkFlag;
  }

  /**
   * Sets no link flag.
   *
   * @param noLinkFlag the no link flag
   */
  public void setNoLinkFlag(final boolean noLinkFlag) {
    this.noLinkFlag = noLinkFlag;
  }

}
