package fr.acoss.dorybackend.agent.sipgen.core.main.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import fr.acoss.dorybackend.agent.sipgen.core.data.Work;
import fr.acoss.dorybackend.agent.sipgen.core.main.SipGenerator;
import fr.acoss.dorybackend.agent.sipgen.core.modele.dto.DocumentDto;
import fr.acoss.dorybackend.agent.sipgen.core.tools.ArchiveTransfer;
import fr.acoss.dorybackend.agent.sipgen.core.tools.importer.ArchiveTransferToSIPExporter;
import fr.acoss.dorybackend.agent.sipgen.core.tools.importer.DiskToDataObjectPackageImporter;
import fr.acoss.dorybackend.agent.sipgen.core.tools.parameters.DiskImportContext;
import fr.acoss.dorybackend.agent.sipgen.core.tools.parameters.ExportContext;
import fr.acoss.dorybackend.agent.sipgen.core.tools.parameters.Prefs;
import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.FileHelper;
import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.MetadataHelper;
import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.SEDALibException;
import fr.acoss.dorybackend.core.layer.metier.DocumentMetier;
import fr.acoss.dorybackend.core.layer.metier.LotVersementMetier;
import fr.acoss.dorybackend.core.layer.metier.SipMetier;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheDocumentType;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheLotVersementType;
import fr.acoss.dorybackend.modele.dto.DocumentType;
import fr.acoss.dorybackend.modele.dto.LogDocumentType;
import fr.acoss.dorybackend.modele.dto.LotVersementType;
import fr.acoss.dorybackend.modele.dto.StatutDocumentType;



/**
 * La classe main qui permet de generer des SIP depuis les données en base
 */
@Service
public class SipGeneratorImpl implements SipGenerator {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(SipGeneratorImpl.class);

  /**
   * Prefixe de la valeur du archive unit profile
   */
  public static final String STR_PREFIXE_ARCHIVE_UNIT_PROFILE = "AUP-";

  /**
   * Prefixe de la valeur de la règle de AppraisalRule
   */
  public static final String STR_PREFIXE_MANAGEMENT_APPRAISALRULE = "APP-";

  /**
   * Le format du fichier SIP (contenant le repertoire content et le fichier manifest)
   */
  public static final String STR_EXTENTION_SIP_FILE = ".zip";

  /**
   * Le statut d'un document quand erreur lors de son integration dans un SIP
   */
  public static String STR_CODE_STATUT_DOC_ERREUR_SIP = "ERREUR_SIP";

  public static String STR_CODE_STATUT_DOC_INTEGRATION_SIP_EN_COURS = "INTEGRATION_SIP_EN_COURS";

  public static String STR_CODE_STATUT_HORODATE = "HORODATE";

  public static String STR_DOC_ERREUR_INTEGRATION_SIP = "erreur";

  public static String STR_DOC_VALIDE_INTEGRATION_SIP = "valide";

  /**
   * Le nombre de lot de versement par page lors de la recherche
   */
  public static int NB_LOT_VERSEMENT_PAR_PAGE = 100;

  /**
   * Le nombre de maximun de documents dans un sip
   */
  @Value("${sip.taille.documents:100}")
  private int nbMaxDocsDansSip;

  /**
   * L'url de dépôt des SIP
   */
  @Value("${dorybackend.sas.vitam}")
  private String sasVitam;

  /**
   * Service provenant de la librairie database-access permettant de manipuler les documents (CRUD)
   */
  @Autowired
  private DocumentMetier documentMetier;

  /**
   * Service provenant de la librairie database-access permettant de manipuler les lot de versement (CRUD)
   */
  @Autowired
  private LotVersementMetier lotVersementMetier;

  /**
   * Service provenant de la librairie database-access permettant de manipuler les sip (CRUD)
   */
  @Autowired
  private SipMetier sipMetier;

  /*
   * The preferences file name.
   */
  static public final String PREFERENCES_FILENAME = "preferences.properties";

  @Autowired
  private ResourceLoader resourceLoader;

  /*
   * Le path du fichier preferences.properties
   */
  private Path preferencePath;

  @PostConstruct
  private void postConstruct() {
    final Resource preferenceFileResource = resourceLoader.getResource("classpath:" + PREFERENCES_FILENAME);
    try {
      final File preferenceFile = preferenceFileResource.getFile();
      preferencePath = preferenceFile != null ? preferenceFile.toPath() : preferencePath;
    } catch (final IOException e1) {
    }
  }

  @Override
  public void doTask() {
    /*
     * 1) En utilisant les services fournis par la librairie database-acces,
     * rechercher tous les lots de versements au statut « HORODATE »
     * 2) Pour chaque lot de versement au statut « HORODATE »
     * a. Rechercher (en utilisant la librairie database-access) par paquet de X (X étant le nombre de documents maximum permis pour la construction d’un SIP) les documents au statut « HORODATE » du lot de versement courant.
     * i. Pour chaque paquet de documents, enlever tous ceux qui ne remplissent pas toutes les conditions nécessaires pour être intégrer dans un SIP.
     * Les conditions sont les suivantes :
     *  Présence des métadonnées obligatoires : Code RND et l’id d’archivage.
     *  Le fichier binaire associé au document est présent physiquement.
     *  Le fichier des métadonnées est présent physiquement.
     * ii. Mettre à jour le statut des documents d’un paquet qui ne remplissent pas toutes les conditions nécessaires pour être intégrer dans un SIP à « ERREUR ».
     * iii. Mettre à jour le statut des documents valides à « CREATION_SIP ». Tracer tout changement de statut d’un document dans la table hi_historique_statut_document en utilisant la librairie database-access.
     * iv. Donner au moteur de génération de SIP (module core) tous les documents valides. Une fois le fichier .zip créé physiquement dans le sas Dory, ce moteur de génération de SIP nous retourne tous les documents qui ont bien été intégrés dans le fichier .zip fraichement créé.
     * v. Mettre à jour le statut des documents qui n’ont pas pu être intégrer dans le SIP à « ERREUR » et les autres à « INTEGRE_SIP ».
     * vi. Créer un enregistrement dans la table si_sip, puis ajouter une relation entre le sip et le lot de versement courant. Ajouter aussi les relations entre le SIP fraichement créer et les documents qui ont le statut « INTEGRE_SIP ».
     */


    final StatutDocumentType statutDocumentTypeErreur = new StatutDocumentType();
    statutDocumentTypeErreur.code(STR_CODE_STATUT_DOC_ERREUR_SIP);

    final StatutDocumentType statutDocumentTypeCreationSip = new StatutDocumentType();
    statutDocumentTypeCreationSip.code(STR_CODE_STATUT_DOC_INTEGRATION_SIP_EN_COURS);

    /*
     * En utilisant les services fournis par la librairie database-acces,
     * rechercher par paquets de NB_LOT_VERSEMENT_PAR_PAGE les lots de versements au statut « HORODATE »
     */
    final CriteresRechercheLotVersementType criteresRechercheLotVersementType = new CriteresRechercheLotVersementType();
    criteresRechercheLotVersementType.setSize(NB_LOT_VERSEMENT_PAR_PAGE);
    criteresRechercheLotVersementType.setCodeStatutLotVersement(STR_CODE_STATUT_HORODATE);
    List<LotVersementType> lstLotVersement = new ArrayList<>();
    Integer currentPage = new Integer(0);
    while (currentPage > -1) {
      criteresRechercheLotVersementType.setCurrentPage(currentPage);
      lstLotVersement = lotVersementMetier.rechercherLots(criteresRechercheLotVersementType);

      /*
       * Pour chaque lot de versement du paquet courant,
       */
      for (final LotVersementType lotVersementType : lstLotVersement) {
        if (lotVersementType != null && lotVersementType.getId() != null) {

          // Generation de SIP pour le lot de versement courant
          generateDocsFromLotVersement(lotVersementType.getId(), statutDocumentTypeErreur, statutDocumentTypeCreationSip);
        }
      }

      // si la taille de la liste est inférieure à celle qu'on a voulu alors, il ne reste plus de données à recupérer
      if (lstLotVersement != null && lstLotVersement.size() < NB_LOT_VERSEMENT_PAR_PAGE) {
        currentPage = -1;
      } else {
        currentPage++;
      }
    }
  }

  /**
   * Generation de zéro ou plusieurs SIP à partir des documents du lot de versement
   * 
   * @param idLotVersement
   * @param statutDocumentTypeErreur
   * @param statutDocumentTypeCreationSip
   */
  private void generateDocsFromLotVersement(final Long idLotVersement, final StatutDocumentType statutDocumentTypeErreur,
                                            final StatutDocumentType statutDocumentTypeCreationSip) {

    // recuperation des documents appartenant au lot de versement et dont le statut est HORODATE par paquet de nbMaxDocsDansSip docs.
    final Map<Integer, List<DocumentType>> documents = rechercherDocuments(idLotVersement, STR_CODE_STATUT_HORODATE);

    // création de SIP pour chaque paquet de documents
    if (documents != null && !documents.isEmpty()) {
      documents.forEach((page, lstDocument) -> doSipGenerationFromDocs(lstDocument, statutDocumentTypeErreur, statutDocumentTypeCreationSip));
    }

  }

  /**
   * Permet de generer un SIP à partir d'une liste de document.
   * Avant de crérer le SIP, une verification est faite sur chaque document.
   * On enleve tous les documents qui ne verifient pas les conditions necessaires pour être intégrer dans un SIP.
   * Le statut des documents non valides devient ERREUR.
   * Le statut des documents réellement intégrés dans le SIP devient INTEGRE_SIP
   * 
   * @param lstDocument
   * @param statutDocumentTypeErreur
   * @param statutDocumentTypeCreationSip
   * @return
   */
  private void doSipGenerationFromDocs(final List<DocumentType> lstDocument, final StatutDocumentType statutDocumentTypeErreur,
                                       final StatutDocumentType statutDocumentTypeCreationSip) {

    /*
     * Premier filtrage:
     * - Présence des métadonnées obligatoires : Code RND et l’id d’archivage.
     * - Le fichier binaire associé au document est présent physiquement.
     * - Le fichier des métadonnées est présent physiquement.
     */
    List<DocumentDto> lstDocumentsEnErreur = null;
    List<DocumentDto> lstDocumentsValides = null;
    List<DocumentDto> lstDocumentReellementIntegreDansSIP = null;

    final Map<String, List<DocumentDto>> mapEtatDocuments = checkAndPrepareDocsBeforeSipGen(lstDocument);

    if (mapEtatDocuments != null) {
      lstDocumentsEnErreur = mapEtatDocuments.get(STR_DOC_ERREUR_INTEGRATION_SIP);
      lstDocumentsValides = mapEtatDocuments.get(STR_DOC_VALIDE_INTEGRATION_SIP);
    }

    // TODO
    // ajout gestion des exceptions

    /*
     * Appel au moteur de generation de SIP
     * On stocke la liste de documents réellement intégrés dans un SIP. Après le passage du moteur de genération de SIP.
     */
    String sipName = null;
    String strPathSipOut = null;
    if (lstDocumentsValides != null && !lstDocumentsValides.isEmpty()) {
      sipName = lstDocumentsValides.get(0).getUuid();
      strPathSipOut = sasVitam + File.separator + lstDocumentsValides.get(0).getUuid() + STR_EXTENTION_SIP_FILE;
      lstDocumentReellementIntegreDansSIP = generateSip(sipName, lstDocumentsValides, strPathSipOut);
    }

    // on va recuperer la liste de documents qui n'ont pas pu être intégrés dans le SIP (dans le fichier .zip)
    if (lstDocumentsValides != null && lstDocumentReellementIntegreDansSIP != null) {
      // ici lstDocumentsValides va maintenant contenir les documents en erreur (qui n'ont pa spu être integrés dans le sip)
      if (lstDocumentsValides.removeAll(lstDocumentReellementIntegreDansSIP)) {

        if (lstDocumentsEnErreur != null) {
          lstDocumentsEnErreur.addAll(lstDocumentsValides);
        } else {
          lstDocumentsEnErreur = lstDocumentsValides;
        }
      }
    }

    // on va mettre le statut des documents qui n'ont pas pu être intégrés dans le sip à ERREUR
    if (lstDocumentsEnErreur != null && !lstDocumentsEnErreur.isEmpty()) {
      final List<String> lstIdDocumentToErreur = new ArrayList<>();
      lstDocumentsEnErreur.forEach(doc -> lstIdDocumentToErreur.add(doc.getUuid()));
      if (!lstIdDocumentToErreur.isEmpty()) {
        documentMetier.changerStatutDocsTo(lstIdDocumentToErreur, statutDocumentTypeErreur);
      }
    }

    // Création du SIP en BDD avec le statut SIP_A_VERSER et documents associés INTEGRE_SIP
    if (lstDocumentReellementIntegreDansSIP != null && !lstDocumentReellementIntegreDansSIP.isEmpty()) {
      sipMetier.creerSip(sipName, strPathSipOut, toLstDocumentType(lstDocumentReellementIntegreDansSIP));
    }

    // on va compter le nb de documents
  }

  /**
   * Permet de verifier que les documents passés en parametre vérifient les conditions suivantes:
   * - Présence des métadonnées obligatoires : Code RND et l’id d’archivage.
   * - Le fichier binaire associé au document est présent physiquement.
   * - Le fichier des métadonnées est présent physiquement.
   * - Le format du fichier binaire fait parti des formats valides pour être intégrer dans un sip
   * On verifie egalement les données non obligatoire comme le hash no scellé et le bloc horodaté
   * 
   * @param lstDocumentType
   *          List<DocumentType>
   * @return la liste des documents qui vérifient toutes les conditions precisées plus haut et la liste des documents en erreur
   */
  private Map<String, List<DocumentDto>> checkAndPrepareDocsBeforeSipGen(final List<DocumentType> lstDocumentType) {
    // permet de stocker tous les documents valides
    final List<DocumentDto> lstDocumentsValides = new ArrayList<>();
    // permet de stocker tous les documents en erreurs
    final List<DocumentDto> lstDocumentsErreurs = new ArrayList<>();

    final Map<String, List<DocumentDto>> mapEtatDocuments = new HashMap<>();

    if (lstDocumentType != null) {

      final List<DocumentDto> lstDocumentDtoToCheck = toLstDocumentDto(lstDocumentType);
      List<LogDocumentType> lstLogDocument;

      for (final DocumentDto documentDto : lstDocumentDtoToCheck) {

        // On va vérifier que ce document vérifie toutes les conditions requises pour pouvoir être intégrer dans un SIP.
        lstLogDocument = checkMandatoryDataForSipIntegration(documentDto);

        // si la liste lstLogDocument est vide, alors le document est intégrable dans un sip
        if (lstLogDocument.isEmpty()) {
          final String codeRnd = documentDto.getLstMetadonnees().get(MetadataHelper.MetadataVitam.METADATA_CodeRND.getRealeName()).getValue();
          documentDto.setArchiveUnitProfile(STR_PREFIXE_ARCHIVE_UNIT_PROFILE + codeRnd);
          documentDto.setAppraisalRule(STR_PREFIXE_MANAGEMENT_APPRAISALRULE + codeRnd);
          lstDocumentsValides.add(documentDto);

          // le document est en erreur
        } else {
          lstDocumentsErreurs.add(documentDto);
        }

        LogDocumentType tmpLogDocument;
        // on verifie la présence de la donnée hash Scelle
        if (documentDto.getHashScelle() == null || documentDto.getHashScelle().trim().isEmpty()) {
          SipGeneratorImpl.LOGGER.info("Integration d'un document dans un SIP dont la donnée Hash Scelle n'est pas présente: " + documentDto);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("Integration d'un document dans un SIP dont la donnée Hash Scelle n'est pas présente: " + documentDto);
          lstLogDocument.add(tmpLogDocument);
        }

        // on verifie la présence de la donnée horodate
        if (documentDto.getBlocHorodate() == null || documentDto.getBlocHorodate().trim().isEmpty()) {
          SipGeneratorImpl.LOGGER.info("Integration d'un document dans un SIP dont la donnée Horodatage n'est pas présente: " + documentDto);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("Integration d'un document dans un SIP dont la donnée Horodatage n'est pas présente: " + documentDto);
          lstLogDocument.add(tmpLogDocument);
        }

        // Ajout des logs en bdd
        documentMetier.addLogsToDocument(documentDto.getUuid(), lstLogDocument);

      }

      mapEtatDocuments.put("erreur", lstDocumentsErreurs);
      mapEtatDocuments.put("valide", lstDocumentsValides);
    }

    return mapEtatDocuments;
  }


  /**
   * Permet de verifier que le document passé en parametre vérifie les conditions suivantes:
   * - Présence des métadonnées obligatoires : Code RND et l’id d’archivage.
   * - Le fichier binaire associé au document est présent physiquement.
   * - Le fichier des métadonnées est présent physiquement.
   * - Le format du fichier binaire fait parti des formats valides pour être intégrer dans un sip
   * Les conditions minimales pour pouvoir être intégrer dans un SIP
   * 
   * @param documentDto
   *          DocumentDto
   * @return List<LogDocumentType>
   */
  private List<LogDocumentType> checkMandatoryDataForSipIntegration(final DocumentDto documentDto) {
    final List<LogDocumentType> lstLogDocument = new ArrayList<>();
    if (documentDto != null) {

      LogDocumentType tmpLogDocument;
      final String documentFileName = documentDto.getPathDocument();

      // vérifier la presence de l'UUID
      if (documentDto.getUuid() == null || documentDto.getUuid().trim().isEmpty()) {
        SipGeneratorImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car la donnée UUID n'est pas présente: " + documentDto);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car la donnée UUID n'est pas présente: " + documentDto);
        lstLogDocument.add(tmpLogDocument);
      }

      // on vérifie si le document est vraiment présent physiquement
      if (documentFileName == null || !exists(documentFileName)) {
        SipGeneratorImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le document n'est pas présent physiquement: "
            + documentFileName);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le document n'est pas présent physiquement: "
            + documentFileName);
        lstLogDocument.add(tmpLogDocument);
      } else {
        // on vérifie si le fichier des métadonnées est présent physiquement
        String pathMetadataFile = FileHelper.removeFileExtension(documentFileName);
        pathMetadataFile += ".json";

        if (!exists(pathMetadataFile)) {
          SipGeneratorImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le fichier des métadonnées n'est pas présent physiquement: "
              + pathMetadataFile);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le fichier des métadonnées n'est pas présent physiquement: "
              + pathMetadataFile);
          lstLogDocument.add(tmpLogDocument);
        } else {
          // vérification des métadonnées obligatoires

          final Path documentPath = Paths.get(documentFileName);
          documentDto.setLstMetadonnees(MetadataHelper.getDataTypes(documentPath));

          // on verifie la presence des métadonnées obligatoire
          final List<String> lstMandatoryMetadataNotFound = MetadataHelper.ckeckIfAllMandatoryMetaArePresent(documentDto.getLstMetadonnees());

          /*
           * On boucle sur la liste des métadonnées obligatoires non trouvée.
           * Puis on les loggue en base
           */
          if (lstMandatoryMetadataNotFound != null && !lstMandatoryMetadataNotFound.isEmpty()) {
            for (final String metadataName : lstMandatoryMetadataNotFound) {
              SipGeneratorImpl.LOGGER.info("La métadonnée obligatoire " + metadataName + " n'est pas renseignée.");
              tmpLogDocument = new LogDocumentType();
              tmpLogDocument.setMessage("La métadonnée obligatoire " + metadataName + " n'est pas renseignée.");
              lstLogDocument.add(tmpLogDocument);
            }
          }
        }
      }

      // on vérifier si le document n'est pas un répertoire
      if (documentFileName != null) {
        final Path documentPath = Paths.get(documentFileName);
        if (Files.isDirectory(documentPath, java.nio.file.LinkOption.NOFOLLOW_LINKS)) {

          SipGeneratorImpl.LOGGER.info("impossible d'intégrer ce document car c'est un répertoire: "
              + documentFileName);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("impossible d'intégrer ce document car c'est un répertoire: "
              + documentFileName);
          lstLogDocument.add(tmpLogDocument);
        }
      }
    }

    return lstLogDocument;
  }

  private List<DocumentDto> toLstDocumentDto(final List<DocumentType> lstDocumentType) {
    final List<DocumentDto> lstDocumentDto = new ArrayList<>();

    if (lstDocumentType != null) {
      DocumentDto tmpDocumentDto;
      for (final DocumentType documentType : lstDocumentType) {
        tmpDocumentDto = new DocumentDto();
        tmpDocumentDto.setBlocHorodate(documentType.getBlocHorodate());
        tmpDocumentDto.setHashScelle(documentType.getHashScelle());
        tmpDocumentDto.setPathDocument(documentType.getPathDocument());
        tmpDocumentDto.setUuid(documentType.getUuid());
        tmpDocumentDto.setId(documentType.getId());

        lstDocumentDto.add(tmpDocumentDto);
      }
    }

    return lstDocumentDto;
  }

  /**
   * Conversion List<DocumentDto> en List<DocumentType>
   * 
   * @param lstDocumentDto
   * @return List<DocumentType>
   */
  private List<DocumentType> toLstDocumentType(final List<DocumentDto> lstDocumentDto) {

    final List<DocumentType> lstDocumentType = new ArrayList<>();

    if (lstDocumentDto != null) {
      DocumentType documentType;

      for (final DocumentDto documentDto : lstDocumentDto) {
        documentType = new DocumentType();
        documentType.setBlocHorodate(documentDto.getBlocHorodate());
        documentType.setHashNonScelle(documentDto.getHashScelle());
        documentType.setPathDocument(documentDto.getPathDocument());
        documentType.setUuid(documentDto.getUuid());
        documentType.setId(documentDto.getId());

        lstDocumentType.add(documentType);

      }
    }
    return lstDocumentType;
  }

  /**
   * Permet de rechercher tous les documents appartenant au lot de versement idLotVersement et dont le statut est à codeStatutDocument.
   * Les documents seront regroupés par paquet de X documents (X étant la valeur de la variable nbMaxDocsDansSip)
   * 
   * @param idLotVersement
   *          Long
   * @param codeStatutDocument
   *          String
   * @return Des document regroupés par paquet de X documents (X étant la valeur de la variable nbMaxDocsDansSip)
   */
  private Map<Integer, List<DocumentType>> rechercherDocuments(final Long idLotVersement, final String codeStatutDocument) {

    final Map<Integer, List<DocumentType>> documents = new HashMap<>();

    /*
     * En utilisant les services fournis par la librairie database-access,
     * rechercher par paquet de X (X étant le nombre de documents maximum permis pour la construction d’un SIP)
     * les documents au statut « codeStatutDocument », qui appartiennent au lot de versement dont l'identifiant est idLotVersement.
     */

    // preparation des critères de recherche
    final CriteresRechercheDocumentType criteres = new CriteresRechercheDocumentType();
    criteres.setIdLotVersement(idLotVersement);
    criteres.setCodeStatutDocument(codeStatutDocument);
    criteres.setSearchForIdSipNull(true);
    Integer currentPage = 0;
    criteres.setSize(nbMaxDocsDansSip);
    List<DocumentType> lstDocumentType = new ArrayList<>();

    // on boucle tant qu'il y a encore de donnée à recuperer.
    while (currentPage > -1) {
      criteres.setCurrentPage(currentPage);
      lstDocumentType = documentMetier.rechercherDocuments(criteres);

      if (lstDocumentType != null && !lstDocumentType.isEmpty()) {
        documents.put(currentPage, lstDocumentType);
      }

      /*
       * On verifie s'il reste encore de documents à récupérés:
       * si la taille de la liste est inférieure à celle qu'on a voulu alors, il ne reste plus de données à recupérer
       */
      if (lstDocumentType != null && lstDocumentType.size() < nbMaxDocsDansSip) {
        currentPage = -1;
      } else {
        currentPage++;
      }
    }
    return documents;
  }

  /**
   * Permet de generer un SIP à partir des informations en parametre
   * 
   * @param sipName
   *          : le nom du SIP
   * @param lstDocumentAIntegrerDansSIP:
   *          la liste des documents qu'on va intégrer dans le SIP
   * @param strPathOut
   *          : Le chemin où on a déposé le fichier .zip
   * @return une liste des document qui ont bien été intégrés dans le sip (fichier .zip) fraichement créé
   */
  private List<DocumentDto> generateSip(final String sipName, final List<DocumentDto> lstDocumentAIntegrerDansSIP, final String strPathOut) {
    List<DocumentDto> lstDocumentReellementIntegreDansSIP = new ArrayList<>();
    if (preferencePath != null && lstDocumentAIntegrerDansSIP != null && !lstDocumentAIntegrerDansSIP.isEmpty()) {

      final Work work = new Work(null, new DiskImportContext(Prefs.getInstance(preferencePath)), null);

      final DiskToDataObjectPackageImporter di = new DiskToDataObjectPackageImporter(lstDocumentAIntegrerDansSIP, null);

      try {
        di.doImport();
      } catch (final SEDALibException e) {
        e.printStackTrace();
      } catch (final InterruptedException e) {
        e.printStackTrace();
      }

      final Path pathOut = Paths.get(strPathOut);

      final ExportContext newExportContext = new ExportContext(Prefs.getInstance(preferencePath));
      work.setExportContext(newExportContext);
      work.getExportContext().setOnDiskOutput(pathOut.toString());

      work.setDataObjectPackage(di.getDataObjectPackage());

      work.getDataObjectPackage().regenerateContinuousIds();
      final ArchiveTransfer archiveTransfer = new ArchiveTransfer();

      work.getDataObjectPackage().setManagementMetadataXmlData(work.getExportContext().getManagementMetadataXmlData());
      archiveTransfer.setDataObjectPackage(work.getDataObjectPackage());
      archiveTransfer.setGlobalMetadata(work.getExportContext().getArchiveTransferGlobalMetadata());

      final ArchiveTransferToSIPExporter smm = new ArchiveTransferToSIPExporter(archiveTransfer);
      try {
        lstDocumentReellementIntegreDansSIP = smm.doExportToSEDASIP(work.getExportContext().getOnDiskOutput(),
                                                                    work.getExportContext().isHierarchicalArchiveUnits(),
                                                                    work.getExportContext().isIndented());

      } catch (final SEDALibException | InterruptedException e) {
        SipGeneratorImpl.LOGGER.error(e.getMessage());
      }

    }

    return lstDocumentReellementIntegreDansSIP;

  }

  /**
   * Permet de savoir si un fichier existe vraiment physiquement.
   */
  private boolean exists(final String strPath) {
    SipGeneratorImpl.LOGGER.trace("verification de l'existance du fichier: " + strPath);
    boolean exists = false;

    if (strPath != null && !strPath.trim().isEmpty()) {

      try {
        final Path filePath = Paths.get(strPath);
        final File file = filePath.toFile();

        if (file != null && file.length() > 0) {
          exists = true;
        }

      } catch (final InvalidPathException | UnsupportedOperationException e) {
        SipGeneratorImpl.LOGGER.error("", e);
      }
    }
    return exists;
  }

}
