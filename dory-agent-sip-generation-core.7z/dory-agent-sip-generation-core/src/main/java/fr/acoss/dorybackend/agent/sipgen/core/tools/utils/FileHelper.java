package fr.acoss.dorybackend.agent.sipgen.core.tools.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

/**
 * Classe utilitaire pour les fichiers (File)
 */
public class FileHelper {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(FileHelper.class);

  /**
   * Conversion du fichier json en chaine de charactères
   * 
   * @param jsonFile
   *          File
   * @return String
   */
  public static String jsonFileToString(final File jsonFile) {

    final StringBuilder jsonString = new StringBuilder();
    // final JSONParser jsonParser = new JSONParser();
    //
    // try (Reader targetReader = new FileReader(jsonFile)) {
    // final Object obj = jsonParser.parse(targetReader);
    //
    // // final JSONObject metadata = (JSONObject) obj;
    // final JSONArray metadata = (JSONArray) obj;
    // jsonString.append(metadata.toJSONString());
    // }
    // catch (final Exception e) {
    // FileHelper.LOGGER.error("Erreur lors de la conversion du fichier json en chaine de charactères", e);
    // }

    return jsonString.toString();
  }


  /**
   * Conversion MultipartFile -> File
   * 
   * @param file
   *          MultipartFile
   * @return
   * @throws IOException
   */
  public static File convertToFile(final MultipartFile file) throws IOException {
    File convFile = null;
    FileOutputStream fos = null;
    try {
      if (file != null) {
        final String OriginalFilename = file.getOriginalFilename();
        if (OriginalFilename != null) {
          convFile = new File(OriginalFilename);
          convFile.createNewFile();
          fos = new FileOutputStream(convFile);
          fos.write(file.getBytes());
        }
      }
    }
    finally {
      if (fos != null) {
        try {
          fos.close();
        }
        catch (final IOException e) {
          FileHelper.LOGGER.error("Erreur lors de la fermeture du flux", e);
        }
      }
    }

    return convFile;
  }

  /**
   * Permet de lister les fichiers/repertoire qui se trouvent dans le repertoire (directoryPath) et ses sous repertoires
   * 
   * @param directoryPath
   *          String
   * @param maxDepth
   *          int
   * @return une liste de chaine de caractère qui représente tous les fichiers/repertoires dans le repertoire (directoryPath) et ses sous repertoires
   */
  public static List<String> getAllFilesInDirectory(final String directoryPath, final int maxDepth) {
    final List<String> lstPath = new ArrayList<>();

    if (directoryPath != null && !directoryPath.trim().isEmpty() && maxDepth > -1) {

      final Path startDir = Paths.get(directoryPath);

      try (Stream<Path> stream = Files.walk(startDir, maxDepth)) {
        final List<String> collect = stream
            .map(String::valueOf)
            .sorted()
            .collect(Collectors.toList());

        collect.forEach(System.out::println);
      }
      catch (final IOException e) {
        FileHelper.LOGGER.error("Erreur lors de la recherche des fichiers", e);
      }
    }

    return lstPath;
  }

  /**
   * Méthode de calcul du sha512 du fichier
   * 
   * @param onDiskPath
   * @return
   */
  public static String getDigestSha512(final Path onDiskPath) {
    MessageDigest messageDigest = null;
    InputStream is = null;
    String sha512 = null;
    try {
      messageDigest = MessageDigest.getInstance("SHA-512");
    } catch (final NoSuchAlgorithmException e) {
      LOGGER.error("no Provider supports aMessageDigestSpi implementation for thespecified algorithm", e);
    }

    try {
      is = new BufferedInputStream(Files.newInputStream(onDiskPath));
      final byte[] buffer = new byte[4096];
      for (int read; (read = is.read(buffer)) != -1;) {
        messageDigest.update(buffer, 0, read);
      }
    } catch (final IllegalArgumentException | UnsupportedOperationException | IOException | SecurityException | NullPointerException e) {
      LOGGER.error("", e);
    } finally {
      if (is != null) {
        try {
          is.close();
        } catch (final IOException e) {
          LOGGER.error("", e);
        }
      }
    }

    // Convert the byte to hex format
    try {
      @SuppressWarnings("resource")
      final Formatter formatter = new Formatter();
      if (messageDigest != null) {
        for (final byte b : messageDigest.digest()) {
          formatter.format("%02x", b);
        }
      }
      sha512 = formatter.toString();
    } catch (final Exception e) {
      LOGGER.error("", e);
    }

    return sha512;
  }

  /**
   * Méthode de calcul du sha512 du fichier
   * 
   * @param multipartFile
   * @return
   */
  public static String getDigestSha512(final MultipartFile multipartFile) {
    MessageDigest messageDigest = null;
    InputStream is = null;
    String sha512 = null;
    try {
      messageDigest = MessageDigest.getInstance("SHA-512");
    } catch (final NoSuchAlgorithmException e) {
      LOGGER.error("no Provider supports aMessageDigestSpi implementation for thespecified algorithm", e);
    }

    if (messageDigest != null) {
      try {
        is = new BufferedInputStream(multipartFile.getInputStream());
        final byte[] buffer = new byte[4096];
        for (int read; (read = is.read(buffer)) != -1;) {
          messageDigest.update(buffer, 0, read);
        }
      } catch (final IllegalArgumentException | UnsupportedOperationException | IOException | SecurityException | NullPointerException e) {
        LOGGER.error("", e);
      } finally {
        if (is != null) {
          try {
            is.close();
          } catch (final IOException e) {
            LOGGER.error("", e);
          }
        }
      }

      // Convert the byte to hex format
      try {
        @SuppressWarnings("resource")
        final Formatter formatter = new Formatter();
        for (final byte b : messageDigest.digest()) {
          formatter.format("%02x", b);
        }
        sha512 = formatter.toString();
      } catch (final Exception e) {
        LOGGER.error("", e);
      }
    }

    return sha512;
  }

  /**
   * Méthode de calcul de la taille du fichier en entée du SIP
   * 
   * @param onDiskPath
   * @return
   */
  public static String getSizeOfAFile(final Path onDiskPath) {
    final String size = String.valueOf(onDiskPath.toFile().length());
    return size;
  }

  /**
   * Méthode de calcul de la date de dernière modification du fichier en entrée du
   * SIP
   * 
   * @param onDiskPath
   * @return
   */
  public static String getLastModifiedDate(final Path onDiskPath) {
    final String lastModified = String.valueOf(onDiskPath.toFile().lastModified());
    return lastModified;
  }

  /**
   * Permet de renomer une fichier
   * 
   * @param toBeRenamed
   * @param new_name
   * @throws IOException
   */
  public static void renameFile(final File toBeRenamed, final String new_name) throws IOException {
    final File fileWithNewName = new File(toBeRenamed.getParent(), new_name);
    if (fileWithNewName.exists()) {
      FileHelper.LOGGER.error("Impossible de renommer le fichier : " + toBeRenamed.getPath() + " car le fichier source : "
          + new_name + " existe déjà.");
    }
    final boolean success = toBeRenamed.renameTo(fileWithNewName);
    if (!success) {
      FileHelper.LOGGER.error("Le fichier : " + toBeRenamed.getName() + " a été renommé en : " + new_name);
    }
  }

  /**
   * Permet de supprimer l'extension sur le nom d'un fichier
   * 
   * @param fileName
   * @return
   */
  public static String removeFileExtension(final String fileName) {

    String fileNameWithoutExt = "";

    if (fileName != null && !fileName.isEmpty()) {
      fileNameWithoutExt = fileName.replaceAll("[.][^.]+$", "");
    }
    return fileNameWithoutExt;
  }

  /**
   * Permet de retourner l'extention d'un fichier
   * 
   * @param fileName
   *          String
   * @return String
   */
  public static String getFileExtention(String fileName) {
    String fileExtention = "";

    if (fileName != null && !fileName.isEmpty()) {
      fileName = fileName.trim();

      fileExtention = fileName.substring(fileName.lastIndexOf(".") + 1);
    }
    return fileExtention;
  }
}
