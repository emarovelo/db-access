package fr.acoss.dorybackend.agent.sipgen.core.tools.xml;

import static java.time.format.DateTimeFormatter.ISO_DATE;
import static java.time.format.DateTimeFormatter.ISO_DATE_TIME;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.ctc.wstx.api.WstxInputProperties;
import com.ctc.wstx.api.WstxOutputProperties;

import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.SEDALibException;

/**
 * The Class SEDAXMLEventReader.
 * <p>
 * Wrapper class for XMLEventReader for high level functions used in all SEDA
 * metadata readers. It can read either XML document, either XML fragments. It's
 * based on WoodStox STAX objects.
 */
public class SEDAXMLEventReader implements AutoCloseable {

  /** The XMLInputFactory. */
  private static XMLInputFactory xmlif;

  /** The XMLInputFactory for fragments. */
  private static XMLInputFactory xmlifFragments;

  /** The XMLOutputFactory. */
  private static XMLOutputFactory xmlof;

  /** The XMLOutputFactory for fragments. */
  private static XMLOutputFactory xmlofFragments;

  static {
    try {
      xmlif = XMLInputFactory.newInstance();
      xmlifFragments = XMLInputFactory.newInstance();
      // Warning it's a Woodstox specific mode
      xmlifFragments.setProperty(WstxInputProperties.P_INPUT_PARSING_MODE,
                                 WstxInputProperties.PARSING_MODE_FRAGMENT);
      xmlof = XMLOutputFactory.newInstance();
      xmlofFragments = XMLOutputFactory.newInstance();
      xmlofFragments.setProperty(WstxOutputProperties.P_OUTPUT_VALIDATE_STRUCTURE, false);
      // XML objects initialization
    } catch (final Exception e) {
      System.err.println("Erreur fatale, impossible de créer les outils de manipulation Xml et/ou Droid");
      System.exit(1);
    }
  }

  /** The xml reader. */
  public XMLEventReader xmlReader;

  /**
   * Instantiates a new SEDAXML event reader.
   *
   * @param is            the InputStream
   * @param isForElements true, if the reader must be able to read fragements
   *                      (multi root)
   * @throws SEDALibException if impossible to open the stream
   */
  public SEDAXMLEventReader(final InputStream is, final boolean isForElements) throws SEDALibException {
    InputStreamReader readerFIS = null;
    try {
      readerFIS = new InputStreamReader(is, "UTF-8");
      if (isForElements) {
        xmlReader = xmlifFragments.createXMLEventReader(readerFIS);
      } else {
        xmlReader = xmlif.createXMLEventReader(readerFIS);
      }
    } catch (final Exception e) {
      if (readerFIS != null) {
        try {
          readerFIS.close();
        } catch (final IOException e1) {
          // too bad
        }
      }
      throw new SEDALibException("Impossible d'ouvrir un flux de lecture XML (" + e.getMessage() + ")");
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.AutoCloseable#close()
   */
  // Methods
  @Override
  public void close() throws XMLStreamException {
    xmlReader.close();
  }

  /**
   * Get the date and time from XML format "yyyy-MM-dd'T'HH:mm:sszone-offset"
   *
   * @param datetimeString contains XML formated date of the given date
   * @return the date and time
   * @throws DateTimeParseException if not a well formed date and time
   */

  public static LocalDateTime getDateTimeFromString(final String datetimeString) throws DateTimeParseException {
    LocalDateTime ldt;
    try {
      ldt = LocalDateTime.parse(datetimeString, ISO_DATE_TIME);
    } catch (final DateTimeParseException e) {
      ldt = LocalDate.parse(datetimeString, ISO_DATE).atStartOfDay();
    }
    return ldt;
  }

  /**
   * Get the date from XML format "yyyy-MM-ddzone-offset"
   *
   * @param dateString contains XML formated date of the given date
   * @return the date and time
   * @throws DateTimeParseException if not a well formed date
   */

  public static LocalDate getDateFromString(final String dateString) throws DateTimeParseException {
    return LocalDate.parse(dateString, ISO_DATE);
  }

  /**
   * Peek name.
   *
   * @return the name
   * @throws XMLStreamException the XML stream exception
   */
  public String peekName() throws XMLStreamException {
    final XMLEvent event = peekUsefullEvent();

    if (!event.isStartElement()) {
      return null;
    }
    return event.asStartElement().getName().getLocalPart();
  }

  /**
   * Peek usefull event.
   *
   * @return the XML event
   * @throws XMLStreamException the XML stream exception
   */
  public XMLEvent peekUsefullEvent() throws XMLStreamException {
    XMLEvent result;

    result = xmlReader.peek();
    while (result.getEventType() == XMLStreamConstants.COMMENT
        || result.isCharacters() && result.asCharacters().isWhiteSpace()) {
      xmlReader.nextEvent();
      result = xmlReader.peek();
    }
    return result;
  }

  /**
   * Peek attribute.
   *
   * @param attribute the attribute
   * @return the attribute string value, or null if the "attribute" isn't set
   * @throws XMLStreamException the XML stream exception
   */
  public String peekAttribute(final String attribute) throws XMLStreamException {
    final XMLEvent peek = peekUsefullEvent();
    String result = null;

    if (peek.isStartElement()) {
      final Attribute a = peek.asStartElement().getAttributeByName(new QName(attribute));
      if (a != null) {
        result = a.getValue();
      }
    }
    return result;
  }

  /**
   * Peek attribute.
   *
   * @param namespace the namespace
   * @param attribute the attribute
   * @return the attribute string value, or null if the "attribute" isn't set
   * @throws XMLStreamException the XML stream exception
   */
  public String peekAttribute(final String namespace, final String attribute) throws XMLStreamException {
    final XMLEvent peek = peekUsefullEvent();
    String result = null;

    if (peek.isStartElement()) {
      final Attribute a = peek.asStartElement().getAttributeByName(new QName(namespace, attribute));
      if (a != null) {
        result = a.getValue();
      }
    }
    return result;
  }

  /**
   * Next usefull event.
   *
   * @return the XML event
   * @throws XMLStreamException the XML stream exception
   */
  public XMLEvent nextUsefullEvent() throws XMLStreamException {
    XMLEvent result;

    result = xmlReader.nextEvent();
    while (result.getEventType() == XMLStreamConstants.COMMENT
        || result.isCharacters() && result.asCharacters().isWhiteSpace()) {
      result = xmlReader.nextEvent();
    }
    return result;
  }

  /**
   * Next block if named.
   *
   * @param tag the tag
   * @return true, if successful
   * @throws XMLStreamException the XML stream exception
   */
  public boolean nextBlockIfNamed(final String tag) throws XMLStreamException {
    final XMLEvent peek = peekUsefullEvent();

    if (!peek.isStartElement()) {
      return false;
    }
    if (!tag.equals(peek.asStartElement().getName().getLocalPart())) {
      return false;
    }
    nextUsefullEvent();
    return true;
  }

  /**
   * Peek block if named.
   *
   * @param tag the tag
   * @return true, if successful
   * @throws XMLStreamException the XML stream exception
   */
  public boolean peekBlockIfNamed(final String tag) throws XMLStreamException {
    final XMLEvent peek = peekUsefullEvent();

    if (!peek.isStartElement()) {
      return false;
    }
    return tag.equals(peek.asStartElement().getName().getLocalPart());
  }

  /**
   * Peek attribute block if named.
   *
   * @param tag       the tag
   * @param attribute the attribute
   * @return the attribute string value, or null if next element is not the "tag"
   *         element or if the "attribute" isn't set
   * @throws XMLStreamException the XML stream exception
   */
  public String peekAttributeBlockIfNamed(final String tag, final String attribute) throws XMLStreamException {
    final XMLEvent peek = peekUsefullEvent();
    String result = null;

    if (peek.isStartElement() && tag.equals(peek.asStartElement().getName().getLocalPart())) {
      result = peek.asStartElement().getAttributeByName(new QName(attribute)).getValue();
    }
    return result;
  }

  /**
   * End block named.
   *
   * @param tag the tag
   * @throws XMLStreamException the XML stream exception
   * @throws SEDALibException   if "tag" element is ended here
   */
  public void endBlockNamed(final String tag) throws XMLStreamException, SEDALibException {
    final XMLEvent event = nextUsefullEvent();

    if (!event.isEndElement()) {
      throw new SEDALibException("Elément " + tag + " mal terminé");
    }
    if (!tag.equals(event.asEndElement().getName().getLocalPart())) {
      throw new SEDALibException("Elément " + tag + " mal terminé");
    }
  }

  /**
   * Next value if named.
   *
   * @param tag the tag
   * @return the value String for the "tag" element, or null if next element is
   *         not the "tag" element
   * @throws XMLStreamException the XML stream exception
   * @throws SEDALibException   if "tag" element is badly formed
   */
  public String nextValueIfNamed(final String tag) throws XMLStreamException, SEDALibException {
    XMLEvent event;
    String result = null;

    if (nextBlockIfNamed(tag)) {
      event = nextUsefullEvent();
      if (event.isCharacters()) {
        result = event.asCharacters().getData();
        event = nextUsefullEvent();
      }
      if (!event.isEndElement() || !event.asEndElement().getName().getLocalPart().equals(tag)) {
        throw new SEDALibException("Elément " + tag + " mal formé");
      }
      if (result == null) {
        result = "";
      }
    }
    return result;
  }

  /**
   * Next Date value if named.
   *
   * @param tag the tag
   * @return the value LocalDateTime for the "tag" element, or null if next element is not
   *         the "tag" element
   * @throws XMLStreamException the XML stream exception
   * @throws SEDALibException   if "tag" element is badly formed
   */
  public LocalDateTime nextDateValueIfNamed(final String tag) throws XMLStreamException, SEDALibException {
    XMLEvent event;
    String tmp = null;
    LocalDateTime result = null;

    if (nextBlockIfNamed(tag)) {
      event = nextUsefullEvent();
      if (event.isCharacters()) {
        tmp = event.asCharacters().getData();
        event = nextUsefullEvent();
      }
      if (!event.isEndElement() || !event.asEndElement().getName().getLocalPart().equals(tag) || tmp == null) {
        throw new SEDALibException("Elément date " + tag + " mal formé");
      }
      try {
        result = getDateTimeFromString(tmp);
      } catch (final DateTimeParseException e) {
        throw new SEDALibException("Valeur non interprétable [" + tmp + "] dans l'élément date " + tag);
      }
    }
    return result;
  }

  /**
   * Next Boolean value if named.
   *
   * @param tag the tag
   * @return the value Boolean for the "tag" element, or null if next element is
   *         not the "tag" element
   * @throws XMLStreamException the XML stream exception
   * @throws SEDALibException   the SEDALibException
   */
  public Boolean nextBooleanValueIfNamed(final String tag) throws XMLStreamException, SEDALibException {
    XMLEvent event;
    String tmp = null;
    Boolean result = null;

    if (nextBlockIfNamed(tag)) {
      event = nextUsefullEvent();
      if (event.isCharacters()) {
        tmp = event.asCharacters().getData();
        event = nextUsefullEvent();
      }
      if (!event.isEndElement() || !event.asEndElement().getName().getLocalPart().equals(tag) || tmp == null) {
        throw new SEDALibException("Elément booléen " + tag + " mal formé");
      }
      switch (tmp) {
      case "true":
      case "1":
        result = true;
        break;
      case "false":
      case "0":
        result = false;
        break;
      default:
        throw new SEDALibException("Valeur interdite [" + tmp + "] dans l'élément booléen " + tag);
      }
    }
    return result;
  }

  /**
   * Next mandatory value.
   *
   * @param tag the tag
   * @return the value String for the "tag" element, or null if next element is
   *         not the "tag" element
   * @throws XMLStreamException the XML stream exception
   * @throws SEDALibException   the SEDALibException
   */
  public String nextMandatoryValue(final String tag) throws XMLStreamException, SEDALibException {
    if (!peekBlockIfNamed(tag)) {
      throw new SEDALibException("Element " + tag + " non trouvé");
    }
    return nextValueIfNamed(tag);
  }

  /**
   * Next block as string if named.
   *
   * @param tag the tag
   * @return the String containing all the "tag" element (with begin and end
   *         tags), or null if next element is not the "tag" element
   * @throws XMLStreamException the XML stream exception
   */
  public String nextBlockAsStringIfNamed(final String tag) throws XMLStreamException {
    XMLEvent event = peekUsefullEvent();

    if (event.isStartElement() && tag.equals(event.asStartElement().getName().getLocalPart())) {
      int count = 0;
      final StringWriter sw = new StringWriter();
      final XMLEventWriter xw = xmlof.createXMLEventWriter(sw);

      while (xmlReader.hasNext()) {
        event = xmlReader.nextEvent();
        xw.add(event);
        if (event.isStartElement() && ((StartElement) event).getName().getLocalPart().equals(tag)) {
          count++;
        } else if (event.isEndElement() && ((EndElement) event).getName().getLocalPart().equals(tag)) {
          count--;
          if (count == 0) {
            break;
          }
        }
      }
      if (xw != null) {
        xw.close();
      }
      return sw.toString();
    } else {
      return null;
    }
  }

  /**
   * Next mandatory block as string.
   *
   * @param tag the tag
   * @return the String containing all the "tag" element (with begin and end
   *         tags), or null if next element is not the "tag" element
   * @throws XMLStreamException the XML stream exception
   * @throws SEDALibException   if the next block is not a "tag" element
   */
  public String nextMandatoryBlockAsString(final String tag) throws XMLStreamException, SEDALibException {
    if (!peekBlockIfNamed(tag)) {
      throw new SEDALibException("Elément " + tag + " non trouvé");
    }
    return nextBlockAsStringIfNamed(tag);
  }
}
