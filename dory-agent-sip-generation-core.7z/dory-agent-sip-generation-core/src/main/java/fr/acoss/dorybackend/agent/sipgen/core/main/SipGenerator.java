package fr.acoss.dorybackend.agent.sipgen.core.main;

/**
 *
 */
public interface SipGenerator {
  void doTask();
}
