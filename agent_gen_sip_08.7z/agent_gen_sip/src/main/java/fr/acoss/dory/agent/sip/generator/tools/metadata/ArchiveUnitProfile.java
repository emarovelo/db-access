package fr.acoss.dory.agent.sip.generator.tools.metadata;

import fr.acoss.dory.agent.sip.generator.tools.metadata.namedtype.StringType;

/**
 * The Class ArchiveUnitProfile.
 * <p>
 * Class for SEDA element ArchiveUnitProfile.
 * <p>
 * A ArchiveUnitProfile metadata.
 * <p>
 * Standard quote: "Référence à une partie d'un profil d’archivage applicable à
 * un ArchiveUnit en particulier. Permet par exemple de faire référence à une
 * typologie documentaire dans un profil d'archivage."
 */
public class ArchiveUnitProfile extends StringType {

  /**
   * Instantiates a new ArchiveUnitProfile.
   */
  public ArchiveUnitProfile() {
    super("ArchiveUnitProfile");
  }

  /**
   * Instantiates a new ArchiveUnitProfile.
   *
   * @param value the value
   */
  public ArchiveUnitProfile(final String value) {
    super("ArchiveUnitProfile", value);
  }
}
