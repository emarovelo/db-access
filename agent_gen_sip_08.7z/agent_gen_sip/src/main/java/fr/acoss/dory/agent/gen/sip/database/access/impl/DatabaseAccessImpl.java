package fr.acoss.dory.agent.gen.sip.database.access.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import fr.acoss.dory.agent.gen.sip.core.metier.FileStorage;
import fr.acoss.dory.agent.gen.sip.core.metier.SipGenerator;
import fr.acoss.dory.agent.gen.sip.core.modele.dto.DocumentDto;
import fr.acoss.dory.agent.gen.sip.core.tools.utils.FileHelper;
import fr.acoss.dory.agent.gen.sip.database.access.DatabaseAccess;
import fr.acoss.dorybackend.core.layer.metier.DocumentMetier;
import fr.acoss.dorybackend.core.layer.metier.LotVersementMetier;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheDocumentType;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheLotVersementType;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.DocumentType;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.LogDocumentType;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.LotVersementType;

/**
 * Classe permettant la gestion des données depuis la base de donnée
 */
@Service
public class DatabaseAccessImpl implements DatabaseAccess {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(DatabaseAccessImpl.class);

  /**
   * The allow pattern String from preferences.properties file.
   */
  @Value("${importContext.disk.allowPatternList}")
  private String allowPatternsString;

  /**
   * The allow patterns.
   */
  private List<Pattern> allowPatterns;

  @Autowired
  private DocumentMetier documentMetier;

  @Autowired
  private LotVersementMetier lotVersementMetier;

  @Autowired
  private FileStorage fileStorage;

  @Autowired
  private SipGenerator sipGenerator;

  @PostConstruct
  private void postConstruct() {

    if (allowPatterns == null) {
      allowPatterns = new ArrayList<>();
    }

    if (allowPatternsString == null) {
      allowPatternsString = Strings.EMPTY;
    }
    Arrays.asList(allowPatternsString.split("\\s*\n\\s*")).forEach(patternString -> allowPatterns.add(Pattern.compile(patternString)));
  }

  @Override
  public void genererSip() {

    // Etape 1: recupération des lots de versement

    // instanciation d'un objet CriteresRechercheLotVersementType
    final CriteresRechercheLotVersementType criteresRechercheLotVersementType = new CriteresRechercheLotVersementType();

    // la taille max par page est de 100
    criteresRechercheLotVersementType.setSize(100);

    // recupererer seulement les lots de versement dont le statut est HORODATE
    criteresRechercheLotVersementType.setCodeStatutLotVersement("HORODATE");

    List<LotVersementType> lstLotVersement = new ArrayList<>();
    // on commence à garger la page 0
    Integer currentPage = new Integer(0);

    // on boucle tant qu'il y a encore de données
    while (currentPage > -1) {
      criteresRechercheLotVersementType.setCurrentPage(currentPage);

      // appel de la couche DadabaseAcces pour recuperer les lots de versement
      lstLotVersement = lotVersementMetier.rechercherLots(criteresRechercheLotVersementType);

      for (final LotVersementType lotVersementType : lstLotVersement) {
        if (lotVersementType != null && lotVersementType.getId() != null) {

          // generation des SIP pour le let de versement
          generateDocsFromLotVersement(lotVersementType.getId());
        }

      }

      // si la taille de la liste est inférieure à celle qu'on a voulu alors, il ne reste plus de données à recupérer
      if (lstLotVersement != null && lstLotVersement.size() < 100) {
        currentPage = -1;
      } else {
        currentPage++;
      }
    }
  }

  private void generateDocsFromLotVersement(final Long idLotVersement) {
    final CriteresRechercheDocumentType criteres = new CriteresRechercheDocumentType();
    // recuperation des documents appartenant au lot de versement
    criteres.setIdLotVersement(idLotVersement);

    // recuperation des documents qui n'appartient pas encore à un SIP
    criteres.setSearchForIdSipNull(true);

    final Integer pageSize = 100;
    Integer currentPage = 0;

    criteres.setSize(pageSize);


    List<DocumentType> lstDocumentType = new ArrayList<>();
    List<DocumentDto> lstDocumentDtoResult;
    while (currentPage > -1) {
      criteres.setCurrentPage(currentPage);

      lstDocumentType = documentMetier.rechercherDocuments(criteres);

      // si la taille de la liste est inférieure à celle qu'on a voulu alors, il ne reste plus de données à recupérer
      if (lstDocumentType != null && lstDocumentType.size() < 100) {
        currentPage = -1;
      } else {
        currentPage++;
      }

      // En entrée: la liste de tous les documents à integrer dans un SIP
      // En sortie: liste de documents après filtrage et reelement integrer dans le SIP
      lstDocumentDtoResult = checkAndPrepareDocsBeforeSipGen(lstDocumentType);

      // ajout gestion des exceptions
      // ajouter un parametre qui represente le nom du sip
      // ajouter un parametre qui represente le path de sorti du SIP
      sipGenerator.generateSip(lstDocumentDtoResult);


    }

  }


  private List<DocumentDto> checkAndPrepareDocsBeforeSipGen(final List<DocumentType> lstDocumentType) {
    final List<DocumentDto> lstDocumentDtoResult = new ArrayList<>();

    if (lstDocumentType != null) {

      final List<DocumentDto> lstDocumentDto = toLstDocumentDto(lstDocumentType);
      List<LogDocumentType> lstLogDocument;
      for (final DocumentDto documentDto : lstDocumentDto) {
        lstLogDocument = checkDataDocument(documentDto);

        if (lstLogDocument.isEmpty()) {
          lstDocumentDtoResult.add(documentDto);

          // ici mettre le statut du document à CREATION_SIP
        } else {
          // ici mettre le statut du document à ERREUR

        }

        LogDocumentType tmpLogDocument;

        // on verifie la présence de la donnée hash Scelle
        if (documentDto.getHashScelle() == null || documentDto.getHashScelle().trim().isEmpty()) {
          DatabaseAccessImpl.LOGGER.info("Integration d'un document dans un SIP dont la donnée Hash Scelle n'est pas présente: " + documentDto);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("Integration d'un document dans un SIP dont la donnée Hash Scelle n'est pas présente: " + documentDto);
          lstLogDocument.add(tmpLogDocument);
        }

        // on verifie la présence de la donnée horodate
        if (documentDto.getBlocHorodate() == null || documentDto.getBlocHorodate().trim().isEmpty()) {
          DatabaseAccessImpl.LOGGER.info("Integration d'un document dans un SIP dont la donnée Horodatage n'est pas présente: " + documentDto);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("Integration d'un document dans un SIP dont la donnée Horodatage n'est pas présente: " + documentDto);
          lstLogDocument.add(tmpLogDocument);
        }

        // MAJ BDD
        documentMetier.addLogsToDocument(documentDto.getId(), lstLogDocument);
      }
    }

    return lstDocumentDtoResult;
  }

  private List<LogDocumentType> checkDataDocument(final DocumentDto documentDto) {
    final List<LogDocumentType> lstLogDocument = new ArrayList<>();
    if (documentDto != null) {

      LogDocumentType tmpLogDocument;
      final String documentFileName = documentDto.getPathDocument();

      // vérifier la presence de l'UUID
      if (documentDto.getUuid() == null || documentDto.getUuid().trim().isEmpty()) {
        DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car la donnée UUID n'est pas présente: " + documentDto);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car la donnée UUID n'est pas présente: " + documentDto);
        lstLogDocument.add(tmpLogDocument);
      }

      // on vérifie si le document est vraiment présent physiquement
      if (documentFileName == null || !fileStorage.exists(documentFileName)) {
        DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le document n'est pas présent physiquement: "
            + documentFileName);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le document n'est pas présent physiquement: "
            + documentFileName);
        lstLogDocument.add(tmpLogDocument);
      } else {
        // on vérifie si le fichier des métadonnées est présent physiquement
        String pathMetadataFile = FileHelper.removeFileExtension(documentFileName);
        pathMetadataFile += ".json";

        if (!fileStorage.exists(pathMetadataFile)) {
          DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le fichier des métadonnées n'est pas présent physiquement: "
              + pathMetadataFile);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le fichier des métadonnées n'est pas présent physiquement: "
              + pathMetadataFile);
          lstLogDocument.add(tmpLogDocument);
        }
      }

      // on vérifie si le format du document fait parti de la liste des formats permis à intégrer dans un SIP
      if (documentFileName != null && !mustBeAllowed(documentFileName.substring(documentFileName.lastIndexOf(File.separator) + 1))) {
        DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document dans un SIP car le format du fichier ne fait par parti de la liste des formats autorisés: "
            + allowPatternsString);
        tmpLogDocument = new LogDocumentType();
        tmpLogDocument.setMessage("impossible d'integrer ce document dans un SIP car le format du fichier ne fait parti de la liste des formats autorisés: "
            + allowPatternsString);
        lstLogDocument.add(tmpLogDocument);
      }

      // on vérifier si le document n'est pas un répertoire
      if (documentFileName != null) {
        final Path documentPath = Paths.get(documentFileName);
        if (Files.isDirectory(documentPath, java.nio.file.LinkOption.NOFOLLOW_LINKS)) {

          DatabaseAccessImpl.LOGGER.info("impossible d'integrer ce document car c'est un répertoire: "
              + documentFileName);
          tmpLogDocument = new LogDocumentType();
          tmpLogDocument.setMessage("impossible d'integrer ce document car c'est un répertoire: "
              + documentFileName);
          lstLogDocument.add(tmpLogDocument);

        }

      }

    }

    return lstLogDocument;
  }

  private List<DocumentDto> toLstDocumentDto(final List<DocumentType> lstDocumentType) {
    final List<DocumentDto> lstDocumentDto = new ArrayList<>();

    if (lstDocumentType != null) {
      DocumentDto tmpDocumentDto;
      for (final DocumentType documentType : lstDocumentType) {
        tmpDocumentDto = new DocumentDto();
        tmpDocumentDto.setBlocHorodate(documentType.getBlocHorodate());
        tmpDocumentDto.setHashScelle(documentType.getHashScelle());
        tmpDocumentDto.setPathDocument(documentType.getPathDocument());
        tmpDocumentDto.setUuid(documentType.getUuid());
        tmpDocumentDto.setId(documentType.getId());

        lstDocumentDto.add(tmpDocumentDto);

      }
    }

    return lstDocumentDto;
  }

  /**
   * Test if a file name is compliant to one of allow patterns.
   *
   * @param fileName
   *          the file name string to test
   */
  private boolean mustBeAllowed(final String fileName) {
    boolean doMatch = false;
    for (final Pattern p : allowPatterns) {
      if (p.matcher(fileName).matches()) {
        doMatch = true;
        break;
      }
    }
    return doMatch;
  }
}
