package fr.acoss.dory.agent.gen.sip.core.tools.utils;

/**
 * Class for all exceptions thrown by the SEDALib classes
 * <p>
 * These exceptions are always fatal for the process.
 */
public class SEDALibException extends Exception {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -4184545314543900727L;

  /**
   * Instantiates a new SEDALib exception.
   *
   * @param message
   *            the message
   */
  public SEDALibException(final String message) {
    super(message);
  }

  /**
   * Instantiates a new SEDALib exception.
   *
   * @param message
   *            the message
   * @param cause
   *            the cause
   */
  public SEDALibException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
