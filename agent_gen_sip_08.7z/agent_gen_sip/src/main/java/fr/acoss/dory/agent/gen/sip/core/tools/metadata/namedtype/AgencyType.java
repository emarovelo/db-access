package fr.acoss.dory.agent.gen.sip.core.tools.metadata.namedtype;


import java.util.LinkedHashMap;

import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;

/**
 * The Class AgencyType.
 * <p>
 * For abstract agency type SEDA metadata
 */
public class AgencyType extends ComplexListType {

  /**
   * Init metadata map.
   */
  @ComplexListMetadataMap
  static final public LinkedHashMap<String, ComplexListMetadataKind> metadataMap;
  static {
    metadataMap = new LinkedHashMap<>();
    metadataMap.put("Identifier", new ComplexListMetadataKind(StringType.class, false));
    metadataMap.put("OrganisationDescriptiveMetadata", new ComplexListMetadataKind(AnyXMLType.class, false));
  }

  /**
   * Instantiates a new agency type.
   *
   * @param elementName the element name
   */
  public AgencyType(final String elementName) {
    super(elementName);
  }

  /**
   * Instantiates a new agency type with identifier.
   *
   * @param elementName the element name
   * @param identifier  the identifier
   */
  public AgencyType(final String elementName, final String identifier) {
    super(elementName);
    try {
      addNewMetadata("Identifier", identifier);
    } catch (final SEDALibException ignored) {
    }
  }
}
