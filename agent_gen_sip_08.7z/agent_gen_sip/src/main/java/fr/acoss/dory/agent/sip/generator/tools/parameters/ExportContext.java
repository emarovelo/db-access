package fr.acoss.dory.agent.sip.generator.tools.parameters;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import fr.acoss.dory.agent.sip.generator.tools.core.GlobalMetadata;

/**
 * The Class ExportContext.
 */
@Component
public class ExportContext {

  /**
   * The First dataobject selection mode.
   */
  static public final int FIRST_DATAOBJECT = 1;

  /**
   * The Last dataobject selection mode.
   */
  static public final int LAST_DATAOBJECT = 2;

  /**
   * The All dataobjects selection mode.
   */
  static public final int ALL_DATAOBJECTS = 3;

  // prefs elements
  /** The hierarchical archive units in SEDA manifest. */
  @Value("${exportContext.general.hierarchicalArchiveUnits:true}")
  private boolean hierarchicalArchiveUnits;

  /** The indented xml in SEDA manifest. */
  @Value("${exportContext.general.indented:true}")
  private boolean indented;

  /** The DataObjectPackage elements reindex before export flag. */
  @Value("${exportContext.general.reindex:false}")
  private boolean reindex;

  /** The csv export mode for usage_version object selection. */
  @Value("${exportContext.csvExport.usageVersionSelectionMode:2}")
  private int usageVersionSelectionMode;

  /** The csv export max name size for directories. */
  @Value("${exportContext.csvExport.maxNameSize:32}")
  private int maxNameSize;

  /** The ManagementMetadata. */
  @Value("${exportContext.general.managementMetadataXmlData}")
  private String managementMetadataXmlData;

  /** The archive transfer global metadata. */
  private GlobalMetadata globalMetadata;

  /** The descriptive metadata filter flag. */
  @Value("${exportContext.general.metadataFilterFlag:false}")
  private boolean metadataFilterFlag;

  /** The descriptive metadata kept in content. */
  private List<String> keptMetadataList;

  @Value("${exportContext.general.keptMetadataList}")
  private String keptMetadataString;

  /** The on disk output. */
  private String onDiskOutput;

  /**
   * Instantiates a new global metadata context.
   */
  public ExportContext() {
    setArchiveTransferGlobalMetadata(new GlobalMetadata());

    if (usageVersionSelectionMode < FIRST_DATAOBJECT
        || usageVersionSelectionMode > ALL_DATAOBJECTS) {
      usageVersionSelectionMode = LAST_DATAOBJECT;
    }

    if (maxNameSize < 0) {
      maxNameSize = 0;
    }

    if (keptMetadataString == null || keptMetadataString.isEmpty()) {
      keptMetadataList = new ArrayList<>();
    } else {
      keptMetadataList = Arrays.asList(keptMetadataString.split("\\s*\n\\s*"))
          .stream()
          .map(String::trim)
          .collect(Collectors.toList());
    }
  }

  /**
   * Instantiates a new GlobalMetadata from the preferences.
   *
   * @param prefs
   *          the prefs
   */
  public ExportContext(final Prefs prefs) {
    setArchiveTransferGlobalMetadata(new GlobalMetadata());
    hierarchicalArchiveUnits = Boolean.parseBoolean(prefs.getPrefProperties().getProperty("exportContext.general.hierarchicalArchiveUnits", "true"));
    indented = Boolean.parseBoolean(prefs.getPrefProperties().getProperty("exportContext.general.indented", "true"));
    reindex = Boolean.parseBoolean(prefs.getPrefProperties().getProperty("exportContext.general.reindex", "false"));
    try {
      usageVersionSelectionMode = Integer.parseInt(prefs.getPrefProperties()
                                                   .getProperty("exportContext.csvExport.usageVersionSelectionMode", Integer.toString(LAST_DATAOBJECT)));
    } catch (final NumberFormatException e) {
      usageVersionSelectionMode = LAST_DATAOBJECT;
    }
    if (usageVersionSelectionMode < FIRST_DATAOBJECT || usageVersionSelectionMode > ALL_DATAOBJECTS) {
      usageVersionSelectionMode = LAST_DATAOBJECT;
    }
    try {
      maxNameSize = Integer.parseInt(prefs.getPrefProperties().getProperty("exportContext.csvExport.maxNameSize", "32"));
    } catch (final NumberFormatException e) {
      maxNameSize = 32;
    }
    if (maxNameSize < 0) {
      maxNameSize = 0;
    }
    managementMetadataXmlData = nullIfEmpty(prefs.getPrefProperties().getProperty("exportContext.general.managementMetadataXmlData", ""));
    metadataFilterFlag = Boolean.parseBoolean(prefs.getPrefProperties().getProperty("exportContext.general.metadataFilterFlag", "false"));
    keptMetadataString = prefs.getPrefProperties().getProperty("exportContext.general.keptMetadataList", "");
    if (keptMetadataString.isEmpty()) {
      keptMetadataList = new ArrayList<>();
    } else {
      keptMetadataList = Arrays.asList(keptMetadataString.split("\\s*\n\\s*"))
          .stream()
          .map(String::trim)
          .collect(Collectors.toList());
    }

    getArchiveTransferGlobalMetadata().comment = nullIfEmpty(prefs.getPrefProperties().getProperty("exportContext.globalMetadata.comment", ""));
    getArchiveTransferGlobalMetadata().date = nullIfEmpty(prefs.getPrefProperties().getProperty("exportContext.globalMetadata.date", ""));
    getArchiveTransferGlobalMetadata().setNowFlag(Boolean.parseBoolean(prefs.getPrefProperties().getProperty("exportContext.globalMetadata.nowFlag", "true")));
    getArchiveTransferGlobalMetadata().messageIdentifier = nullIfEmpty(prefs.getPrefProperties()
                                                                       .getProperty("exportContext.globalMetadata.messageIdentifier", ""));
    getArchiveTransferGlobalMetadata().archivalAgreement = nullIfEmpty(prefs.getPrefProperties()
                                                                       .getProperty("exportContext.globalMetadata.archivalAgreement", ""));
    getArchiveTransferGlobalMetadata().codeListVersionsXmlData = nullIfEmpty(prefs.getPrefProperties()
                                                                             .getProperty("exportContext.globalMetadata.codeListVersionsXmlData", ""));
    getArchiveTransferGlobalMetadata().transferRequestReplyIdentifier = nullIfEmpty(prefs.getPrefProperties()
                                                                                    .getProperty("exportContext.globalMetadata.transferRequestReplyIdentifier",
                                                                                        ""));
    getArchiveTransferGlobalMetadata().archivalAgencyIdentifier = nullIfEmpty(prefs.getPrefProperties()
                                                                              .getProperty("exportContext.globalMetadata.archivalAgencyIdentifier", ""));
    getArchiveTransferGlobalMetadata().archivalAgencyOrganizationDescriptiveMetadataXmlData = nullIfEmpty(prefs.getPrefProperties()
                                                                                                          .getProperty("exportContext.globalMetadata.archivalAgencyOrganizationDescriptiveMetadataXmlData",
                                                                                                              ""));
    getArchiveTransferGlobalMetadata().transferringAgencyIdentifier = nullIfEmpty(prefs.getPrefProperties()
                                                                                  .getProperty("exportContext.globalMetadata.transferringAgencyIdentifier",
                                                                                      ""));
    getArchiveTransferGlobalMetadata().transferringAgencyOrganizationDescriptiveMetadataXmlData = nullIfEmpty(prefs.getPrefProperties()
                                                                                                              .getProperty("exportContext.globalMetadata.transferringAgencyOrganizationDescriptiveMetadataXmlData",
                                                                                                                  ""));
  }

  /**
   * Gets the archive transfer global metadata.
   *
   * @return the archive transfer global metadata
   */
  public GlobalMetadata getArchiveTransferGlobalMetadata() {
    return globalMetadata;
  }

  /**
   * Sets the archive transfer global metadata.
   *
   * @param globalMetadata the new archive transfer global metadata
   */
  public void setArchiveTransferGlobalMetadata(final GlobalMetadata globalMetadata) {
    this.globalMetadata = globalMetadata;
  }

  /**
   * Checks if is hierarchical archive units.
   *
   * @return true, if is hierarchical archive units
   */
  public boolean isHierarchicalArchiveUnits() {
    return hierarchicalArchiveUnits;
  }

  /**
   * Sets the hierarchical archive units.
   *
   * @param hierarchicalArchiveUnits the new hierarchical archive units
   */
  public void setHierarchicalArchiveUnits(final boolean hierarchicalArchiveUnits) {
    this.hierarchicalArchiveUnits = hierarchicalArchiveUnits;
  }

  /**
   * Checks if is indented.
   *
   * @return true, if is indented
   */
  public boolean isIndented() {
    return indented;
  }

  /**
   * Sets the indented.
   *
   * @param indented the new indented
   */
  public void setIndented(final boolean indented) {
    this.indented = indented;
  }

  /**
   * Is reindex boolean.
   *
   * @return the boolean
   */
  public boolean isReindex() {
    return reindex;
  }

  /**
   * Sets reindex.
   *
   * @param reindex the reindex
   */
  public void setReindex(final boolean reindex) {
    this.reindex = reindex;
  }

  /**
   * Gets usage version selection mode.
   *
   * @return the usage version selection mode
   */
  public int getUsageVersionSelectionMode() {
    return usageVersionSelectionMode;
  }

  /**
   * Sets usage version selection mode.
   *
   * @param usageVersionSelectionMode the usage version selection mode
   */
  public void setUsageVersionSelectionMode(final int usageVersionSelectionMode) {
    this.usageVersionSelectionMode = usageVersionSelectionMode;
  }

  /**
   * Gets max name size.
   *
   * @return the max name size
   */
  public int getMaxNameSize() {
    return maxNameSize;
  }

  /**
   * Sets max name size.
   *
   * @param maxNameSize the max name size
   */
  public void setMaxNameSize(final int maxNameSize) {
    this.maxNameSize = maxNameSize;
  }

  /**
   * Gets the management metadata xml data.
   *
   * @return the management metadata xml data
   */
  public String getManagementMetadataXmlData() {
    return managementMetadataXmlData;
  }

  /**
   * Sets the management metadata xml data.
   *
   * @param managementMetadataXmlData the new management metadata xml data
   */
  public void setManagementMetadataXmlData(final String managementMetadataXmlData) {
    this.managementMetadataXmlData = managementMetadataXmlData;
  }

  /**
   * Gets on disk output.
   *
   * @return the on disk output
   */
  public String getOnDiskOutput() {
    return onDiskOutput;
  }

  /**
   * Sets on disk output.
   *
   * @param onDiskOutput the on disk output
   */
  public void setOnDiskOutput(final String onDiskOutput) {
    this.onDiskOutput = onDiskOutput;
  }

  /**
   * Is metadata filter flag boolean.
   *
   * @return the boolean
   */
  public boolean isMetadataFilterFlag() {
    return metadataFilterFlag;
  }

  /**
   * Sets metadata filter flag.
   *
   * @param metadataFilterFlag the metadata filter flag
   */
  public void setMetadataFilterFlag(final boolean metadataFilterFlag) {
    this.metadataFilterFlag = metadataFilterFlag;
  }

  /**
   * Gets kept metadata list.
   *
   * @return the kept metadata list
   */
  public List<String> getKeptMetadataList() {
    return keptMetadataList;
  }

  /**
   * Sets kept metadata list.
   *
   * @param keptMetadataList the kept metadata list
   */
  public void setKeptMetadataList(final List<String> keptMetadataList) {
    this.keptMetadataList = keptMetadataList;
  }

  /**
   * Null if empty.
   *
   * @param s
   *          the s
   * @return the string
   */
  private static String nullIfEmpty(final String s) {
    if (s.isEmpty()) {
      return null;
    }
    return s;
  }
}
