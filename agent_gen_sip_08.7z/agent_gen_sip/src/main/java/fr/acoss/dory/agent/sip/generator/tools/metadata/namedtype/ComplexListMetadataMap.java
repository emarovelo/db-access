package fr.acoss.dory.agent.sip.generator.tools.metadata.namedtype;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ComplexListMetadataMap {
  boolean isExpandable() default false;
}
