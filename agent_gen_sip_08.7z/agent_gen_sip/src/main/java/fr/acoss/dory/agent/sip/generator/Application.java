package fr.acoss.dory.agent.sip.generator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@SpringBootApplication
@ComponentScan({
  "fr.acoss.dory.agent.sip.generator.metier",
  "fr.acoss.dory.agent.sip.generator.tools.parameters",
                "fr.acoss.dory.agent.sip.generator.taskscheduler"
})

@PropertySources({@PropertySource("classpath:application.properties"), @PropertySource("classpath:preferences.properties")})
public class Application {


  /**
   * @param args
   */
  public static void main(final String[] args) {
    SpringApplication.run(Application.class, args);

  }

}
