package fr.acoss.dory.agent.sip.generator.tools.parameters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import fr.acoss.dory.agent.sip.generator.tools.utils.SEDALibException;

/**
 * The Class Prefs.
 * <p>
 *     The preferences are in a properties file named ResipPreferences.properties. It is first searched in the
 *     application directory. If not found it's searched in the personal work directory
 *     (in windows Documents/Resip in linux ~\.resip). If not found it's created with default values in personal work
 *     directory.
 * </p>
 */
public class Prefs {

  /**
   * The preferences file name.
   */
  static public final String PREFERENCES_FILENAME = "preferences.properties";

  /** The preferences properties. */
  private Properties prefProperties;

  /** The preferences properties filename. */
  private String prefPropertiesFilename;

  /**
   * The instance.
   */
  static Prefs instance;


  /**
   * Gets the single instance of Prefs.
   *
   * @return single instance of Prefs
   */
  public static Prefs getInstance(final Path preferenceFilePath) {
    if (instance == null) {
      instance = new Prefs(preferenceFilePath);
    }
    return instance;
  }

  /**
   * Instantiates a new prefProperties.
   */
  private Prefs(final Path preferenceFilePath) {
    try {

      prefProperties = new Properties(){


        private static final long serialVersionUID = 1L;

        @Override
        public Set<Object> keySet() {
          return Collections.unmodifiableSet(new TreeSet<>(super.keySet()));
        }

        @Override
        public Set<Map.Entry<Object, Object>> entrySet() {

          final Set<Map.Entry<Object, Object>> set1 = super.entrySet();
          final Set<Map.Entry<Object, Object>> set2 = new LinkedHashSet<>(set1.size());

          final Iterator<Map.Entry<Object, Object>> iterator = set1.stream().sorted(new Comparator<Map.Entry<Object, Object>>() {

            @Override
            public int compare(final java.util.Map.Entry<Object, Object> o1, final java.util.Map.Entry<Object, Object> o2) {
              return o1.getKey().toString().compareTo(o2.getKey().toString());
            }
          }).iterator();

          while (iterator.hasNext()) {
            set2.add(iterator.next());
          }

          return set2;
        }

        @Override
        public synchronized Enumeration<Object> keys() {
          return Collections.enumeration(new TreeSet<>(super.keySet()));
        }
      };
      try {

        prefPropertiesFilename = preferenceFilePath.toString();
        load();
      } catch (final SEDALibException e) {
      }
    } catch (final Exception e) {
      System.out.println(e);
    }
  }

  // /**
  // * Creates the default prefProperties.
  // *
  // * @throws SEDALibException the resip exception
  // */
  // public void createDefaultPrefs() throws SEDALibException {
  // try {
  // final CreationContext oic = new CreationContext();
  // oic.setDefaultPrefs();
  // oic.toPrefs(this);
  // final ExportContext gmc = new ExportContext();
  // gmc.setDefaultPrefs();
  // gmc.toPrefs(this);
  // final DiskImportContext dic = new DiskImportContext();
  // dic.setDefaultPrefs();
  // dic.toPrefs(this);
  // final MailImportContext mic = new MailImportContext();
  // mic.setDefaultPrefs();
  // mic.toPrefs(this);
  // final CSVImportContext cic = new CSVImportContext();
  // cic.setDefaultPrefs();
  // cic.toPrefs(this);
  // final CSVMetadataImportContext cmic = new CSVMetadataImportContext();
  // cmic.setDefaultPrefs();
  // cmic.toPrefs(this);
  // final CSVTreeImportContext ctic = new CSVTreeImportContext();
  // ctic.setDefaultPrefs();
  // ctic.toPrefs(this);
  // final TreatmentParameters tsp = new TreatmentParameters();
  // tsp.setDefaultPrefs();
  // tsp.toPrefs(this);
  // save();
  // } catch (final Exception e) {
  // throw new SEDALibException("Panic: Can't create a default preferences file, stop");
  // }
  // }

  /**
   * Save the prefProperties in the PREFERENCES_FILENAME file.
   *
   * @throws SEDALibException the resip exception
   */
  public void save() throws SEDALibException {
    save(prefPropertiesFilename);
  }

  /**
   * Save the prefProperties in the PREFERENCES_FILENAME file.
   *
   * @param filename the filename
   * @throws SEDALibException the resip exception
   */
  public void save(final String filename) throws SEDALibException {
    try (FileOutputStream fos = new FileOutputStream(filename)) {
      prefProperties.store(fos, "Resip preferences");
    } catch (final Exception e) {
      throw new SEDALibException("Impossible de sauvegarder les préférences\n-> " + e.getMessage());
    }
  }

  /**
   * Import the prefProperties from a file.
   *
   * @throws SEDALibException the resip exception
   */
  public void load() throws SEDALibException {
    load(prefPropertiesFilename);
  }

  /**
   * Import the prefProperties from a file.
   *
   * @param filename the filename
   * @throws SEDALibException the resip exception
   */
  public void load(final String filename) throws SEDALibException {
    try (FileInputStream fis = new FileInputStream(filename)) {
      prefProperties.load(fis);
    } catch (final Exception e) {
      throw new SEDALibException("Impossible d'importer les préférences\n-> " + e.getMessage());
    }
  }

  /**
   * Gets default work dir, OS dependent.
   *
   * @return the default work dir
   */
  public static String getDefaultWorkDir() {
    if (System.getProperty("os.name").toLowerCase().contains("win")) {
      return System.getProperty("user.home") + File.separator + "Documents" + File.separator + "Resip";
    } else {
      return System.getProperty("user.home") + File.separator + ".Resip";
    }
  }

  /**
   * Gets the prefProperties.
   *
   * @return the prefProperties
   */
  public Properties getPrefProperties() {
    return prefProperties;
  }

  /**
   * Gets the prefProperties load dir.
   *
   * @return the prefProperties load dir
   * @throws SEDALibException the seda lib exception
   */
  public String getPrefsLoadDir() throws SEDALibException {
    String result = prefProperties.getProperty("global.loadDir", "");
    if (result.isEmpty()) {
      result = System.getProperty("user.home");
    }

    return result;
  }

  /**
   * Sets the prefProperties load dir from child.
   *
   * @param loadDir the new prefProperties load dir from child
   * @throws SEDALibException the seda lib exception
   */
  public void setPrefsLoadDirFromChild(final String loadDir) throws SEDALibException {
    final Path tmp = Paths.get(loadDir).toAbsolutePath().normalize().getParent();
    if (tmp != null) {
      prefProperties.setProperty("global.loadDir", tmp.toString());
      save();
    }
  }

  /**
   * Gets the prefProperties import dir.
   *
   * @return the prefProperties import dir
   * @throws SEDALibException the seda lib exception
   */
  public String getPrefsImportDir() throws SEDALibException {
    String result = prefProperties.getProperty("global.importDir", "");
    if (result.isEmpty()) {
      result = System.getProperty("user.home");
    }

    return result;
  }

  /**
   * Sets the prefProperties import dir from child.
   *
   * @param importDir the new prefProperties import dir from child
   * @throws SEDALibException the seda lib exception
   */
  public void setPrefsImportDirFromChild(final String importDir) throws SEDALibException {
    final Path tmp = Paths.get(importDir).toAbsolutePath().normalize().getParent();
    if (tmp != null) {
      prefProperties.setProperty("global.importDir", tmp.toString());
      save();
    }
  }

  /**
   * Gets the prefProperties export dir.
   *
   * @return the prefProperties export dir
   * @throws SEDALibException the seda lib exception
   */
  public String getPrefsExportDir() throws SEDALibException {
    String result = prefProperties.getProperty("global.exportDir", "");
    if (result.isEmpty()) {
      result = System.getProperty("user.home");
    }

    return result;
  }

  /**
   * Sets the prefProperties export dir from child.
   *
   * @param exportDir the new prefProperties export dir from child
   * @throws SEDALibException the seda lib exception
   */
  public void setPrefsExportDirFromChild(final String exportDir) throws SEDALibException {
    final Path tmp = Paths.get(exportDir).toAbsolutePath().normalize().getParent();
    if (tmp != null){
      prefProperties.setProperty("global.exportDir", tmp.toString());
      save();
    }
  }

  // /**
  // * Reinitialise prefProperties.
  // *
  // * @throws SEDALibException the seda lib exception
  // */
  // public void reinitialisePrefs() throws SEDALibException {
  // createDefaultPrefs();
  // }
}
