package fr.acoss.dory.agent.gen.sip.core.data;

import fr.acoss.dory.agent.gen.sip.core.tools.DataObjectPackage;
import fr.acoss.dory.agent.gen.sip.core.tools.parameters.CreationContext;
import fr.acoss.dory.agent.gen.sip.core.tools.parameters.ExportContext;

/**
 * The Class Work.
 */
public class Work {

  // Inner Object

  /** The Constant CURRENT_SERIALIZATION_VERSION. */
  static final String CURRENT_SERIALIZATION_VERSION = "1.0";



  /** The SIP export context. */
  private ExportContext exportContext;

  /** The creation context. */
  private CreationContext creationContext;

  /** The DataObjectPackage. */
  private DataObjectPackage dataObjectPackage;

  /**
   * Instantiates a new work for json serialization.
   */
  public Work() {
    this(null, null, null);
  }

  /**
   * Instantiates a new work.
   *
   * @param dataObjectPackage the archive transfer
   * @param creationContext   the creation context
   * @param exportContext     the export context
   */
  public Work(final DataObjectPackage dataObjectPackage, final CreationContext creationContext, final ExportContext exportContext) {
    this.dataObjectPackage = dataObjectPackage;
    this.creationContext = creationContext;
    this.exportContext = exportContext;
  }

  /**
   * Gets the archive transfer.
   *
   * @return the archive transfer
   */
  public DataObjectPackage getDataObjectPackage() {
    return dataObjectPackage;
  }

  /**
   * Sets the archive transfer.
   *
   * @param dataObjectPackage the new archive transfer
   */
  public void setDataObjectPackage(final DataObjectPackage dataObjectPackage) {
    this.dataObjectPackage = dataObjectPackage;
  }

  /**
   * Gets the creation context.
   *
   * @return the creation context
   */
  public CreationContext getCreationContext() {
    return creationContext;
  }

  /**
   * Sets the creation context.
   *
   * @param creationContext the new creation context
   */
  public void setCreationContext(final CreationContext creationContext) {
    this.creationContext = creationContext;
  }

  /**
   * Gets the global metadata context.
   *
   * @return the global metadata context
   */
  public ExportContext getExportContext() {
    return exportContext;
  }

  /**
   * Sets the global metadata context.
   *
   * @param exportContext the new global metadata context
   */
  public void setExportContext(final ExportContext exportContext) {
    this.exportContext = exportContext;
  }
}
