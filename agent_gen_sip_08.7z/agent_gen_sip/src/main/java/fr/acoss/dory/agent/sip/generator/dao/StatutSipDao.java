package fr.acoss.dory.agent.sip.generator.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.agent.sip.generator.model.persistance.StatutSip;

/**
 * Interface DAO de gestion de statut de sip
 */
public interface StatutSipDao extends JpaRepository<StatutSip, Long> {

  /**
   * Recherche d'un statut par son code
   * 
   * @param code
   *          String
   * @return Optional<StatutSip>
   */
  Optional<StatutSip> findByCode(String code);
}
