package fr.acoss.dory.agent.sip.generator.tools.core;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The Class ArchiveUnitList.
 * <p>
 * Class for managing list of child ArchiveUnits either by id or by object
 * reference. Those two modes are useful at different moments of process (import
 * -&lt; ID, ArchiveTransfer fusion -&lt; objects...).
 * <p>
 * It keeps inner two lists, one of ids and one of ArchiveUnit objects. At a
 * given moment only one list is defined the other one is null. So if you need
 * for example to change ArchiveUnits ID, you have before to force all
 * ArchiveUnitRefList in object reference mode by reading the object references list.
 */
public class ArchiveUnitRefList extends DataObjectPackageElement {

  /**
   * The ArchiveUnit list.
   */
  @JsonIgnore
  private List<ArchiveUnit> archiveUnitList;

  /**
   * The inDataPackageObjectId list.
   */
  private List<String> inDataObjectPackageIdList;

  /**
   * Instantiates a new ArchiveUnit references list.
   *
   * @param dataObjectPackage the DataObjectPackage containing the ArchiveUnits in list
   */
  public ArchiveUnitRefList(final DataObjectPackage dataObjectPackage) {
    super(dataObjectPackage);
    archiveUnitList = null;
    inDataObjectPackageIdList = null;
  }

  /**
   * Gets the inDataPackageObjectId list.
   *
   * @return the inDataPackageObjectId list
   */
  public List<String> getInDataObjectPackageIdList() {
    if (inDataObjectPackageIdList != null) {
      return inDataObjectPackageIdList;
    }
    if (archiveUnitList == null) {
      inDataObjectPackageIdList = new ArrayList<>(0);
    } else {
      inDataObjectPackageIdList = new ArrayList<>(archiveUnitList.size());
      for (final ArchiveUnit au : archiveUnitList) {
        inDataObjectPackageIdList.add(au.inDataPackageObjectId);
      }
    }
    archiveUnitList = null;
    return inDataObjectPackageIdList;
  }

  /**
   * Gets the ArchiveUnit objects list.
   *
   * @return the ArchiveUnit list
   */
  @JsonIgnore
  public List<ArchiveUnit> getArchiveUnitList() {
    if (archiveUnitList != null) {
      return archiveUnitList;
    }
    if (inDataObjectPackageIdList == null) {
      archiveUnitList = new ArrayList<>(0);
    } else {
      archiveUnitList = new ArrayList<>(inDataObjectPackageIdList.size());
      for (final String inSipId : inDataObjectPackageIdList) {
        archiveUnitList.add(getDataObjectPackage().getArchiveUnitById(inSipId));
      }
    }
    inDataObjectPackageIdList = null;
    return archiveUnitList;
  }

  /**
   * Adds the ArchiveUnit by object reference.
   *
   * @param archiveUnit the ArchiveUnit
   */
  public void add(final ArchiveUnit archiveUnit) {
    getArchiveUnitList().add(archiveUnit);
  }

  /**
   * Removes the ArchiveUnit by object reference.
   *
   * @param archiveUnit the ArchiveUnit
   */
  public void remove(final ArchiveUnit archiveUnit) {
    getArchiveUnitList().remove(archiveUnit);
  }

}
