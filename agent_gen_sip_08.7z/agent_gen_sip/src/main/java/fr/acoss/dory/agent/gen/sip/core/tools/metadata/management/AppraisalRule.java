package fr.acoss.dory.agent.gen.sip.core.tools.metadata.management;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import fr.acoss.dory.agent.gen.sip.core.tools.metadata.namedtype.RuleType;
import fr.acoss.dory.agent.gen.sip.core.tools.utils.SEDALibException;

/**
 * The Class AppraisalRule.
 * <p>
 * Class for SEDA element AppraisalRule
 * <p>
 * A management ArchiveUnit metadata.
 * <p>
 * Standard quote: "Gestion de la durée d’utilité administrative"
 */
public class AppraisalRule extends RuleType {

  /** The final action list. */
  static protected List<String> finalActionList;

  static {
    finalActionList = new ArrayList<>();
    finalActionList.add("Keep");
    finalActionList.add("Destroy");
  }

  /**
   * Instantiates a new appraisal rule.
   */
  public AppraisalRule() {
    super("AppraisalRule");
  }

  /**
   * Instantiates a new appraisal rule, with one rule and a date.
   *
   * @param rule        the rule
   * @param startDate   the start date
   */
  public AppraisalRule(final String rule, final LocalDate startDate) {
    super("AppraisalRule", rule, startDate);
  }

  /**
   * Instantiates a new appraisal rule, with one rule, a date and final action.
   *
   * @param rule        the rule
   * @param startDate   the start date
   * @param finalAction the final action
   * @throws SEDALibException if the FinalAction field or value is not expected in
   *                          this kind of rule
   */
  public AppraisalRule(final String rule, final LocalDate startDate, final String finalAction) throws SEDALibException {
    super("AppraisalRule", rule, startDate, finalAction);
  }

  @Override
  public List<String> getFinalActionList() {
    return finalActionList;
  }
}
