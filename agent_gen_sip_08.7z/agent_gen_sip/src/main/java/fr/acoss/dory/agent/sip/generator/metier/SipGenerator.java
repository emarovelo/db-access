package fr.acoss.dory.agent.sip.generator.metier;

import java.nio.file.Path;
import java.util.List;

/**
 * SIP generator class
 */
public interface SipGenerator {

  /**
   * Méthode appeler par le scheduler et qui permet de generer la création des SIP à envoyer à la solution vitam
   * Ces SIP sont créés à partir des documents qui sont préalablement déposés par dorybackend
   * 
   * @param lstPathDocument
   *          : la liste des documents à mettre dans le SIP
   */
  void generateSip(List<Path> lstPathDocument);

}
