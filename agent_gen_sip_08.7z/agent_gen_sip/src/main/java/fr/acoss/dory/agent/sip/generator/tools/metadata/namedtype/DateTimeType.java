package fr.acoss.dory.agent.sip.generator.tools.metadata.namedtype;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import fr.acoss.dory.agent.sip.generator.tools.utils.SEDALibException;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLEventReader;
import fr.acoss.dory.agent.sip.generator.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class StringType.
 * <p>
 * For abstract String formatted SEDA metadata
 */
public class DateTimeType extends NamedTypeMetadata {

  /**
   * The value.
   */
  private LocalDateTime value;

  /**
   * Instantiates a new string.
   */
  public DateTimeType() {
    this(null, (LocalDateTime) null);
  }

  /**
   * Instantiates a new string.
   *
   * @param elementName the XML element name
   */
  public DateTimeType(final String elementName) {
    this(elementName, (LocalDateTime) null);
  }

  /**
   * Instantiates a new string.
   *
   * @param elementName the XML element name
   * @param value       the value
   */
  public DateTimeType(final String elementName, final LocalDateTime value) {
    super(elementName);
    this.value = value;
  }

  /**
   * Instantiates a new string.
   *
   * @param elementName the XML element name
   * @param dateValue   the date (no time) value
   */
  public DateTimeType(final String elementName, final LocalDate dateValue) {
    super(elementName);
    value = dateValue.atStartOfDay();
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toSedaXml(fr.gouv.vitam.
   * tools.sedalib.xml.SEDAXMLStreamWriter)
   */
  @Override
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter) throws SEDALibException {
    try {
      if (value == null) {
        xmlWriter.writeElementValue(elementName, null);
      } else {
        xmlWriter.writeElementValue(elementName, SEDAXMLStreamWriter.getStringFromDateTime(value));
      }
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur d'écriture XML dans un élément de type DateTimeType [" + getXmlElementName() + "]\n->" + e.getMessage());
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.metadata.SEDAMetadata#toCsvList()
   */
  @Override
  public LinkedHashMap<String, String> toCsvList() throws SEDALibException {
    final LinkedHashMap<String, String> result = new LinkedHashMap<>();
    if (value != null) {
      result.put("",SEDAXMLStreamWriter.getStringFromDateTime(value));
    }
    return result;
  }

  /**
   * Import the metadata content in XML expected form from the SEDA Manifest.
   *
   * @param xmlReader the SEDAXMLEventReader reading the SEDA manifest
   * @return true, if it finds something convenient, false if not
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not respected, for example
   */
  @Override
  public boolean fillFromSedaXml(final SEDAXMLEventReader xmlReader) throws SEDALibException {
    String tmpDate;
    try {
      if (xmlReader.peekBlockIfNamed(elementName)) {
        XMLEvent event = xmlReader.nextUsefullEvent();
        elementName = event.asStartElement().getName().getLocalPart();
        event = xmlReader.nextUsefullEvent();
        if (event.isCharacters()) {
          tmpDate = event.asCharacters().getData();
          try {
            value = SEDAXMLEventReader.getDateTimeFromString(tmpDate);
          } catch (final DateTimeParseException e) {
            throw new SEDALibException("La date est mal formatée");
          }
          event = xmlReader.nextUsefullEvent();
        } else {
          value = null;
        }
        if (!event.isEndElement() || !elementName.equals(event.asEndElement().getName().getLocalPart())) {
          throw new SEDALibException("Elément " + elementName + " mal terminé");
        }
      } else {
        return false;
      }
    } catch (XMLStreamException | IllegalArgumentException | SEDALibException e) {
      throw new SEDALibException("Erreur de lecture XML dans un élément de type DateTimeType\n->" + e.getMessage());
    }
    return true;
  }

  // Getters and setters

  /**
   * Get the value
   *
   * @return the value
   */
  public LocalDateTime getValue() {
    return value;
  }

  /**
   * Sets value.
   *
   * @param value the value
   */
  public void setValue(final LocalDateTime value) {
    this.value = value;
  }
}
