package fr.acoss.dory.agent.sip.generator.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.agent.sip.generator.model.persistance.StatutDocument;

/**
 * Interface DAO de gestion de statut de document
 */
public interface StatutDocumentDao extends JpaRepository<StatutDocument, Long> {

  /**
   * Recherche d'un statut unic par son code
   * 
   * @param code
   *          String
   * @return Optional<Statut>
   */
  Optional<StatutDocument> findByCode(String code);

}
