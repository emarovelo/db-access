package fr.acoss.dorybackend.modele.dto;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DocumentType
 */
public class DocumentType   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("uuid")
  private String uuid = null;

  @JsonProperty("contratService")
  private String contratService = null;

  @JsonProperty("applicationVersante")
  private String applicationVersante = null;

  @JsonProperty("pathDocument")
  private String pathDocument = null;

  @JsonProperty("pathMetadonnee")
  private String pathMetadonnee = null;

  @JsonProperty("dateCreation")
  private OffsetDateTime dateCreation = null;

  @JsonProperty("dateMaj")
  private OffsetDateTime dateMaj = null;

  @JsonProperty("statut")
  private StatutDocument statut = null;

  @JsonProperty("metadonneeDocument")
  private String metadonneeDocument = null;

  @JsonProperty("hashScelle")
  private String hashScelle = null;

  @JsonProperty("hashNonScelle")
  private String hashNonScelle = null;

  @JsonProperty("blocHorodate")
  private String blocHorodate = null;

  @JsonProperty("clePublicCertificat")
  private String clePublicCertificat = null;

  @JsonProperty("logs")
  @Valid
  private List<LogDocumenType> logs = null;

  public DocumentType id(final Long id) {
    this.id = id;
    return this;
  }

  /**
   * Identifiant du document
   * @return id
   **/
  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  public DocumentType uuid(final String uuid) {
    this.uuid = uuid;
    return this;
  }

  /**
   * uuid du document
   * @return uuid
   **/
  public String getUuid() {
    return uuid;
  }

  public void setUuid(final String uuid) {
    this.uuid = uuid;
  }

  public DocumentType contratService(final String contratService) {
    this.contratService = contratService;
    return this;
  }

  /**
   * contrat de service
   * @return contratService
   **/
  public String getContratService() {
    return contratService;
  }

  public void setContratService(final String contratService) {
    this.contratService = contratService;
  }

  public DocumentType applicationVersante(final String applicationVersante) {
    this.applicationVersante = applicationVersante;
    return this;
  }

  /**
   * Le nom de l'application versante
   * @return applicationVersante
   **/
  public String getApplicationVersante() {
    return applicationVersante;
  }

  public void setApplicationVersante(final String applicationVersante) {
    this.applicationVersante = applicationVersante;
  }

  public DocumentType pathDocument(final String pathDocument) {
    this.pathDocument = pathDocument;
    return this;
  }

  /**
   * L url de depot du document
   * @return pathDocument
   **/
  public String getPathDocument() {
    return pathDocument;
  }

  public void setPathDocument(final String pathDocument) {
    this.pathDocument = pathDocument;
  }

  public DocumentType pathMetadonnee(final String pathMetadonnee) {
    this.pathMetadonnee = pathMetadonnee;
    return this;
  }

  /**
   * L url de depot du fichier json contenant les metadonnees du document
   * @return pathMetadonnee
   **/
  public String getPathMetadonnee() {
    return pathMetadonnee;
  }

  public void setPathMetadonnee(final String pathMetadonnee) {
    this.pathMetadonnee = pathMetadonnee;
  }

  public DocumentType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }

  /**
   * Date de creation
   * @return dateCreation
   **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public DocumentType dateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
    return this;
  }

  /**
   * Date de derniere mise  a jour (obligatoire pour les services de maj)
   * @return dateMaj
   **/
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  public DocumentType statut(final StatutDocument statut) {
    this.statut = statut;
    return this;
  }

  /**
   * Get statut
   * @return statut
   **/
  public StatutDocument getStatut() {
    return statut;
  }

  public void setStatut(final StatutDocument statut) {
    this.statut = statut;
  }

  public DocumentType metadonneeDocument(final String metadonneeDocument) {
    this.metadonneeDocument = metadonneeDocument;
    return this;
  }

  /**
   * json representant les metadonnees du document
   * @return metadonneeDocument
   **/
  public String getMetadonneeDocument() {
    return metadonneeDocument;
  }

  public void setMetadonneeDocument(final String metadonneeDocument) {
    this.metadonneeDocument = metadonneeDocument;
  }

  public DocumentType hashScelle(final String hashScelle) {
    this.hashScelle = hashScelle;
    return this;
  }

  /**
   * Hash scellé du document
   * @return hashScelle
   **/
  public String getHashScelle() {
    return hashScelle;
  }

  public void setHashScelle(final String hashScelle) {
    this.hashScelle = hashScelle;
  }

  public DocumentType hashNonScelle(final String hashNonScelle) {
    this.hashNonScelle = hashNonScelle;
    return this;
  }

  /**
   * Hash non scellé du document
   * @return hashNonScelle
   **/
  public String getHashNonScelle() {
    return hashNonScelle;
  }

  public void setHashNonScelle(final String hashNonScelle) {
    this.hashNonScelle = hashNonScelle;
  }

  public DocumentType blocHorodate(final String blocHorodate) {
    this.blocHorodate = blocHorodate;
    return this;
  }

  /**
   * Bloc horodate du document
   * @return blocHorodate
   **/
  public String getBlocHorodate() {
    return blocHorodate;
  }

  public void setBlocHorodate(final String blocHorodate) {
    this.blocHorodate = blocHorodate;
  }

  public DocumentType clePublicCertificat(final String clePublicCertificat) {
    this.clePublicCertificat = clePublicCertificat;
    return this;
  }

  /**
   * Clé public du certificat'
   * @return clePublicCertificat
   **/
  public String getClePublicCertificat() {
    return clePublicCertificat;
  }

  public void setClePublicCertificat(final String clePublicCertificat) {
    this.clePublicCertificat = clePublicCertificat;
  }

  public DocumentType logs(final List<LogDocumenType> logs) {
    this.logs = logs;
    return this;
  }

  public DocumentType addLogsItem(final LogDocumenType logsItem) {
    if (logs == null) {
      logs = new ArrayList<>();
    }
    logs.add(logsItem);
    return this;
  }

  /**
   * Logs du document
   * @return logs
   **/
  public List<LogDocumenType> getLogs() {
    return logs;
  }

  public void setLogs(final List<LogDocumenType> logs) {
    this.logs = logs;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final DocumentType documentType = (DocumentType) o;
    return Objects.equals(id, documentType.id) &&
        Objects.equals(uuid, documentType.uuid) &&
        Objects.equals(contratService, documentType.contratService) &&
        Objects.equals(applicationVersante, documentType.applicationVersante) &&
        Objects.equals(pathDocument, documentType.pathDocument) &&
        Objects.equals(pathMetadonnee, documentType.pathMetadonnee) &&
        Objects.equals(dateCreation, documentType.dateCreation) &&
        Objects.equals(dateMaj, documentType.dateMaj) &&
        Objects.equals(statut, documentType.statut) &&
        Objects.equals(metadonneeDocument, documentType.metadonneeDocument) &&
        Objects.equals(hashScelle, documentType.hashScelle) &&
        Objects.equals(hashNonScelle, documentType.hashNonScelle) &&
        Objects.equals(blocHorodate, documentType.blocHorodate) &&
        Objects.equals(clePublicCertificat, documentType.clePublicCertificat) &&
        Objects.equals(logs, documentType.logs);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, uuid, contratService, applicationVersante, pathDocument, pathMetadonnee, dateCreation, dateMaj, statut, metadonneeDocument, hashScelle, hashNonScelle, blocHorodate, clePublicCertificat, logs);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class DocumentType {\n");

    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    uuid: ").append(toIndentedString(uuid)).append("\n");
    sb.append("    contratService: ").append(toIndentedString(contratService)).append("\n");
    sb.append("    applicationVersante: ").append(toIndentedString(applicationVersante)).append("\n");
    sb.append("    pathDocument: ").append(toIndentedString(pathDocument)).append("\n");
    sb.append("    pathMetadonnee: ").append(toIndentedString(pathMetadonnee)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    dateMaj: ").append(toIndentedString(dateMaj)).append("\n");
    sb.append("    statut: ").append(toIndentedString(statut)).append("\n");
    sb.append("    metadonneeDocument: ").append(toIndentedString(metadonneeDocument)).append("\n");
    sb.append("    hashScelle: ").append(toIndentedString(hashScelle)).append("\n");
    sb.append("    hashNonScelle: ").append(toIndentedString(hashNonScelle)).append("\n");
    sb.append("    blocHorodate: ").append(toIndentedString(blocHorodate)).append("\n");
    sb.append("    clePublicCertificat: ").append(toIndentedString(clePublicCertificat)).append("\n");
    sb.append("    logs: ").append(toIndentedString(logs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

