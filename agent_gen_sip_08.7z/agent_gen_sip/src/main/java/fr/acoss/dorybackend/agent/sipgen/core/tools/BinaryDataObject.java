package fr.acoss.dorybackend.agent.sipgen.core.tools;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;

import fr.acoss.dorybackend.agent.sipgen.core.modele.dto.DocumentDto;
import fr.acoss.dorybackend.agent.sipgen.core.tools.droid.DroidIdentifier;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.SEDAMetadata;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.data.FileInfo;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.data.FormatIdentification;
import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.SEDALibException;
import fr.acoss.dorybackend.agent.sipgen.core.tools.xml.SEDAXMLEventReader;
import fr.acoss.dorybackend.agent.sipgen.core.tools.xml.SEDAXMLStreamWriter;
import uk.gov.nationalarchives.droid.core.interfaces.IdentificationResult;

/**
 * The Class BinaryDataObject.
 * <p>
 * Class for SEDA element BinaryDataObject. It contains metadata and links to
 * the binary file.
 */
public class BinaryDataObject extends DataObjectPackageIdElement implements DataObject {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(BinaryDataObject.class);

  // SEDA elements

  /**
   * The data object system id.
   */
  public String dataObjectSystemId;

  /**
   * The data object group system id.
   */
  public String dataObjectGroupSystemId;

  /**
   * The relationships xml element in String form.
   */
  public List<String> relationshipsXmlData;

  /**
   * The data object group reference id.
   */
  String dataObjectGroupReferenceId;

  /**
   * The data object group id.
   */
  String dataObjectGroupId;

  /**
   * The data object version.
   */
  public String dataObjectVersion;

  // Attachment
  // - binary content in xml not supported by SEDALib

  /**
   * The uri.
   */
  public String uri;

  /**
   * The message digest.
   */
  public String messageDigest;

  /**
   * The message digest algorithm.
   */
  public String messageDigestAlgorithm;

  /**
   * The size.
   */
  public long size;

  /**
   * The compressed.
   */
  public String compressed;

  /**
   * The format identification.
   */
  public FormatIdentification formatIdentification;

  /**
   * The file info.
   */
  public FileInfo fileInfo;

  /**
   * The Document
   */
  public DocumentDto documentDto;

  /**
   * The metadata xml element in String form.
   */
  public String metadataXmlData;

  /**
   * The other metadata xml element in String form.
   */
  public String otherMetadataXmlData;

  // Inner element
  /**
   * The DataObjectGroup in which is the BinaryDataObject, or null.
   */
  @JsonIgnore
  private DataObjectGroup dataObjectGroup;

  // Constructors

  /**
   * Instantiates a new BinaryDataObject.
   */
  public BinaryDataObject() {
    this(null, null, null, null);
  }

  /**
   * Instantiates a new BinaryDataObject.
   *
   * @param dataObjectPackage the DataObjectPackage
   */
  public BinaryDataObject(final DataObjectPackage dataObjectPackage) {
    this(dataObjectPackage, null, null, null);
  }

  /**
   * Instantiates a new BinaryDataObject.
   * <p>
   * If DataObjectPackage is defined the new ArchiveUnit is added with a generated
   * uniqID in the structure.
   *
   * @param dataObjectPackage the DataObjectPackage containing the
   *                          BinaryDataObject
   * @param path              the path defining the BinaryDataObject onDisk
   *                          representation or null
   * @param filename          the filename metadata
   * @param dataObjectVersion the DataObjectVersion
   */
  public BinaryDataObject(final DataObjectPackage dataObjectPackage, final Path path, final String filename, final String dataObjectVersion) {
    super(dataObjectPackage);
    dataObjectSystemId = null;
    dataObjectGroupSystemId = null;
    relationshipsXmlData = new ArrayList<>();
    dataObjectGroupReferenceId = null;
    dataObjectGroupId = null;
    this.dataObjectVersion = dataObjectVersion;
    uri = null;
    messageDigest = null;
    messageDigestAlgorithm = null;
    size = -1;
    compressed = null;
    formatIdentification = null;
    if (filename == null) {
      if (path != null) {
        fileInfo = new FileInfo();
        fileInfo.filename = path.getFileName().toString();
      } else {
        fileInfo = null;
      }
    } else {
      fileInfo = new FileInfo();
      fileInfo.filename = filename;
    }
    metadataXmlData = null;
    otherMetadataXmlData = null;

    if (path == null) {
      onDiskPath = null;
    } else {
      onDiskPath = path.toAbsolutePath().normalize();
    }
    dataObjectGroup = null;
    if (dataObjectPackage != null) {
      try {
        dataObjectPackage.addBinaryDataObject(this);
      } catch (final SEDALibException e) {
        // impossible as the uniqID is generated by the called function.
      }
    }
  }

  /**
   * Instantiates a new BinaryDataObject, giving the metadata in XML fragments
   * format.
   * <p>
   * If DataObjectPackage is defined the new ArchiveUnit is added with a generated
   * uniqID in the structure.
   * <p>
   * Fragment sample: <code>
   * &lt;DataObjectVersion&gt;BinaryMaster_1_DataObjectVersion&gt;
   * &lt;Uri&gt;content/ID37.zip&lt;/Uri&gt;
   * &lt;MessageDigest algorithm="SHA-512"&gt;
   * 4723e0f6f8d54cda8989ffa5809318b2369b4b0c7957deda8399c311c397c026cc1511a0494d6f8e7b474e20171c40a5d40435c95841820a08a92e844b960947
   * &lt;/MessageDigest&gt;
   * &lt;Size&gt;1466&lt;/Size&gt;
   * &lt;FormatIdentification&gt;
   * &lt;FormatLitteral&gt;ZIP Format&lt;/FormatLitteral&gt;
   * &lt;MimeType&gt;application/zip&lt;/MimeType&gt;
   * &lt;FormatId&gt;x-fmt/263&lt;/FormatId&gt;
   * &lt;/FormatIdentification&gt;
   * &lt;FileInfo&gt;
   * &lt;Filename&gt;OK-RULES-MDRULES.zip&lt;/Filename&gt;
   * &lt;LastModified&gt;2018-08-28T19:22:19Z&lt;/LastModified&gt;
   * &lt;/FileInfo&gt;
   * </code>
   *
   * @param dataObjectPackage the DataObjectPackage
   * @param xmlData           the raw XML content describing this BinaryDataObject
   *                          in manifest but without DataObjectGroup ID or RefID
   *                          information
   * @throws SEDALibException if any xmlData reading exception
   */
  public BinaryDataObject(final DataObjectPackage dataObjectPackage, final String xmlData) throws SEDALibException {
    this(dataObjectPackage);
    fromSedaXmlFragments(xmlData);
  }

  // Methods

  /**
   * Gets the extension of a file name.
   *
   * @param fileName the file name
   * @return the extension
   */
  private static String getExtension(final String fileName) {
    if (fileName == null) {
      return "";
    }
    final int i = fileName.lastIndexOf('.');
    return i < 0 ? "seda" : fileName.substring(i + 1);
  }

  /**
   * Gets the digest sha 512.
   *
   * @return the digest sha 512
   * @throws SEDALibException if unable to get digest
   */
  private String getDigestSha512() throws SEDALibException {
    MessageDigest messageDigest;
    // tentative de mobilisation de l'algorithme de hashage SHA-512
    BinaryDataObject.LOGGER.info("tentative de mobilisation de l'algorithme de hashage SHA-512");
    try {
      messageDigest = MessageDigest.getInstance("SHA-512");
    } catch (final NoSuchAlgorithmException e1) {
      throw new SEDALibException("Impossible de mobiliser l'algorithme de hashage SHA-512");
    }
    // tentative de calcul du hash du fichier
    try (InputStream is = new BufferedInputStream(Files.newInputStream(onDiskPath))) {
      final byte[] buffer = new byte[4096];
      for (int read; (read = is.read(buffer)) != -1; ) {
        messageDigest.update(buffer, 0, read);
      }
    } catch (final Exception e) {
      throw new SEDALibException(
                                 "Impossible de calculer le hash du fichier [" + onDiskPath.toString() + "]->" + e.getMessage());
    }

    // Convert the byte to hex format
    try (Formatter formatter = new Formatter()) {
      for (final byte b : messageDigest.digest()) {
        formatter.format("%02x", b);
      }
      return formatter.toString();
    } catch (final Exception e) {
      throw new SEDALibException(
                                 "Impossible d'encoder le hash du fichier [" + onDiskPath.toString() + "]->" + e.getMessage());
    }
  }

  /**
   * Extract technical elements (lastmodified date, size, format, digest...) from
   * file and complete the BinaryDataObject metadata.
   *
   * @throws SEDALibException if unable to get size or lastmodified date (probably
   *                          can't access file)
   */
  public void extractTechnicalElements() throws SEDALibException {
    IdentificationResult ir = null;
    String lfilename = null;
    long lsize;
    FileTime llastModified;

    if (fileInfo != null && fileInfo.filename != null) {
      lfilename = fileInfo.filename;
    }
    try {
      lsize = Files.size(onDiskPath);
      if (lfilename == null) {
        lfilename = onDiskPath.getFileName().toString();
      }
      llastModified = Files.getLastModifiedTime(onDiskPath);
    } catch (final IOException e) {
      throw new SEDALibException("Impossible de générer les infos techniques pour le fichier ["
          + onDiskPath.toString() + "]\n->" + e.getMessage());
    }

    messageDigestAlgorithm = "SHA-512";
    messageDigest = getDigestSha512();
    size = lsize;

    try {
      ir = DroidIdentifier.getInstance().getIdentificationResult(onDiskPath);
    } catch (final SEDALibException e) {
      BinaryDataObject.LOGGER.error("Impossible de faire l'identification Droid pour le fichier ["
          + onDiskPath.toString() + "]\n->" + e.getMessage());

    }
    if (ir != null) {
      formatIdentification = new FormatIdentification(ir.getName(), ir.getMimeType(), ir.getPuid(), null);
    } else {
      formatIdentification = new FormatIdentification("Unknown", null, "UNKNOWN", null);
    }

    if (fileInfo == null) {
      fileInfo = new FileInfo();
    }
    if (fileInfo.filename == null) {
      fileInfo.filename = lfilename;
    }
    fileInfo.lastModified = llastModified;
  }

  /**
   * Change null values of String to "non défini".
   *
   * @param a a String
   * @return the transformed string
   */
  private String undefined(final String a) {
    if (a == null) {
      return "non défini";
    } else {
      return a;
    }
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    String result;
    try {
      result = "DataObjectVersion: " + undefined(dataObjectVersion);
      if (fileInfo == null) {
        result += "\nPas d'éléments FileInfo";
      } else {
        result += "\nNom: " + undefined(fileInfo.filename);
        if (fileInfo.lastModified != null) {
          result += "\nModifié le:" + fileInfo.lastModified.toString();
        }
      }
      if (size == -1) {
        result += "\nTaille inconnue";
      } else {
        result += "\nTaille: " + size + " octets";
      }
      result += "\nSIP Id: " + undefined(inDataPackageObjectId);
      result += "\nURI: " + undefined(uri);
      if (formatIdentification == null) {
        result += "\nPas d'éléments FormatIdentification";
      } else {
        result += "\nMimeType: " + undefined(formatIdentification.mimeType) + "\nPUID: "
            + undefined(formatIdentification.formatId) + "\nFormat: "
            + undefined(formatIdentification.formatLitteral);
      }
      result += "\nDigest: " + undefined(messageDigestAlgorithm) + " - " + undefined(messageDigest);
      if (onDiskPath == null) {
        result += "\nPath: null";
      } else {
        result += "\nPath: " + undefined(onDiskPath.toString());
      }
      if (metadataXmlData != null) {
        result += "\nMetadata:\n" + metadataXmlData;
      }
      if (otherMetadataXmlData != null) {
        result += "\nOtherMetadata:\n" + otherMetadataXmlData;
      }
    } catch (final Exception e) {
      return "Can't give elements-" + super.toString();
    }
    return result;
  }

  // SEDA XML exporter

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.core.DataObject#toSedaXml(fr.gouv.vitam.tools.
   * sedalib.xml.SEDAXMLStreamWriter)
   */
  @Override
  public void toSedaXml(final SEDAXMLStreamWriter xmlWriter)
      throws InterruptedException, SEDALibException {
    try {
      xmlWriter.writeStartElement("BinaryDataObject");
      xmlWriter.writeAttributeIfNotEmpty("id", inDataPackageObjectId);
      xmlWriter.writeElementValueIfNotEmpty("DataObjectSystemId", dataObjectSystemId);
      xmlWriter.writeElementValueIfNotEmpty("DataObjectGroupSystemId", dataObjectGroupSystemId);
      for (final String rXmlData : relationshipsXmlData) {
        xmlWriter.writeRawXMLBlockIfNotEmpty(rXmlData);
      }
      //		dataObjectGroupReferenceId not used in 2.1 DataObjectGroup mode
      //		dataObjectGroupId not used in 2.1 DataObjectGroup mode
      xmlWriter.writeElementValueIfNotEmpty("DataObjectVersion", dataObjectVersion);
      uri = "content/" + inDataPackageObjectId
          + (fileInfo != null && fileInfo.filename != null ? "." + getExtension(fileInfo.filename)
          : "");
      xmlWriter.writeElementValueIfNotEmpty("Uri", uri);
      if (messageDigest != null) {
        xmlWriter.writeStartElement("MessageDigest");
        xmlWriter.writeAttribute("algorithm", messageDigestAlgorithm);
        xmlWriter.writeCharacters(messageDigest);
        xmlWriter.writeEndElement();
      }
      xmlWriter.writeElementValueIfNotEmpty("Size", Long.toString(size));
      xmlWriter.writeElementValueIfNotEmpty("Compressed", compressed);
      if (formatIdentification != null) {
        formatIdentification.toSedaXml(xmlWriter);
      }
      if (fileInfo != null) {
        fileInfo.toSedaXml(xmlWriter);
      }
      xmlWriter.writeRawXMLBlockIfNotEmpty(metadataXmlData);
      xmlWriter.writeRawXMLBlockIfNotEmpty(otherMetadataXmlData);
      xmlWriter.writeEndElement();
    } catch (final XMLStreamException e) {
      throw new SEDALibException(
                                 "Erreur d'écriture XML du BinaryDataObject [" + inDataPackageObjectId + "]\n->" + e.getMessage());
    }

    final int counter = getDataObjectPackage().getNextInOutCounter();
    BinaryDataObject.LOGGER.error(Integer.toString(counter) + " DataObject (métadonnées) exportés\"");

  }

  /*
   * (non-Javadoc)
   *
   * @see fr.gouv.vitam.tools.sedalib.core.DataObject#toSedaXmlFragments()
   */
  @Override
  public String toSedaXmlFragments() throws SEDALibException {
    String result;
    try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SEDAXMLStreamWriter xmlWriter = new SEDAXMLStreamWriter(baos, 2)) {
      toSedaXml(xmlWriter);
      xmlWriter.close();
      result = baos.toString("UTF-8");
    } catch (SEDALibException | XMLStreamException | InterruptedException | IOException e) {
      throw new SEDALibException("Erreur interne ->" + e.getMessage());
    }
    if (result != null) {
      if (result.isEmpty()) {
        result = null;
      } else {
        result = result.replaceFirst("\\<BinaryDataObject .*\\>", "");
        result = result.substring(0, result.lastIndexOf("</BinaryDataObject>") - 1);
        result = result.trim();
      }
    }
    return result;
  }

  // SEDA XML importer

  /**
   * Read the BinaryDataObject element content in XML expected form from the SEDA
   * Manifest in the ArchiveTransfer. Utility methods for fromSedaXml and
   * fromSedaXmlFragments
   *
   * @param xmlReader the SEDAXMLEventReader reading the SEDA manifest
   * @throws SEDALibException if the XML can't be read or the SEDA scheme is not
   *                          respected
   */
  private void setFromXmlContent(final SEDAXMLEventReader xmlReader)
      throws SEDALibException {
    String tmp;
    try {
      dataObjectSystemId = xmlReader.nextValueIfNamed("DataObjectSystemId");
      dataObjectGroupSystemId = xmlReader.nextValueIfNamed("DataObjectGroupSystemId");
      while (true) {
        tmp = xmlReader.nextValueIfNamed("Relationship");
        if (tmp != null) {
          relationshipsXmlData.add(tmp);
        } else {
          break;
        }
      }
      dataObjectGroupReferenceId = xmlReader.nextValueIfNamed("DataObjectGroupReferenceId");
      dataObjectGroupId = xmlReader.nextValueIfNamed("DataObjectGroupId");
      dataObjectVersion = xmlReader.nextValueIfNamed("DataObjectVersion");
      if (xmlReader.peekBlockIfNamed("Attachment")) {
        throw new SEDALibException("Elément Attachment non supporté");
      }
      uri = xmlReader.nextValueIfNamed("Uri");
      tmp = xmlReader.peekAttributeBlockIfNamed("MessageDigest", "algorithm");
      if (tmp != null) {
        messageDigestAlgorithm = tmp;
        messageDigest = xmlReader.nextValueIfNamed("MessageDigest");
      }
      tmp = xmlReader.nextValueIfNamed("Size");
      if (tmp != null) {
        size = Integer.parseInt(tmp);
      }
      compressed = xmlReader.nextValueIfNamed("Compressed");
      formatIdentification = (FormatIdentification) SEDAMetadata.fromSedaXml(xmlReader,FormatIdentification.class);
      fileInfo = (FileInfo) SEDAMetadata.fromSedaXml(xmlReader,FileInfo.class);
      metadataXmlData = xmlReader.nextBlockAsStringIfNamed("Metadata");
      otherMetadataXmlData = xmlReader.nextBlockAsStringIfNamed("OtherMetadata");
    } catch (final XMLStreamException e) {
      throw new SEDALibException("Erreur de lecture XML\n->" + e.getMessage());
    }
  }

  /**
   * Import the BinaryDataObject in XML expected form from the SEDA Manifest in
   * the DataObjectPackage.
   *
   * @param xmlReader             the SEDAXMLEventReader reading the SEDA manifest
   * @param dataObjectPackage     the DataObjectPackage to be completed
   * @param rootDir               the directory where the BinaryDataObject files are
   *                              exported
   * @return the read BinaryDataObject, or null if not a BinaryDataObject
   * @throws SEDALibException     if the XML can't be read or the SEDA scheme is
   *                              not respected
   * @throws InterruptedException if export process is interrupted
   */
  public static BinaryDataObject fromSedaXml(final SEDAXMLEventReader xmlReader, final DataObjectPackage dataObjectPackage,
                                             final String rootDir)
                                                 throws SEDALibException, InterruptedException {
    BinaryDataObject bdo = null;
    DataObjectGroup dog;
    String tmp;
    try {
      tmp = xmlReader.peekAttributeBlockIfNamed("BinaryDataObject", "id");
      if (tmp != null) {
        bdo = new BinaryDataObject();
        bdo.inDataPackageObjectId = tmp;
        dataObjectPackage.addBinaryDataObject(bdo);
        xmlReader.nextUsefullEvent();
        bdo.setFromXmlContent(xmlReader);
        xmlReader.endBlockNamed("BinaryDataObject");
      }
    } catch (XMLStreamException | SEDALibException e) {
      throw new SEDALibException("Erreur de lecture dans le BinaryDataObject"
          + (bdo != null ? " [" + bdo.inDataPackageObjectId + "]" : "") + "\n->" + e.getMessage());
    }
    //case not a BinaryDataObject
    if (bdo == null) {
      return null;
    }

    if (bdo.dataObjectGroupReferenceId != null && bdo.dataObjectGroupId != null) {
      throw new SEDALibException("Eléments DataObjectGroupReferenceId et DataObjectGroupId incompatibles");
    }
    if (bdo.dataObjectGroupId != null) {
      if (dataObjectPackage.getDataObjectGroupById(bdo.dataObjectGroupId) != null) {
        throw new SEDALibException("Elément DataObjectGroup [" + bdo.dataObjectGroupId + "] déjà créé");
      }
      dog = new DataObjectGroup();
      dog.setInDataObjectPackageId(bdo.dataObjectGroupId);
      dataObjectPackage.addDataObjectGroup(dog);
      dog.addDataObject(bdo);
      BinaryDataObject.LOGGER.info("DataObjectGroup [" + dog.inDataPackageObjectId
                                   + "] créé depuis BinaryDataObject [" + bdo.inDataPackageObjectId + "]");

    } else if (bdo.dataObjectGroupReferenceId != null) {
      dog = dataObjectPackage.getDataObjectGroupById(bdo.dataObjectGroupReferenceId);
      if (dog == null) {
        throw new SEDALibException("Erreur de référence au DataObjectGroup [" + bdo.dataObjectGroupId + "]");
      }
      dog.addDataObject(bdo);
    }
    bdo.dataObjectGroupReferenceId = null;
    bdo.dataObjectGroupId = null;
    final int counter = dataObjectPackage.getNextInOutCounter();

    BinaryDataObject.LOGGER.info(Integer.toString(counter) + " DataObject (métadonnées) importés");
    return bdo;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * fr.gouv.vitam.tools.sedalib.core.DataObject#fromSedaXmlFragments(java.lang.
   * String)
   */
  @Override
  public void fromSedaXmlFragments(final String fragments) throws SEDALibException {
    final BinaryDataObject bdo = new BinaryDataObject();

    try (ByteArrayInputStream bais = new ByteArrayInputStream(fragments.getBytes("UTF-8"));
        SEDAXMLEventReader xmlReader = new SEDAXMLEventReader(bais, true)) {
      // jump StartDocument
      xmlReader.nextUsefullEvent();
      bdo.setFromXmlContent(xmlReader);
      final XMLEvent event = xmlReader.xmlReader.peek();
      if (!event.isEndDocument()) {
        throw new SEDALibException("Il y a des champs illégaux");
      }
    } catch (XMLStreamException | SEDALibException | IOException e) {
      throw new SEDALibException("Erreur de lecture du BinaryDataObject\n->" + e.getMessage());
    }

    if (bdo.dataObjectGroupId != null || bdo.dataObjectGroupReferenceId != null) {
      throw new SEDALibException(
          "La référence à un DataObjectGroup n'est pas modifiable par édition, il ne doit pas être défini");
    }
    dataObjectSystemId = bdo.dataObjectSystemId;
    dataObjectGroupSystemId = bdo.dataObjectGroupSystemId;
    relationshipsXmlData = bdo.relationshipsXmlData;
    dataObjectVersion = bdo.dataObjectVersion;
    messageDigest = bdo.messageDigest;
    messageDigestAlgorithm = bdo.messageDigestAlgorithm;
    size = bdo.size;
    compressed = bdo.compressed;
    fileInfo = bdo.fileInfo;
    formatIdentification = bdo.formatIdentification;
    metadataXmlData = bdo.metadataXmlData;
    otherMetadataXmlData = bdo.otherMetadataXmlData;
  }

  // Getters and setters

  /**
   * Gets the DataObjectGroup reference id.
   *
   * @return the DataObjectGroup reference id
   */
  public String getDataObjectGroupReferenceId() {
    return dataObjectGroupReferenceId;
  }

  /**
   * Sets the DataObjectGroup reference id.
   *
   * @param dataObjectGroupReferenceId the new DataObject group reference id
   */
  public void setDataObjectGroupReferenceId(final String dataObjectGroupReferenceId) {
    this.dataObjectGroupReferenceId = dataObjectGroupReferenceId;
  }

  /**
   * Gets the DataObjectGroup id.
   *
   * @return the DataObjectGroup id
   */
  public String getDataObjectGroupId() {
    return dataObjectGroupId;
  }

  /**
   * Sets the DataObjectGroup id.
   *
   * @param dataObjectGroupId the new data object group id
   */
  public void setDataObjectGroupId(final String dataObjectGroupId) {
    this.dataObjectGroupId = dataObjectGroupId;
  }

  /*
   * (non-Javadoc)
   *
   * @see fr.gouv.vitam.tools.sedalib.core.DataObject#getOg()
   */
  @Override
  public DataObjectGroup getDataObjectGroup() {
    return dataObjectGroup;
  }

  /**
   * Sets the dataObjectGroup.
   *
   * @param dataObjectGroup the new DataObjectGroup
   */
  public void setDataObjectGroup(final DataObjectGroup dataObjectGroup) {
    this.dataObjectGroup = dataObjectGroup;
  }

}
