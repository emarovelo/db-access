package fr.acoss.dorybackend.modele.dto;

import java.time.OffsetDateTime;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * SipType
 */
public class SipType   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("nom")
  private String nom = null;

  @JsonProperty("urlDepot")
  private String urlDepot = null;

  @JsonProperty("requestId")
  private String requestId = null;

  @JsonProperty("dateCreation")
  private OffsetDateTime dateCreation = null;

  @JsonProperty("dateMaj")
  private OffsetDateTime dateMaj = null;

  public SipType id(final Long id) {
    this.id = id;
    return this;
  }

  /**
   * Indentifiant du SIP
   * @return id
   **/
  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  public SipType nom(final String nom) {
    this.nom = nom;
    return this;
  }

  /**
   * Le nom du SIP
   * @return nom
   **/
  public String getNom() {
    return nom;
  }

  public void setNom(final String nom) {
    this.nom = nom;
  }

  public SipType urlDepot(final String urlDepot) {
    this.urlDepot = urlDepot;
    return this;
  }

  /**
   * L url de depot du SIP
   * @return urlDepot
   **/
  public String getUrlDepot() {
    return urlDepot;
  }

  public void setUrlDepot(final String urlDepot) {
    this.urlDepot = urlDepot;
  }

  public SipType requestId(final String requestId) {
    this.requestId = requestId;
    return this;
  }

  /**
   * Le requestId transmis dans la reponse de la requete ingest-external de Vitam
   * @return requestId
   **/
  public String getRequestId() {
    return requestId;
  }

  public void setRequestId(final String requestId) {
    this.requestId = requestId;
  }

  public SipType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }

  /**
   * Date de creation
   * @return dateCreation
   **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public SipType dateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
    return this;
  }

  /**
   * Date de derniere mise a jour (obligatoire pour les services de maj)
   * @return dateMaj
   **/
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final SipType sipType = (SipType) o;
    return Objects.equals(id, sipType.id) &&
        Objects.equals(nom, sipType.nom) &&
        Objects.equals(urlDepot, sipType.urlDepot) &&
        Objects.equals(requestId, sipType.requestId) &&
        Objects.equals(dateCreation, sipType.dateCreation) &&
        Objects.equals(dateMaj, sipType.dateMaj);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, nom, urlDepot, requestId, dateCreation, dateMaj);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class SipType {\n");

    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    nom: ").append(toIndentedString(nom)).append("\n");
    sb.append("    urlDepot: ").append(toIndentedString(urlDepot)).append("\n");
    sb.append("    requestId: ").append(toIndentedString(requestId)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    dateMaj: ").append(toIndentedString(dateMaj)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

