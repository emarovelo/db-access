package fr.acoss.dorybackend.agent.sipgen.core.tools.parameters;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

/**
 * The Class DiskImportContext.
 */
public class DiskImportContext extends CreationContext {

  /**
   * The allow pattern list.
   */
  private List<String> allowPatternList;

  @Value("${importContext.disk.allowPatternList}")
  private String allowPatternsString;

  /**
   * The No link flag.
   */
  @Value("${importContext.disk.noLinkFlag:false}")
  private boolean noLinkFlag;

  /**
   * Instantiates a new disk import context.
   */
  public DiskImportContext() {
    if (allowPatternsString == null || allowPatternsString.isEmpty()) {
      allowPatternList = new ArrayList<>();
    } else {
      allowPatternList = Arrays.asList(allowPatternsString.split("\\s*\n\\s*"));
    }
  }

  /**
   * Instantiates a new disk import context.
   *
   * @param prefs
   *          the prefs
   */
  public DiskImportContext(final Prefs prefs) {
    super(prefs);
    allowPatternsString = prefs.getPrefProperties().getProperty("importContext.disk.allowPatternList", "");
    if (allowPatternsString.isEmpty()) {
      allowPatternList = new ArrayList<>();
    } else {
      allowPatternList = Arrays.asList(allowPatternsString.split("\\s*\n\\s*"));
    }
    noLinkFlag = Boolean.parseBoolean(prefs.getPrefProperties().getProperty("importContext.disk.noLinkFlag", "false"));
  }

  // Getters and setters

  /**
   * Gets the allow pattern list.
   *
   * @return the allow pattern list
   */
  public List<String> getAllowPatternList() {
    return allowPatternList;
  }

  /**
   * Sets the allow pattern list.
   *
   * @param allowPatternList
   *          the new allow pattern list
   */
  public void setAllowPatternList(final List<String> allowPatternList) {
    this.allowPatternList = allowPatternList;
  }

  /**
   * Is no link flag boolean.
   *
   * @return the boolean
   */
  public boolean isNoLinkFlag() {
    return noLinkFlag;
  }

  /**
   * Sets no link flag.
   *
   * @param noLinkFlag the no link flag
   */
  public void setNoLinkFlag(final boolean noLinkFlag) {
    this.noLinkFlag = noLinkFlag;
  }

}
