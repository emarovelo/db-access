package fr.acoss.dorybackend.agent.sipgen.core.metier;

import java.util.List;

import fr.acoss.dorybackend.agent.sipgen.core.modele.dto.DocumentDto;

/**
 * SIP generator class
 */
public interface SipCreator {

  /**
   * @param lstDocumentDto
   *          : la liste des documents à intégrer dans le SIP
   */

  /**
   * @param lstDocumentDto
   * @return le nombre de documents réellement intégrés dans le SIP
   */

  /**
   * Permet de generer un SIP à partir de la liste de DocumentDto passée en paramètre
   * 
   * @param lstDocumentDto
   *          List<DocumentDto>
   * @return la liste de DocumentDto réellement intégré dans le SIP
   */
  List<DocumentDto> generateSip(List<DocumentDto> lstDocumentDto);

}
