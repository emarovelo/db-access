package fr.acoss.dorybackend.modele.dto;

import java.time.OffsetDateTime;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * TraceStatutDocumentType
 */
public class TraceStatutDocumentType   {
  @JsonProperty("statutCode")
  private String statutCode = null;

  @JsonProperty("dateCreation")
  private OffsetDateTime dateCreation = null;

  @JsonProperty("message")
  private String message = null;

  public TraceStatutDocumentType statutCode(final String statutCode) {
    this.statutCode = statutCode;
    return this;
  }

  /**
   * Le code du statut
   * @return statutCode
   **/
  public String getStatutCode() {
    return statutCode;
  }

  public void setStatutCode(final String statutCode) {
    this.statutCode = statutCode;
  }

  public TraceStatutDocumentType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }

  /**
   * La date du changement de statut du document
   * @return dateCreation
   **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public TraceStatutDocumentType message(final String message) {
    this.message = message;
    return this;
  }

  /**
   * Message lie au changement de statut du document
   * @return message
   **/
  public String getMessage() {
    return message;
  }

  public void setMessage(final String message) {
    this.message = message;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final TraceStatutDocumentType traceStatutDocumentType = (TraceStatutDocumentType) o;
    return Objects.equals(statutCode, traceStatutDocumentType.statutCode) &&
        Objects.equals(dateCreation, traceStatutDocumentType.dateCreation) &&
        Objects.equals(message, traceStatutDocumentType.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(statutCode, dateCreation, message);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class TraceStatutDocumentType {\n");

    sb.append("    statutCode: ").append(toIndentedString(statutCode)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

