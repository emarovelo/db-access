package fr.acoss.dorybackend.tools;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The Class DataObjectRefList.
 * <p>
 * Class for managing list of contained DataObjects either by id or by object
 * reference. Those two modes are useful at different moments of process (import
 * -&lt; ID, DataObjectPackage fusion -&lt; objects...).
 * <p>
 * It keeps inner two lists, one of ids and one of DataObjects objects. At a
 * given moment only one list is defined the other one is null. So if you need
 * for example to change DataObjects ID, you have before to force all
 * DataObjectRefList in object reference mode by reading the object references list.
 */
public class DataObjectRefList extends DataObjectPackageElement {

  /**
   * The DataObject list.
   */
  @JsonIgnore
  private List<DataObject> dataObjectList;

  /**
   * The inDataPackageObjectId list.
   */
  private ArrayList<String> inDataObjectPackageIdList;

  /**
   * Instantiates a new DataObject reference list, used by deserialization.
   */
  public DataObjectRefList() {
    this(null);
  }

  /**
   * Instantiates a new DataObject reference list.
   *
   * @param dataObjectPackage the DataObjectPackage
   */
  public DataObjectRefList(final DataObjectPackage dataObjectPackage) {
    super(dataObjectPackage);
    inDataObjectPackageIdList = null;
  }

  /**
   * Gets the inDataPackageObjectId list.
   *
   * @return the inDataPackageObjectId list
   */
  public ArrayList<String> getInDataObjectPackageIdList() {
    if (inDataObjectPackageIdList != null) {
      return inDataObjectPackageIdList;
    }
    if (dataObjectList == null) {
      inDataObjectPackageIdList = new ArrayList<>(0);
    } else {
      inDataObjectPackageIdList = new ArrayList<>(dataObjectList.size());
      for (final DataObject dataObject : dataObjectList) {
        inDataObjectPackageIdList.add(dataObject.getInDataObjectPackageId());
      }
    }
    dataObjectList = null;
    return inDataObjectPackageIdList;
  }

  /**
   * Gets the DataObject list.
   *
   * @return the DataObject list
   */
  public List<DataObject> getDataObjectList() {
    if (dataObjectList != null) {
      return dataObjectList;
    }
    if (inDataObjectPackageIdList == null) {
      dataObjectList = new ArrayList<>(0);
    } else {
      dataObjectList = new ArrayList<>(inDataObjectPackageIdList.size());
      for (final String inSipId : inDataObjectPackageIdList) {
        dataObjectList.add(getDataObjectPackage().getDataObjectById(inSipId));
      }
    }
    inDataObjectPackageIdList = null;
    return dataObjectList;
  }


  /**
   * Adds the DataObject by inDataPackageObjectId.
   *
   * @param inDataObjectPackageId the inDataPackageObjectId
   */
  public void addById(final String inDataObjectPackageId) {
    getInDataObjectPackageIdList().add(inDataObjectPackageId);
  }

  /**
   * Gets the contained DataObject count.
   *
   * @return the count
   */
  @JsonIgnore
  public int getCount() {
    if (inDataObjectPackageIdList != null) {
      return inDataObjectPackageIdList.size();
    } else if (dataObjectList != null) {
      return dataObjectList.size();
    }
    return 0;
  }

  /**
   * Gets the uniq DataObjectGroup containing all DataObjects if it exists, null if not
   *
   * @return the uniq DataObjectGroup or null
   */
  @JsonIgnore
  public DataObjectGroup getNormalizedDataObjectGroup() {
    getDataObjectList();
    if (dataObjectList.size() != 1) {
      return null;
    }
    if (dataObjectList.get(0) instanceof DataObjectGroup) {
      return (DataObjectGroup) dataObjectList.get(0);
    }
    return null;
  }
}
