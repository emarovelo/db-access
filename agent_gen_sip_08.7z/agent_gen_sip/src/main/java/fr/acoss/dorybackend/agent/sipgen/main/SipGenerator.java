package fr.acoss.dorybackend.agent.sipgen.main;

/**
 *
 */
public interface SipGenerator {
  void genererSip();
}
