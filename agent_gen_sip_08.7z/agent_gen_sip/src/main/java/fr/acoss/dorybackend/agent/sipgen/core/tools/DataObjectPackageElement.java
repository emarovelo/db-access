package fr.acoss.dorybackend.agent.sipgen.core.tools;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The Class DataObjectPackageElement.
 * <p>
 * Class for SEDA elements objects in DataObjectPackage (ArchiveUnit, ArchiveUnitRefList...)
 */
public class DataObjectPackageElement {

  /**
   * The archiveTransfer.
   */
  @JsonIgnore
  private DataObjectPackage dataObjectPackage;

  /**
   * Instantiates a new DataObjectPackage element.
   *
   * @param dataObjectPackage the ArchiveTransfer
   */
  public DataObjectPackageElement(final DataObjectPackage dataObjectPackage) {
    this.dataObjectPackage = dataObjectPackage;
  }

  /**
   * Gets the DataObjectPackage.
   *
   * @return dataObjectPackage
   */
  public DataObjectPackage getDataObjectPackage() {
    return dataObjectPackage;
  }

  /**
   * Sets the DataObjectPackage.
   *
   * @param dataObjectPackage the new DataObjectPackage
   */
  public void setDataObjectPackage(final DataObjectPackage dataObjectPackage) {
    this.dataObjectPackage = dataObjectPackage;
  }
}
