package fr.acoss.dorybackend.agent.sipgen.core.tools.content;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.stream.XMLStreamException;

import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.SEDAMetadata;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.ComplexListMetadataKind;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.ComplexListMetadataMap;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.ComplexListType;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.DateTimeType;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.StringType;
import fr.acoss.dorybackend.agent.sipgen.core.tools.metadata.namedtype.TextType;
import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.SEDALibException;
import fr.acoss.dorybackend.agent.sipgen.core.tools.utils.MetadataHelper.MetadataVitam;
import fr.acoss.dorybackend.agent.sipgen.core.tools.xml.SEDAXMLStreamWriter;

/**
 * The Class Content.
 * <p>
 * Class for SEDA element Content.
 * <p>
 * A ArchiveUnit metadata.
 * <p>
 * Standard quote: "Métadonnées de description associées à un ArchiveUnit"
 */
public class Content extends ComplexListType {

  /**
   * Init metadata map.
   */
  @ComplexListMetadataMap(isExpandable = true)
  static final public LinkedHashMap<String, ComplexListMetadataKind> metadataMap;

  static {
    metadataMap = new LinkedHashMap<>();
    metadataMap.put(MetadataVitam.METADATA_DescriptionLevel.getRealeName(), new ComplexListMetadataKind(StringType.class, false));
    metadataMap.put(MetadataVitam.METADATA_Title.getRealeName(), new ComplexListMetadataKind(TextType.class, true));
    // Acoss extensions
    metadataMap.put(MetadataVitam.METADATA_CodeRND.getRealeName(), new ComplexListMetadataKind(StringType.class, false));
    metadataMap.put(MetadataVitam.METADATA_IdImageISO.getRealeName(), new ComplexListMetadataKind(StringType.class, false));
    metadataMap.put(MetadataVitam.METADATA_NumberOfFiles.getRealeName(), new ComplexListMetadataKind(StringType.class, false));
    metadataMap.put(MetadataVitam.METADATA_TypeImageISO.getRealeName(), new ComplexListMetadataKind(StringType.class, false));
    metadataMap.put(MetadataVitam.METADATA_CreationDate.getRealeName(), new ComplexListMetadataKind(StringType.class, false));
    metadataMap.put(MetadataVitam.METADATA_IdArchivage.getRealeName(), new ComplexListMetadataKind(DateTimeType.class, false));
  }

  /**
   * Instantiates a new Content.
   */
  public Content() {
    super("Content");
  }

  /**
   * Return the XML export form as the String representation, but filtered by a list of authorized inner metadata.
   *
   * @param keptMetadataList the kept metadata list
   * @return the indented XML form String
   */
  public String filteredToString(final List<String> keptMetadataList) {
    String result = null;
    try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SEDAXMLStreamWriter xmlWriter = new SEDAXMLStreamWriter(baos, 2)) {
      xmlWriter.writeStartElement(elementName);
      for (final SEDAMetadata sm : metadataList) {
        if (keptMetadataList.contains(sm.getXmlElementName())) {
          sm.toSedaXml(xmlWriter);
        }
      }
      xmlWriter.writeEndElement();
      xmlWriter.flush();
      result = baos.toString("UTF-8");
      if (result.startsWith("\n")) {
        result = result.substring(1);
      }
    } catch (XMLStreamException | IOException | SEDALibException e) {
      if (result == null) {
        result = super.toString();
      }
    }
    return result;
  }

}
