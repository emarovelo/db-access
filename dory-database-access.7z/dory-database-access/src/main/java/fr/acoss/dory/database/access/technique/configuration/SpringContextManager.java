package fr.acoss.dory.database.access.technique.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import fr.acoss.dory.database.access.technique.enumeration.EnumBeanSpring;

/**
 * Classe permettant de récupérer le contexte Spring dans les classes non managées <br/>
 * Cette classe n'est pas déclarée ici en tant que @Component ou autre, mais en tant que @Bean dans SpringContextFactory.<br />
 * Cela permet de pouvoir à la fois récupérer l'instance de SpringContextManager via la factory classique
 * et également de pouvoir la récupérer via l'injection spring.<br />
 * Le fait que SpringContextManager implémente ApplicationContextAware déclenche l'appel à setApplicationContext au démarrage.
 */
public final class SpringContextManager implements ApplicationContextAware {

  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(SpringContextManager.class);

  /**
   * Contexte
   */
  private ApplicationContext springContext;

  /**
   * Permet de récuperer un bean Spring <br/>
   * note : wrappeur sur la méthode getBean du contextSpring
   *
   * @param beanSpring
   *          le nom du bean
   * @return Object le bean
   */
  public Object getBean(final EnumBeanSpring beanSpring) {
    if (beanSpring == null) {
      throw new IllegalArgumentException("Le paramètre beanSpring doit être renseigné");
    }
    LOGGER.trace("Récupération du bean {}", beanSpring.getNomBeanSpring());

    return springContext.getBean(beanSpring.getNomBeanSpring());
  }

  /**
   * Récupère la gestion des libellés
   *
   * @return Libelles
   */
  public Libelles getLibelles() {
    return (Libelles) getBean(EnumBeanSpring.SPRING_BEAN_LIBELLES);
  }

  /**
   * Au chargement du bean par spring, récupération du contexte
   * {@inheritDoc}
   */
  @Override
  public void setApplicationContext(final ApplicationContext applicationContext) {
    springContext = applicationContext;
  }
}
