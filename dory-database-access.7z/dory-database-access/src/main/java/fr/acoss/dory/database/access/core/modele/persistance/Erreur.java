package fr.acoss.dory.database.access.core.modele.persistance;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import fr.acoss.dory.database.access.technique.modele.persistance.AbstractPersistanceMere;

/**
 * Classe de persistance pour test de gestion des erreurs
 * L'annotation length sur libelle est positionné à 128 alors qu'en base le champ a une longueur de 5
 */
@Entity
public class Erreur extends AbstractPersistanceMere implements Serializable {

  /** long serialVersionUID. */
  private static final long serialVersionUID = 1547178328610909263L;

  /** Champ id. */
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE)
  private Long id;

  /** Champs communs. */
  @NotNull
  @Length(min = 1, max = 128)
  private String libelle;

  /** Champ date creation. */
  @Column(name = "dt_creation", updatable = false)
  private OffsetDateTime dateCreation;

  /**
   * Champ date maj.
   * Utilisé pour gérer les accès concurrents.
   *
   * @See fr.recouv.appliblanche.technique.layer.dao.AbstractGenericDaoImpl.java#findByChampForUpdate()
   */
  @Column(name = "dt_maj")
  @Version
  private OffsetDateTime dateMaj;

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the libelle
   */
  public String getLibelle() {
    return libelle;
  }

  /**
   * @param libelle
   *          the libelle to set
   */
  public void setLibelle(final String libelle) {
    this.libelle = libelle;
  }

  /**
   * @return the dateCreation
   */
  @Override
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  /**
   * @param dateCreation
   *          the dateCreation to set
   */
  @Override
  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  /**
   * @return the dateMaj
   */
  @Override
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  /**
   * @param dateMaj
   *          the dateMaj to set
   */
  @Override
  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

}
