package fr.acoss.dory.database.access.core.layer.metier.impl;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import fr.acoss.dory.database.access.core.layer.dao.SipDao;
import fr.acoss.dory.database.access.core.layer.dao.StatutSipDao;
import fr.acoss.dory.database.access.core.mappeur.DocumentMappeur;
import fr.acoss.dory.database.access.core.mappeur.SipMappeur;
import fr.acoss.dory.database.access.core.modele.persistance.Document;
import fr.acoss.dory.database.access.core.modele.persistance.Sip;
import fr.acoss.dory.database.access.core.modele.persistance.StatutSip;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.DocumentType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.SipType;

/**
 * Couche métier de gestion des sip
 */
public class SipMetierImpl implements fr.acoss.dory.database.access.core.layer.metier.SipMetier {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(SipMetierImpl.class);

  /**
   * injection du dao Sip
   */
  @Resource
  private SipDao sipDao;

  /**
   * injection du dao StatutSipDao
   */
  @Resource
  private StatutSipDao statutSipDao;

  /**
   * injection du mappeur DTO / Entity Document
   */
  @Autowired
  private DocumentMappeur documentMappeur;

  /**
   * injection du mappeur DTO / Entity Sip
   */
  @Autowired
  private SipMappeur sipMappeur;

  /**
   * {@inheritDoc}
   */
  @Override
  public Optional<SipType> creerSip(final String nom, final String urlDepot, final String requestId, final List<DocumentType> lstDocumentType) {

    SipMetierImpl.LOGGER.info("Création d'un SIP avec les données suivantes:\n nom: " + nom + " url de dépôt: " + urlDepot + " request");

    final Optional<StatutSip> statut = statutSipDao.findByCode("CREE");

    if (statut.isPresent()) {
      final Sip sipToSave = new Sip();
      sipToSave.setNom(nom);
      sipToSave.setUrlDepot(urlDepot);
      sipToSave.setRequestId(requestId);
      sipToSave.setStatut(statut.get());

      // association documents <-> sip
      if (lstDocumentType != null && !lstDocumentType.isEmpty()) {
        Document tmpDocument;
        for (final DocumentType documentType : lstDocumentType) {

          // on convertit le DocumentType en Document
          tmpDocument = documentMappeur.toDocument(documentType);

          // on va essayer d'associé le document avec le nouveau SIP
          if (tmpDocument != null) {
            sipToSave.addDocument(tmpDocument);
          }
        }
      }
      return Optional.ofNullable(sipMappeur.toSipType(sipToSave));
    }

    return Optional.empty();

  }


}
