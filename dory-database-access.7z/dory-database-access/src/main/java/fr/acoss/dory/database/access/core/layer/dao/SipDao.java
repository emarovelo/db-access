package fr.acoss.dory.database.access.core.layer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.database.access.core.modele.persistance.Sip;

/**
 * Interface DAO de gestion de la table sip
 */
public interface SipDao extends JpaRepository<Sip, Long>, SipDaoCustom {

}
