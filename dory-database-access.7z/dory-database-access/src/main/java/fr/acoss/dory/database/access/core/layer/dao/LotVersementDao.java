package fr.acoss.dory.database.access.core.layer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.database.access.core.modele.persistance.LotVersement;

/**
 * Interface DAO de gestion des lots de versement
 */
public interface LotVersementDao extends JpaRepository<LotVersement, Long>, LotVersementDaoCustom {

}
