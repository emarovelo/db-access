package fr.acoss.dory.database.access.core.mappeur;

import java.util.List;

import fr.acoss.dory.database.access.core.modele.persistance.Document;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.DocumentType;
import fr.xebia.extras.selma.CollectionMappingStrategy;
import fr.xebia.extras.selma.IoC;
import fr.xebia.extras.selma.Mapper;

/**
 * Interface de mapping des documents entre entité et DTO.
 */
@Mapper(withIoC = IoC.SPRING,
withCollectionStrategy = CollectionMappingStrategy.ALLOW_GETTER,
        withIgnoreFields = {"sip", "lotVersement", "traceStatuts", "logs", "datecreation", "datemaj"})
public interface DocumentMappeur {

  /**
   * Mappe un objet DocumentType en Document.
   *
   * @param documentType
   *          DocumentType
   * @return Document
   */
  Document toDocument(DocumentType documentType);

  /**
   * Mappe un objet DocumentType en Document.
   *
   * @param documentType
   *          DocumentType
   * @param documentAMaj
   *          Document à mettre à jour
   * @return Document
   */
  Document toDocument(DocumentType documentType, Document documentAMaj);

  /**
   * Mappe un objet Document en DocumentType.
   *
   * @param document
   *          Document
   * @return DocumentType
   */
  DocumentType toDocumentType(Document document);

  /**
   * Mappe une liste d'objets Document en liste DocumentType.
   *
   * @param documents
   *          List<Document>
   * @return List<DocumentType>
   */
  List<DocumentType> toDocumentType(List<Document> document);

}
