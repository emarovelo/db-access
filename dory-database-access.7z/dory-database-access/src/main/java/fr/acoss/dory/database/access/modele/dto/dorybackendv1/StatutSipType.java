package fr.acoss.dory.database.access.modele.dto.dorybackendv1;

import java.time.OffsetDateTime;
import java.util.Objects;

/**
 * Classe qui represente le statut d'un SipType
 */
public class StatutSipType {

  /**
   * L'identifiant
   */
  private Long id = null;

  /**
   * Le code unique
   */
  private String code = null;

  /**
   * La date de création
   */
  private OffsetDateTime dateCreation = null;

  /**
   * La date de mise à jour
   */
  private OffsetDateTime dateMaj = null;

  public StatutSipType id(final Long id) {
    this.id = id;
    return this;
  }

  /**
   * Indentifiant du statut
   * 
   * @return id
   **/
  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  public StatutSipType code(final String code) {
    this.code = code;
    return this;
  }

  /**
   * code unique du statut
   * 
   * @return code
   **/
  public String getCode() {
    return code;
  }

  public void setCode(final String code) {
    this.code = code;
  }

  public StatutSipType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }

  /**
   * Date de creation
   * 
   * @return dateCreation
   **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public StatutSipType dateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
    return this;
  }

  /**
   * Date de derniere mise a jour (obligatoire pour les services de maj)
   * 
   * @return dateMaj
   **/
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final StatutSipType statutSip = (StatutSipType) o;
    return Objects.equals(id, statutSip.id) &&
        Objects.equals(code, statutSip.code) &&
        Objects.equals(dateCreation, statutSip.dateCreation) &&
        Objects.equals(dateMaj, statutSip.dateMaj);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, dateCreation, dateMaj);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class StatutSipType {\n");

    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    dateMaj: ").append(toIndentedString(dateMaj)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
