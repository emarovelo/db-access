package fr.acoss.dory.database.access.core.layer.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.database.access.core.modele.persistance.StatutSip;

/**
 * Interface DAO de gestion de la table statut_lot_versement
 */
public interface StatutSipDao extends JpaRepository<StatutSip, Long> {

  /**
   * Recherche d'un statut à partir de son code
   * 
   * @param code
   *          String
   * @return Optional<StatutSip>
   */
  Optional<StatutSip> findByCode(String code);
}
