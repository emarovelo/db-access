package fr.acoss.dory.database.access.core.layer.metier;

/**
 * Couche métier de gestion des statuts de lots de versement
 */
public interface StatutLotVersementMetier {


}
