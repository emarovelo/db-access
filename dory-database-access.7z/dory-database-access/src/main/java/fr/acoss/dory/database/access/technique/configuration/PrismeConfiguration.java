package fr.acoss.dory.database.access.technique.configuration;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

/**
 * Configuration appel à l'API Prisme
 *
 */
@Component
public class PrismeConfiguration {
  
	/** Clé */
	private static final String CLE_ACTIVATION_PRISME = "prisme.actif";

	/** Valeur attendue */
	private static final String VALEUR_ACTIVATION_PRISME = "O";

	/** Clé */
	private static final String CLE_ACTIVATION_CORS = "cors.actif";

	/** Valeur attendue */
	private static final String VALEUR_ACTIVATION_CORS = "O";

	/**
	 * Bean injecté par Spring
	 */
	@Autowired
	private MessageSource messagesSource;

	/**
	 * Indique si l'API prisme est activée ou non dans la configuration.
	 * 
	 * @return
	 */
	public boolean isPrismeActif() {
		String value = messagesSource.getMessage(CLE_ACTIVATION_PRISME, (Object[]) null, Locale.FRANCE);
		return VALEUR_ACTIVATION_PRISME.equals(value);
	}

	/**
	 * Indique si la gestion des CORS est activée ou non dans la configuration.
	 * 
	 * @return
	 */
	public boolean isCorsActif() {
		String value = messagesSource.getMessage(CLE_ACTIVATION_CORS, (Object[]) null, Locale.FRANCE);
		return VALEUR_ACTIVATION_CORS.equals(value);
	}

}
