package fr.acoss.dory.database.access.core.modele.persistance;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Version;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;

import fr.acoss.dory.database.access.technique.modele.persistance.AbstractPersistanceMere;

/**
 * Classe de persistance de la table document
 * .
 * Clef technique
 * id : séquence autoincrementé
 */
@Entity(name = "document")
public class Document extends AbstractPersistanceMere implements Serializable{


  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -3296202233336041795L;

  /** Champ id. */
  @Id
  @SequenceGenerator(name = "name_document_id_seq", sequenceName = "document_id_seq", initialValue = 1, allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "name_document_id_seq")
  private Long id;

  /** Champ uuid. */
  @NotNull
  @NotBlank
  @Column(unique = true)
  private String uuid;

  /** Champ contratservice. */
  @Column(name = "contrat_service")
  private String contratService;

  /** Champ applicationVersante. */
  @Column(name = "application_versante")
  private String applicationVersante;

  /** Champ pathdocument */
  @Column(name = "path_document")
  private String pathDocument;

  /** Champ pathmetadonnee */
  @Column(name = "path_metadonnees")
  private String pathMetadonnee;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "code_statut_document", referencedColumnName = "code", nullable = false)
  private StatutDocument statut;

  /** Champ code_statut_document. */
  @Column(name = "code_statut_document", insertable = false, updatable = false)
  private String codeStatutDocument;

  /** Champ metadata */
  @Column(name = "metadonnees_document")
  private String metadonneeDocument;

  /** Champ hashnonscelle */
  @Column(name = "hash_non_scelle")
  private String hashNonScelle;

  /** Champ hashscelle */
  @Column(name = "hash_scelle")
  private String hashScelle;

  /** Champ blochorodate */
  @Column(name = "bloc_horodate")
  private String blocHorodate;

  /** Champ clepubliccertificat */
  @Column(name = "cle_public_certificat")
  private String clePublicCertificat;

  /**
   * Log
   */
  @OneToMany(
             mappedBy = "document",
             cascade = CascadeType.ALL,
             orphanRemoval = true)
  private List<LogDocument> logs = new ArrayList<>();

  @OneToMany(
             mappedBy = "document",
             fetch = FetchType.LAZY,
             cascade = CascadeType.ALL,
             orphanRemoval = true)
  private final List<TraceStatutDocument> traceStatuts = new ArrayList<>();

  /**
   * Champ SIP.
   */
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "id_sip")
  private Sip sip;

  /** Champ id sip. */
  @Column(name = "id_sip", insertable = false, updatable = false)
  private Long idSip;

  /**
   * Champ Lot Versement
   */
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "id_lot_versement")
  private LotVersement lotVersement;

  /** Champ id lot. */
  @Column(name = "id_lot_versement", insertable = false, updatable = false)
  private Long idLot;

  /** Champ date creation. */
  @Column(name = "dt_creation", updatable = false)
  @CreatedDate
  private OffsetDateTime dateCreation;

  /**
   * Champ date maj.
   * Utilisé pour gérer les accès concurrents.
   * 
   */
  @Column(name = "dt_maj")
  @Version
  private OffsetDateTime dateMaj;

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * @param uuid
   *          the uuid to set
   */
  public void setUuid(final String uuid) {
    this.uuid = uuid;
  }

  /**
   * @return the contratService
   */
  public String getContratService() {
    return contratService;
  }

  /**
   * @param contratService
   *          the contratService to set
   */
  public void setContratService(final String contratService) {
    this.contratService = contratService;
  }

  /**
   * @return the applicationVersante
   */
  public String getApplicationVersante() {
    return applicationVersante;
  }

  /**
   * @param applicationVersante
   *          the applicationVersante to set
   */
  public void setApplicationVersante(final String applicationVersante) {
    this.applicationVersante = applicationVersante;
  }

  /**
   * @return the pathDocument
   */
  public String getPathDocument() {
    return pathDocument;
  }

  /**
   * @param pathDocument
   *          the pathDocument to set
   */
  public void setPathDocument(final String pathDocument) {
    this.pathDocument = pathDocument;
  }

  /**
   * @return the pathMetadonnee
   */
  public String getPathMetadonnee() {
    return pathMetadonnee;
  }

  /**
   * @param pathMetadonnee
   *          the pathMetadonnee to set
   */
  public void setPathMetadonnee(final String pathMetadonnee) {
    this.pathMetadonnee = pathMetadonnee;
  }

  /**
   * @return the statut
   */
  public StatutDocument getStatut() {
    return statut;
  }

  /**
   * @param statut
   *          the statut to set
   */
  public void setStatut(final StatutDocument statut) {
    this.statut = statut;
  }


  /**
   * @return the metadonneeDocument
   */
  public String getMetadonneeDocument() {
    return metadonneeDocument;
  }

  /**
   * @param metadonneeDocument
   *          the metadonneeDocument to set
   */
  public void setMetadonneeDocument(final String metadonneeDocument) {
    this.metadonneeDocument = metadonneeDocument;
  }

  /**
   * @return the hashNonScelle
   */
  public String getHashNonScelle() {
    return hashNonScelle;
  }

  /**
   * @param hashNonScelle
   *          the hashNonScelle to set
   */
  public void setHashNonScelle(final String hashNonScelle) {
    this.hashNonScelle = hashNonScelle;
  }

  /**
   * @return the hashScelle
   */
  public String getHashScelle() {
    return hashScelle;
  }

  /**
   * @param hashScelle
   *          the hashScelle to set
   */
  public void setHashScelle(final String hashScelle) {
    this.hashScelle = hashScelle;
  }

  /**
   * @return the blocHorodate
   */
  public String getBlocHorodate() {
    return blocHorodate;
  }

  /**
   * @param blocHorodate
   *          the blocHorodate to set
   */
  public void setBlocHorodate(final String blocHorodate) {
    this.blocHorodate = blocHorodate;
  }

  /**
   * @return the clePublicCertificat
   */
  public String getClePublicCertificat() {
    return clePublicCertificat;
  }

  /**
   * @param clePublicCertificat
   *          the clePublicCertificat to set
   */
  public void setClePublicCertificat(final String clePublicCertificat) {
    this.clePublicCertificat = clePublicCertificat;
  }

  /**
   * @return the logs
   */
  public List<LogDocument> getLogs() {
    return logs;
  }

  /**
   * @return the traceStatut
   */
  public List<TraceStatutDocument> getTraceStatuts() {
    return traceStatuts;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  /**
   * @return the sip
   */
  public Sip getSip() {
    return sip;
  }

  /**
   * @param sip
   *          the sip to set
   */
  public void setSip(final Sip sip) {
    this.sip = sip;
  }

  /**
   * @return the lotVersement
   */
  public LotVersement getLotVersement() {
    return lotVersement;
  }

  /**
   * @param lot
   *          the lotVersement to set
   */
  public void setLotVersement(final LotVersement lotVersement) {
    this.lotVersement = lotVersement;
  }

  /**
   * @param logs
   *          the logs to set
   */
  public void setLogs(final List<LogDocument> logs) {
    this.logs = logs;
  }

  /**
   * Permet d'ajouter un log au document
   * 
   * @param log
   */
  public void addLog(final LogDocument log) {
    // pour eviter un null pointer exception
    logs = logs == null ? new ArrayList<>() : logs;
    logs.add(log);
    log.setDocument(this);
  }

  /**
   * Permet la suppression d'un log au document
   * 
   * @param log
   */
  public void removeLog(final LogDocument log) {
    logs.remove(log);
    log.setDocument(null);
  }

  /**
   * Permet d'ajouter un TraceStatutDocument au document
   * 
   * @param traceStatutDocument
   */
  public void addTraceStatutDocument(final TraceStatutDocument traceStatutDocument) {
    traceStatuts.add(traceStatutDocument);
    traceStatutDocument.setDocument(this);
  }

  /**
   * Permet la suppression d'un TraceStatutDocument au document
   * 
   * @param traceStatutDocument
   */
  public void removeTraceStatutDocument(final TraceStatutDocument traceStatutDocument) {
    traceStatuts.remove(traceStatutDocument);
    traceStatutDocument.setDocument(null);
  }

}
