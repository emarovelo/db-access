package fr.acoss.dory.database.access.technique.configuration.datasource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import fr.acoss.dory.database.access.technique.configuration.DatasourceConfiguration;
import fr.acoss.dory.database.access.technique.contexte.ContexteUtilisateur;
import fr.acoss.dory.database.access.technique.enumeration.EnumTypeDataSource;

/**
 * Classe permettant de choisir la datasource en fonction des informations positionnées dans le contexte
 * La classe s'appuie sur le type de service (lecture ou ecriture) positionné à partir de l'annotation de type de service pour
 * envoyer soit sur la datasource en lecture seule, ou sur la datasource en lecture ecriture
 * L'objet est construit par spring {@link DatasourceConfiguration}
 */
public class RoutingDataSource extends AbstractRoutingDataSource {

  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(RoutingDataSource.class);

  /**
   * Contexte utilisateur injecté par spring
   */
  private ContexteUtilisateur contexteUtilisateur;

  @Override
  protected Object determineCurrentLookupKey() {
    // par défault utilisation de la datasource en écriture
    EnumTypeDataSource datasourceType = EnumTypeDataSource.DATASOURCE_ECRITURE;
    try {
      // si le contexte utilisateur est valorisée et qu'il s'agit d'un service en lecture seule
      if (contexteUtilisateur != null && contexteUtilisateur.isReadOnlyService()) {
        datasourceType = EnumTypeDataSource.DATASOURCE_LECTURE_SEULE;
      }

      LOGGER.trace("Datasource choisie : {}", datasourceType.name());

    } catch (final BeanCreationException e) {
      LOGGER.info("Le contexteUtilisateur est hors contexte web de type request. Ignorer l'erreur au démarrage du serveur");
      LOGGER.trace("BeanCreationException", e);
    }

    return datasourceType;

  }

  /**
   * @param ContexteUtilisateurBackImpl
   *          the ContexteUtilisateurBack to set
   */
  public final void setContexteUtilisateur(final ContexteUtilisateur contexteUtilisateur) {
    this.contexteUtilisateur = contexteUtilisateur;
  }

}
