package fr.acoss.dory.database.access.core.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import fr.acoss.dory.database.access.core.layer.dao.composite.CriteresRecherche;

/**
 * Classe permettant de gérer les critères de pagination
 */
@Component
public class PagingHelper {
	
	@Autowired
	private SortingHelper sortingHelper;
	
	public static final int DEFAULT_PAGE_SIZE = 20; 
	
	/**
	 * Permet de convertir les CriteresRecherche en PageRequest utilisée par les DAO
	 * @param criteresRecherche
	 * @return PageRequest
	 */
	public PageRequest convertCriteresToPageRequest(CriteresRecherche criteresRecherche) {
		int currentPage = criteresRecherche.getCurrentPage() == null ?  0 : criteresRecherche.getCurrentPage();
		int size = criteresRecherche.getSize() == null ? DEFAULT_PAGE_SIZE : criteresRecherche.getSize();
		Sort sort = this.sortingHelper.toSort(criteresRecherche.getTri());
		
		return PageRequest.of(currentPage, size, sort);
	}
	
}
