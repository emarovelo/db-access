package fr.acoss.dory.database.access.technique.exception;

import fr.acoss.dory.database.access.technique.configuration.SpringContextFactory;
import fr.acoss.dory.database.access.technique.constante.ConstantesTechniques;
import fr.acoss.dory.database.access.technique.enumeration.EnumCleCodeErreur;

/**
 * Un message d'erreur correspond à une erreur fonctionnelle ou technique.
 * Cette classe permet de cumuler une liste de message dans une erreur :
 * Les exceptions fonctionnelles contiennent une liste de messages
 */
public class MessageErreur { 
  /**
   * la clé du code d'erreur : représente la clé dans le fichier de propriété.
   */
  private final EnumCleCodeErreur cleCodeErreur;

  /**
   * le code d'erreur
   */
  private final String codeErreur;

  /**
   * la description
   */
  private final String description;

  /**
   * le message
   */
  private final String message;

  /**
   * Constructeur permet de récupérer l'ensemble des champs du message :
   * <ul>
   * <li>cleCodeErreur</li>
   * <li>message</li>
   * <li>description</li>
   * </ul>
   *
   * @param cleCodeErreur
   */
  public MessageErreur(final EnumCleCodeErreur cleCodeErreur) {
    this.cleCodeErreur = cleCodeErreur;
    this.message = SpringContextFactory.springContextManager().getLibelles().getMessageFromCodeErreur(cleCodeErreur);
    this.description = SpringContextFactory.springContextManager().getLibelles().getDescriptionFromCodeErreur(cleCodeErreur);
    this.codeErreur = SpringContextFactory.springContextManager().getLibelles().getCodeFromCodeErreur(cleCodeErreur);
  }

  /**
   * Constructeur pour les erreurs techniques : il permet de récupérer le message de l'exception source
   *
   * @param cleCodeErreur
   * @param description
   */
  public MessageErreur(final EnumCleCodeErreur cleCodeErreur, final String description) {
    this.cleCodeErreur = cleCodeErreur;
    this.message = SpringContextFactory.springContextManager().getLibelles().getMessageFromCodeErreur(cleCodeErreur);
    this.description = description;
    this.codeErreur = SpringContextFactory.springContextManager().getLibelles().getCodeFromCodeErreur(cleCodeErreur);
  }

  /**
   * Constructeur pour les erreurs techniques : il permet de récupérer le message de l'exception source
   *
   * @param cleCodeErreur
   * @param objs
   */
  public MessageErreur(final EnumCleCodeErreur cleCodeErreur, final Object... objs) {
    this.cleCodeErreur = cleCodeErreur;
    this.message = SpringContextFactory.springContextManager().getLibelles().getMessageFromCodeErreur(cleCodeErreur, objs);
    this.description = SpringContextFactory.springContextManager().getLibelles().getDescriptionFromCodeErreur(cleCodeErreur);
    this.codeErreur = SpringContextFactory.springContextManager().getLibelles().getCodeFromCodeErreur(cleCodeErreur);
  }

  /**
   * @return Le cleCodeErreur.
   */
  public EnumCleCodeErreur getCleCodeErreur() {
    return cleCodeErreur;
  }

  /**
   * @return Le codeErreur.
   */
  public String getCodeErreur() {
    return codeErreur;
  }

  /**
   * @return Le description.
   */
  public String getDescription() {
    return description;
  }

  /**
   * @return Le message.
   */
  public String getMessage() {
    return message;
  }

  @Override
  public String toString() {
    return this.getCodeErreur() + ConstantesTechniques.SEPARATEUR_NIV1 + this.getMessage() + ConstantesTechniques.SEPARATEUR_NIV1 + this.getDescription();
  }

}
