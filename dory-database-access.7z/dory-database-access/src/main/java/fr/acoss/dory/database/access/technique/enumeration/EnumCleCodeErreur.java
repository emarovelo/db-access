package fr.acoss.dory.database.access.technique.enumeration;

import fr.acoss.dory.database.access.technique.configuration.Libelles;

/**
 * Enumération contenant les codes d'erreur liés aux fichiers de propriétés
 *
 * @see Libelles
 *      Tout libellé ajouté dans les fichiers erreurs doivent être mappés dans cet enum
 * @see dorybackend-configuration : \src\main\resources\erreurs.properties
 */
public enum EnumCleCodeErreur {
  // Socle technique
  ERREUR_TECHNIQUE_GENERIQUE("erreur.technique.generique"),
  ERREUR_CONCURRENCE("erreur.technique.concurrence"),
  ERREUR_VALIDATION("erreur.validation"),


  // Code métier
  ERREUR_DOCUMENT_INEXISTANTE("erreur.document.inexistant");

  /**
   * Code lié au fichier de propriété
   */
  private String cle;

  /**
   * Constructeur
   */
  private EnumCleCodeErreur(final String cle) {
    this.cle = cle;
  }

  /**
   * Récupère le code ie la clé du fichier de propriété
   *
   * @return cle
   */
  public String getValeur() {
    return cle;
  };
}
