package fr.acoss.dory.database.access.core.layer.dao;

import java.util.List;

import fr.acoss.dory.database.access.core.layer.dao.composite.CriteresRechercheLotVersement;
import fr.acoss.dory.database.access.core.modele.persistance.LotVersement;

/**
 * Interface DAO de gestion des lots de versement
 */
public interface LotVersementDaoCustom {

  /**
   * Recherche de la liste des lots de versement en filtrant selon des criteres.
   *
   * @param criteres
   *          CriteresRechercheLotVersement
   * @return List<LotVersement>
   */
  List<LotVersement> rechercherLotVersement(CriteresRechercheLotVersement criteres);

  /**
   * @param criteres
   *          CriteresRechercheLotVersement
   * @return le nombre lots de versment correspondant aux criteres
   */
  long compterLotVersement(final CriteresRechercheLotVersement criteres);
}
