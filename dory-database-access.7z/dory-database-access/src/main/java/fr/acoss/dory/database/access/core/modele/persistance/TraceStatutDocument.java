package fr.acoss.dory.database.access.core.modele.persistance;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedDate;

import fr.acoss.dory.database.access.technique.modele.persistance.AbstractPersistanceMere;

/**
 * Classe de persistance de la table tracestatutdocument
 * .
 * Clef technique
 * id : séquence autoincrementé
 */
@Entity(name = "historique_statut_document")
public class TraceStatutDocument extends AbstractPersistanceMere implements Serializable {


  private static final long serialVersionUID = -5758489399652878554L;

  /** Champ id. */
  @Id
  @SequenceGenerator(name = "historique_statut_document_id_seq",
  sequenceName = "historique_statut_document_id_seq_name",
  initialValue = 1,
  allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "historique_statut_document_id_seq")
  private Long id;

  /** Champ date statutcode. */
  @Column(name = "code_statut")
  private String statutCode;

  /** Champ date message. */
  private String message;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "id_document")
  private Document document;

  /** Champ date creation. */
  @Column(name = "dt_creation", updatable = false)
  @CreatedDate
  private OffsetDateTime dateCreation;

  /**
   * Champ date maj.
   * Utilisé pour gérer les accès concurrents.
   * 
   * @See fr.recouv.appliblanche.technique.layer.dao.AbstractGenericDaoImpl.java#findByChampForUpdate()
   */
  @Column(name = "dt_maj")
  @Version
  private OffsetDateTime dateMaj;

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * @param message
   *          the message to set
   */
  public void setMessage(final String message) {
    this.message = message;
  }

  /**
   * @return the document
   */
  public Document getDocument() {
    return document;
  }

  /**
   * @param document
   *          the document to set
   */
  public void setDocument(final Document document) {
    this.document = document;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  /**
   * @return the statutCode
   */
  public String getStatutCode() {
    return statutCode;
  }

  /**
   * @param statutCode
   *          the statutCode to set
   */
  public void setStatutCode(final String statutCode) {
    this.statutCode = statutCode;
  }

}
