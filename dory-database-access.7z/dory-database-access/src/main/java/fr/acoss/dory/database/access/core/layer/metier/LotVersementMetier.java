package fr.acoss.dory.database.access.core.layer.metier;

import java.util.List;

import fr.acoss.dory.database.access.core.layer.metier.composite.CriteresRechercheLotVersementType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.DocumentType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.LotVersementType;

/**
 * Couche métier de gestion des lots de versement
 */
public interface LotVersementMetier {

  /**
   * Rechercher les lots de versement.
   * 
   * @param criteres
   *          CriteresRechercheLotVersementType
   * @return List<LotVersementType>
   */
  List<LotVersementType> rechercherLots(CriteresRechercheLotVersementType criteres);

  /**
   * Recupérer un lot de versement.
   * 
   * @param idLot
   *          Long
   * @return LotVersementType
   */
  LotVersementType recupererLot(Long idLot);

  /**
   * Crée un lot de versement
   * 
   * @param lotVersementType
   *          LotVersementType
   * @param documents
   *          List<DocumentType>
   * @return
   */
  Long creerLot(LotVersementType lotVersementType, List<DocumentType> documents);
}
