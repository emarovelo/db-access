package fr.acoss.dory.database.access.core.layer.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.database.access.core.modele.persistance.StatutDocument;

/**
 * Interface DAO de gestion de la table statut_document
 */
public interface StatutDocumentDao extends JpaRepository<StatutDocument, Long> {

  /**
   * Recherche d'un statut à partir de son code
   * 
   * @param code
   *          String
   * @return Optional<Statut>
   */
  Optional<StatutDocument> findByCode(String code);

}
