package fr.acoss.dory.database.access.modele.dto.dorybackendv1;

import java.time.OffsetDateTime;
import java.util.Objects;

import org.springframework.validation.annotation.Validated;

/**
 * LotVersementType
 */
@Validated
public class LotVersementType {

  /**
   * L'identifiant
   */
  private Long id = null;

  /**
   * Le nom du lot de versement
   */
  private String nom = null;

  /**
   * L'url de dépôt du lot de versement
   */
  private String urlDepot = null;

  /**
   * Le statut du lot de versement
   */
  private StatutLotVersementType statutLotVersement = null;

  /**
   * La date de création du lot de versement
   */
  private OffsetDateTime dateCreation = null;

  /**
   * La date de mise à jour du lot de versement
   */
  private OffsetDateTime dateMaj = null;

  public LotVersementType id(final Long id) {
    this.id = id;
    return this;
  }

  /**
   * Indentifiant du lot de versement
   * 
   * @return id
   **/
  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  public LotVersementType nom(final String nom) {
    this.nom = nom;
    return this;
  }

  /**
   * Le nom du lot de versement
   * 
   * @return nom
   **/
  public String getNom() {
    return nom;
  }

  public void setNom(final String nom) {
    this.nom = nom;
  }

  public LotVersementType urlDepot(final String urlDepot) {
    this.urlDepot = urlDepot;
    return this;
  }

  /**
   * L url de depot du lot de versement
   * 
   * @return urlDepot
   **/
  public String getUrlDepot() {
    return urlDepot;
  }

  public void setUrlDepot(final String urlDepot) {
    this.urlDepot = urlDepot;
  }

  public LotVersementType statutLotVersement(final StatutLotVersementType statutLotVersement) {
    this.statutLotVersement = statutLotVersement;
    return this;
  }

  /**
   * Statut du lot de versement
   * 
   * @return statutLotVersement
   **/
  public StatutLotVersementType getStatutLotVersement() {
    return statutLotVersement;
  }

  public void setStatutLotVersement(final StatutLotVersementType statutLotVersement) {
    this.statutLotVersement = statutLotVersement;
  }

  public LotVersementType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }


  /**
   * Date de creation
   * 
   * @return dateCreation
   **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public LotVersementType dateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
    return this;
  }

  /**
   * Date de derniere mise a jour (obligatoire pour les services de maj)
   * 
   * @return dateMaj
   **/
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final LotVersementType lotVersementType = (LotVersementType) o;
    return Objects.equals(id, lotVersementType.id) &&
        Objects.equals(nom, lotVersementType.nom) &&
        Objects.equals(urlDepot, lotVersementType.urlDepot) &&
        Objects.equals(dateCreation, lotVersementType.dateCreation) &&
        Objects.equals(dateMaj, lotVersementType.dateMaj);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, nom, urlDepot, dateCreation, dateMaj);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class LotVersementType {\n");

    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    nom: ").append(toIndentedString(nom)).append("\n");
    sb.append("    urlDepot: ").append(toIndentedString(urlDepot)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    dateMaj: ").append(toIndentedString(dateMaj)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

