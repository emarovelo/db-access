package fr.acoss.dory.database.access.core.mappeur;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import fr.acoss.dory.database.access.core.layer.metier.composite.PageType;

/**
 * Classe assurant le mapping des objets gérant la pagination
 */
@Component
public class PageTypeMappeur<R,S> {
	
	/**
	 * @param page la page retournée par un DTO
	 * @param converter la fonction de mapping du contenu de la page
	 * @return la page mappée pour les couches métier et API
	 */
	public PageType<R> toPageType(Page<S> page, Function<? super S, ? extends R> converter) {
		PageType<R> result = new PageType<R>();
		result.setCurrentPage(page.getNumber());
		result.setSize(page.getSize());
		result.setNumberOfElements(page.getTotalElements());
		result.setTotalPages(page.getTotalPages());
		
		List<R> contenu = page.getContent().stream().map(converter::apply).collect(Collectors.toList());
		result.setContenu(contenu);
		return result;
	}

}
