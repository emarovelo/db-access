package fr.acoss.dory.database.access.core.layer.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dory.database.access.core.modele.persistance.Document;


/**
 * Interface DAO de gestion de la table document
 */
public interface DocumentDao extends JpaRepository<Document, Long>, DocumentDaoCustom {

  /**
   * Recherche d'un document par son uuid
   * 
   * @param uuid
   *          String
   * @return Optional<Document>
   */
  Optional<Document> findByUuid(String uuid);

}
