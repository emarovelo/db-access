package fr.acoss.dory.database.access.technique.modele.persistance;

import java.time.OffsetDateTime;

/**
 * Classe mère obligatoire pour toutes les entités du projet
 * _
 * héritage obligatoire, permet de faire la gestion de la concurrence d'accès dans les classe filles.
 * - la propriété dateCreation doit être spécifié avec l'annotation @Column(name = "dt_creation", updatable = false)
 * - la propriété dateMaj doit être spécifié avec @Column(name = "dt_maj") et @Version
 */
public abstract class AbstractPersistanceMere {

  /**
   * constructeur positionnant les dates techniques
   */
  public AbstractPersistanceMere() {
    super();
    final OffsetDateTime dateDuJour = OffsetDateTime.now();
    setDateCreation(dateDuJour);
    setDateMaj(dateDuJour);
  }

  /**
   * @return Le dateCreation.
   */
  public abstract OffsetDateTime getDateCreation();

  /**
   * @param dateCreation
   *          Le dateCreation a affecter.
   */
  public abstract void setDateCreation(final OffsetDateTime dateCreation);

  /**
   * @return Le dateMaj.
   */
  public abstract OffsetDateTime getDateMaj();

  /**
   * @param dateMaj
   *          Le dateMaj a affecter.
   */
  public abstract void setDateMaj(final OffsetDateTime dateMaj);
}
