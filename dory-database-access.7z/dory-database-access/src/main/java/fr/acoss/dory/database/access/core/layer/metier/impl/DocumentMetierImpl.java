package fr.acoss.dory.database.access.core.layer.metier.impl;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.acoss.dory.database.access.core.layer.dao.DocumentDao;
import fr.acoss.dory.database.access.core.layer.dao.StatutDocumentDao;
import fr.acoss.dory.database.access.core.layer.metier.DocumentMetier;
import fr.acoss.dory.database.access.core.layer.metier.composite.CriteresRechercheDocumentType;
import fr.acoss.dory.database.access.core.mappeur.CriteresRechercheDocumentMappeur;
import fr.acoss.dory.database.access.core.mappeur.DocumentMappeur;
import fr.acoss.dory.database.access.core.mappeur.LogDocumentMappeur;
import fr.acoss.dory.database.access.core.modele.persistance.Document;
import fr.acoss.dory.database.access.core.modele.persistance.StatutDocument;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.DocumentType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.LogDocumentType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.StatutDocumentType;

/**
 * Couche métier de gestion des documents
 */
@Service
public class DocumentMetierImpl implements DocumentMetier {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(DocumentMetierImpl.class);

  /**
   * injection du dao Document
   */
  @Resource
  private DocumentDao documentDao;

  /**
   * injection du dao StatutDocumentDao
   */
  @Resource
  private StatutDocumentDao statutDocumentDao;

  /**
   * injection du mappeur DTO / Entity Document
   */
  @Autowired
  private DocumentMappeur documentMappeur;

  /**
   * injection du mappeur DTO / Entity LogDocument
   */
  @Autowired
  private LogDocumentMappeur logDocumentMappeur;

  @Autowired
  private CriteresRechercheDocumentMappeur critereRechercheMappeur;

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional(readOnly = true)
  public List<DocumentType> rechercherDocuments(final CriteresRechercheDocumentType criteres) {

    // Appel DAO de recherche
    final List<Document> documents = documentDao.rechercherDocuments(critereRechercheMappeur.toCriteresRechercheDocument(criteres));

    // Mapping du résultat
    return documentMappeur.toDocumentType(documents);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional
  public void addLogsToDocument(final String idArchivage, final List<LogDocumentType> lstLogDoc) {
    DocumentMetierImpl.LOGGER.info("Tentative d'ajout de log sur le document (id: " + idArchivage);
    documentDao.addLogsToDocument(idArchivage, logDocumentMappeur.toLogDocument(lstLogDoc));

  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional(readOnly = true)
  public long compterDocuments(final CriteresRechercheDocumentType criteres) {
    return documentDao.compterDocuments(critereRechercheMappeur.toCriteresRechercheDocument(criteres));
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional
  public void changerStatutDocsTo(final List<String> lstIdArchivage, final StatutDocumentType newStatutDocs) {
    final Optional<StatutDocument> statutDocument = statutDocumentDao.findByCode(newStatutDocs.getCode());

    if (statutDocument.isPresent()) {
      documentDao.changerStatutDocsTo(lstIdArchivage, statutDocument.get());
    }

  }

}
