package fr.acoss.dory.database.access.technique.configuration;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jndi.JndiObjectFactoryBean;

import fr.acoss.dory.database.access.technique.configuration.datasource.RoutingDataSource;
import fr.acoss.dory.database.access.technique.constante.ConstantesTechniques;
import fr.acoss.dory.database.access.technique.contexte.ContexteUtilisateur;
import fr.acoss.dory.database.access.technique.enumeration.EnumTypeDataSource;

/**
 * Construction des datasources dans un environnement déployé sur Tomcat (ie pas en test junit)
 * Les datasources sont fournis par le serveur Tomcat par l'intermédiaire de JNDI
 * Cette classe permet d'accéder aux deux datasources (la maitre et l'esclave).
 * La datasource mise à disposition de la webapp correspond à la classe RoutingDataSource qui permet de choisir la bonne datasource
 */
@Configuration
@Profile(ConstantesTechniques.SPRING_PROFIL_PRODUCTION) // ce profil permet de faire la distinction avec le profil test
public class DatasourceConfiguration {

  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(DatasourceConfiguration.class);

  /**
   * La datasource maitre
   *
   * @param jndiName
   *          son nom jndi
   * @return JndiObjectFactoryBean
   * @throws NamingException
   */
  @Bean
  public DataSource dataSourceMaster(
                                     @Value("${datasource.master.jndi}") final String jndiName)
                                         throws NamingException {

    return (DataSource) getJndiDatasource(jndiName).getObject();

  }

  /**
   * La datasource slave
   *
   * @param jndiName
   *          son nom jndi
   * @return JndiObjectFactoryBean
   * @throws NamingException
   */
  @Bean
  public DataSource dataSourceSlave(
                                    @Value("${datasource.slave.jndi}") final String jndiName)
                                        throws NamingException {

    return (DataSource) getJndiDatasource(jndiName).getObject();

  }

  /**
   * Permet de récupérer un objet JDNI
   *
   * @param jndiName
   * @return JndiObjectFactoryBean
   * @throws NamingException
   */
  private JndiObjectFactoryBean getJndiDatasource(final String jndiName) throws NamingException {
    LOGGER.info("Récupération de l'objet jndi (jndi={})", jndiName);

    final JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
    jndiObjectFactoryBean.setJndiName(jndiName);
    jndiObjectFactoryBean.setProxyInterface(DataSource.class);
    jndiObjectFactoryBean.setLookupOnStartup(false);
    jndiObjectFactoryBean.afterPropertiesSet();
    return jndiObjectFactoryBean;
  }

  /**
   * Construction de la routing datasource
   *
   * @param contexteUtilisateur
   * @param dataSourceMaster
   * @param dataSourceSlave
   * @return RoutingDataSource
   */
  @Bean
  @Primary
  public DataSource dataSource(final ContexteUtilisateur contexteUtilisateur,
                               @Qualifier("dataSourceMaster") final DataSource dataSourceMaster,
                               @Qualifier("dataSourceSlave") final DataSource dataSourceSlave) {
    LOGGER.info("Construction du bean RoutingDataSource");
    final RoutingDataSource routingDataSource = new RoutingDataSource();
    routingDataSource.setContexteUtilisateur(contexteUtilisateur);
    routingDataSource.setDefaultTargetDataSource(dataSourceMaster);

    // construction de la map des datasources
    final Map<Object, Object> map = new HashMap<>();
    map.put(EnumTypeDataSource.DATASOURCE_ECRITURE, dataSourceMaster);
    map.put(EnumTypeDataSource.DATASOURCE_LECTURE_SEULE, dataSourceSlave);

    routingDataSource.setTargetDataSources(map);

    return routingDataSource;
  }
}
