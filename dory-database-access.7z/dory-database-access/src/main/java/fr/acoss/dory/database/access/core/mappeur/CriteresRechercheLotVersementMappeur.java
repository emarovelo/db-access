package fr.acoss.dory.database.access.core.mappeur;

import fr.acoss.dory.database.access.core.layer.dao.composite.CriteresRechercheLotVersement;
import fr.acoss.dory.database.access.core.layer.metier.composite.CriteresRechercheLotVersementType;
import fr.xebia.extras.selma.CollectionMappingStrategy;
import fr.xebia.extras.selma.IoC;
import fr.xebia.extras.selma.Mapper;

/**
 * Interface de mapping des crières de recherche sur les lots de versement entre entité et DTO.
 */
@Mapper(
        withIoC = IoC.SPRING,
        withCollectionStrategy = CollectionMappingStrategy.ALLOW_GETTER)
public interface CriteresRechercheLotVersementMappeur {

  /**
   * @param criteresRechercheLotVersementType
   *          CriteresRechercheLotVersementType
   * @return CriteresRechercheLotVersement les critères de recherche utilisés par le DAO
   */
  CriteresRechercheLotVersement toCriteresRechercheLotVersement(CriteresRechercheLotVersementType criteresRechercheLotVersementType);
}
