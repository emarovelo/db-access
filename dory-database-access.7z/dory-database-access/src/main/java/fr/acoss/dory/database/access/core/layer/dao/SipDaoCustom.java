package fr.acoss.dory.database.access.core.layer.dao;

import java.util.List;

import fr.acoss.dory.database.access.core.modele.persistance.Document;
import fr.acoss.dory.database.access.core.modele.persistance.Sip;

/**
 * Interface DAO de gestion des document
 */
public interface SipDaoCustom {

  Sip creerSip(String nom, String urlDepot, List<Document> lstDocument);
}
