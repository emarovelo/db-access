package fr.acoss.dory.database.access.technique.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * Classe permettant de gérer la classe SpringContextManager à la fois en tant que bean spring via le @Bean
 * et également en tant qu'objet instanciable hors-spring car on en a besoin comme cela dans les exceptions.
 */
@Component
public class SpringContextFactory {
  
  /** Instance unique du context manager. */
  private static SpringContextManager instance = new SpringContextManager();
  
  /**
   * Méthode de récupération du context manager, également déclaré sous forme de bean.
   * @return SpringContextManager
   */
  @Bean
  public static SpringContextManager springContextManager(){
    return instance;
  }
}
