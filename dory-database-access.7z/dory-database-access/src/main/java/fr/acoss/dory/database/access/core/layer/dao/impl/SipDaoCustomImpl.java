package fr.acoss.dory.database.access.core.layer.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.acoss.dory.database.access.core.layer.dao.SipDaoCustom;
import fr.acoss.dory.database.access.core.modele.persistance.Document;
import fr.acoss.dory.database.access.core.modele.persistance.Sip;

/**
 * Implémentation du DAO représentant l'objet Sip
 */
public class SipDaoCustomImpl implements SipDaoCustom {

  /**
   * Entity Manager
   */
  @PersistenceContext
  protected EntityManager entityManager;

  private static final int BATCH_SIZE = 5;

  /**
   * injection logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(SipDaoCustomImpl.class);

  /**
   * {@inheritDoc}
   */
  @Override
  public Sip creerSip(final String nom, final String urlDepot, final List<Document> lstDocument) {
    SipDaoCustomImpl.LOGGER.info("Création d'un nouveau SIP");
    final Sip sipToSave = new Sip();
    sipToSave.setNom(nom);
    sipToSave.setUrlDepot(urlDepot);

    if (lstDocument != null) {
      Document document;
      for (int i = 0; i < lstDocument.size(); i++) {
        document = lstDocument.get(i);
        sipToSave.addDocument(document);

        entityManager.persist(entityManager.merge(sipToSave));

        // manage update statements in batches
        if (i > 0 && i % BATCH_SIZE == 0) {
          entityManager.flush();
          entityManager.clear();
        }

      }
    }

    return sipToSave;
  }

}
