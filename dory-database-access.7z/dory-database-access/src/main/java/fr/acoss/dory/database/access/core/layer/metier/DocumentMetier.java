package fr.acoss.dory.database.access.core.layer.metier;

import java.util.List;

import fr.acoss.dory.database.access.core.layer.metier.composite.CriteresRechercheDocumentType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.DocumentType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.LogDocumentType;
import fr.acoss.dory.database.access.modele.dto.dorybackendv1.StatutDocumentType;

/**
 * Couche métier de gestion des documents
 */
public interface DocumentMetier {

  /**
   * Rechercher les documents.
   * 
   * @param criteres
   *          CriteresRechercheDocumentType
   * @return List<DocumentType>
   */
  List<DocumentType> rechercherDocuments(CriteresRechercheDocumentType criteres);

  /**
   * Ajout de logs sur le document
   * 
   * @param idArchivage
   *          Long
   * @param lstLogDoc
   *          List<LogDocumenType>
   */
  void addLogsToDocument(String idArchivage, List<LogDocumentType> lstLogDoc);

  /**
   * Permet de compter le nombre de documents selon le critère spécifié.
   * 
   * @param criteres
   * @return
   */
  long compterDocuments(final CriteresRechercheDocumentType criteres);

  /**
   * Permet de mettre à jour le statut des documents
   * 
   * @param lstIdArchivage
   *          : Liste d'id d'archivage
   * @param newStatutDocs:
   *          le nouveau statut
   */
  void changerStatutDocsTo(List<String> lstIdArchivage, StatutDocumentType newStatutDocs);
}
