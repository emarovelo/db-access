package fr.acoss.dorybackend.core.mappeur;

import java.util.List;

import fr.acoss.dorybackend.core.modele.persistance.Sip;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.SipType;
import fr.xebia.extras.selma.CollectionMappingStrategy;
import fr.xebia.extras.selma.IoC;
import fr.xebia.extras.selma.Mapper;

/**
 * Interface de mapping des sips entre entité et DTO.
 */
@Mapper(withIoC = IoC.SPRING,
withCollectionStrategy = CollectionMappingStrategy.ALLOW_GETTER,
withIgnoreFields = {"documents", "datecreation", "datemaj"})
public interface SipMappeur {

  /**
   * Mappe un objet SipType en Sip.
   *
   * @param sipType
   *          SipType
   * @return Sip
   */
  Sip toSip(SipType sipType);

  /**
   * Mappe un objet SipType en Sip.
   *
   * @param sipType
   *          SipType
   * @param sipAMaj
   *          Sip à mettre à jour
   * @return Sip
   */
  Sip toSip(SipType sipType, Sip sipAMaj);

  /**
   * Mappe un objet Sip en SipType.
   *
   * @param sip
   *          Sip
   * @return SipType
   */
  SipType toSipType(Sip sip);

  /**
   * Mappe une liste d'objets Sip en liste SipType.
   *
   * @param sips
   *          List<Sip>
   * @return List<SipType>
   */
  List<SipType> toSipType(List<Sip> sips);
}
