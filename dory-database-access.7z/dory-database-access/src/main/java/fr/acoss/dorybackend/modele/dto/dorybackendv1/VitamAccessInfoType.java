package fr.acoss.dorybackend.modele.dto.dorybackendv1;

import java.time.OffsetDateTime;
import java.util.Objects;

import org.springframework.validation.annotation.Validated;

/**
 * VitamAccessInfoType
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-10-22T14:28:09.484+02:00")

public class VitamAccessInfoType   {
  private Long id = null;

  private String code = null;

  private String sslClientCert = null;

  private String tenantId = null;

  private String applicationId = null;

  private String accessContractId = null;

  private String contextId = null;

  private OffsetDateTime dateCreation = null;

  private OffsetDateTime dateMaj = null;

  public VitamAccessInfoType id(final Long id) {
    this.id = id;
    return this;
  }

  /**
   * Indentifiant du SIP
   * @return id
  **/
  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  public VitamAccessInfoType code(final String code) {
    this.code = code;
    return this;
  }

  /**
   * ACCESS ou INGEST
   * @return code
  **/
  public String getCode() {
    return code;
  }

  public void setCode(final String code) {
    this.code = code;
  }

  public VitamAccessInfoType sslClientCert(final String sslClientCert) {
    this.sslClientCert = sslClientCert;
    return this;
  }

  /**
   * Le certificant en base 64
   * @return sslClientCert
  **/
  public String getSslClientCert() {
    return sslClientCert;
  }

  public void setSslClientCert(final String sslClientCert) {
    this.sslClientCert = sslClientCert;
  }

  public VitamAccessInfoType tenantId(final String tenantId) {
    this.tenantId = tenantId;
    return this;
  }

  /**
   * X-Tenan-Id
   * @return tenantId
  **/
  public String getTenantId() {
    return tenantId;
  }

  public void setTenantId(final String tenantId) {
    this.tenantId = tenantId;
  }

  public VitamAccessInfoType applicationId(final String applicationId) {
    this.applicationId = applicationId;
    return this;
  }

  /**
   * X-Application-Id
   * @return applicationId
  **/
  public String getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(final String applicationId) {
    this.applicationId = applicationId;
  }

  public VitamAccessInfoType accessContractId(final String accessContractId) {
    this.accessContractId = accessContractId;
    return this;
  }

  /**
   * X-Access-Contract-Id
   * @return accessContractId
  **/
  public String getAccessContractId() {
    return accessContractId;
  }

  public void setAccessContractId(final String accessContractId) {
    this.accessContractId = accessContractId;
  }

  public VitamAccessInfoType contextId(final String contextId) {
    this.contextId = contextId;
    return this;
  }

  /**
   * X-Context-Id
   * @return contextId
  **/
  public String getContextId() {
    return contextId;
  }

  public void setContextId(final String contextId) {
    this.contextId = contextId;
  }

  public VitamAccessInfoType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }

  /**
   * Date de creation
   * @return dateCreation
  **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public VitamAccessInfoType dateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
    return this;
  }

  /**
   * Date de derniere mise a jour (obligatoire pour les services de maj)
   * @return dateMaj
  **/
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final VitamAccessInfoType vitamAccessInfoType = (VitamAccessInfoType) o;
    return Objects.equals(id, vitamAccessInfoType.id) &&
        Objects.equals(code, vitamAccessInfoType.code) &&
        Objects.equals(sslClientCert, vitamAccessInfoType.sslClientCert) &&
        Objects.equals(tenantId, vitamAccessInfoType.tenantId) &&
        Objects.equals(applicationId, vitamAccessInfoType.applicationId) &&
        Objects.equals(accessContractId, vitamAccessInfoType.accessContractId) &&
        Objects.equals(contextId, vitamAccessInfoType.contextId) &&
        Objects.equals(dateCreation, vitamAccessInfoType.dateCreation) &&
        Objects.equals(dateMaj, vitamAccessInfoType.dateMaj);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, sslClientCert, tenantId, applicationId, accessContractId, contextId, dateCreation, dateMaj);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class VitamAccessInfoType {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    sslClientCert: ").append(toIndentedString(sslClientCert)).append("\n");
    sb.append("    tenantId: ").append(toIndentedString(tenantId)).append("\n");
    sb.append("    applicationId: ").append(toIndentedString(applicationId)).append("\n");
    sb.append("    accessContractId: ").append(toIndentedString(accessContractId)).append("\n");
    sb.append("    contextId: ").append(toIndentedString(contextId)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    dateMaj: ").append(toIndentedString(dateMaj)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

