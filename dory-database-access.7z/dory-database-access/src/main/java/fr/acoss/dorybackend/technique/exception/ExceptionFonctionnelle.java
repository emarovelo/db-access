package fr.acoss.dorybackend.technique.exception;

import java.util.ArrayList;
import java.util.List;

import fr.acoss.dorybackend.technique.enumeration.EnumCleCodeErreur;

/**
 * Exception fonctionnelle de l'application
 */
public class ExceptionFonctionnelle extends RuntimeException {

  private static final long serialVersionUID = -6411608026975263136L;

  /**
   * Une liste de message d'erreur
   */
  private final List<MessageErreur> listMessages = new ArrayList<>();

  /**
   * Constructeur vide, à ne pas utiliser dans le cas général
   */
  public ExceptionFonctionnelle() {

  }

  /**
   * Constructeur à partir d'une clé de codeErreur
   * Récupère le code, le message et la description du fichier de propriétés
   *
   * @param cleCodeErreur
   */
  public ExceptionFonctionnelle(final EnumCleCodeErreur cleCodeErreur) {
    listMessages.add(new MessageErreur(cleCodeErreur));
  }

  /**
   * Constructeur à partir d'une clé de codeErreur
   * Récupère le code, le message et la description du fichier de propriétés
   *
   * @param cleCodeErreur
   * @param objs
   */
  public ExceptionFonctionnelle(final EnumCleCodeErreur cleCodeErreur, final Object... objs) {
    listMessages.add(new MessageErreur(cleCodeErreur, objs));
  }

  /**
   * Constructeur
   * Récupère le code, le message du fichier de propriétés, la description est passée en paramètre
   *
   * @param cleCodeErreur
   * @param description
   */
  public ExceptionFonctionnelle(final EnumCleCodeErreur cleCodeErreur, final String description) {
    listMessages.add(new MessageErreur(cleCodeErreur, description));
  }

  /**
   * Constructeur à partir d'une clé de codeErreur et d'un Throwable
   * Récupère le code, le message et la description du fichier de propriétés
   *
   * @param cleCodeErreur
   * @param ex
   */
  public ExceptionFonctionnelle(final EnumCleCodeErreur cleCodeErreur, final Throwable ex) {
    super(ex);
    listMessages.add(new MessageErreur(cleCodeErreur));
  }

  /**
   * Ajout d'un message d'erreur (si on souhaite traiter une liste d'erreur dans la même exception fonctionnelle)
   *
   * @param message
   *          déjà construit
   */
  public void addMessageErreur(final MessageErreur message) {
    listMessages.add(message);
  }

  /**
   * Ajout d'un message d'erreur à partir de l'enum (si on souhaite traiter une liste d'erreur dans la même exception fonctionnelle)
   *
   * @param cleCodeErreur
   *          EnumCleCodeErreur
   */
  public void addMessageErreur(final EnumCleCodeErreur cleCodeErreur) {
    listMessages.add(new MessageErreur(cleCodeErreur));
  }

  /**
   * @return Le listMessages.
   */
  public List<MessageErreur> getListMessages() {
    return listMessages;
  }

  @Override
  public String getMessage() {
    return listMessages.toString();
  }
}
