package fr.acoss.dorybackend.core.layer.metier.composite;

import java.util.List;

/**
 * DTO permettant de transmettre les criteres de recherche sur les documents.
 */
public class CriteresRechercheDocumentType extends CriteresRechercheType {

  /**
   * Identifiant d'archivage ou UUID
   */
  private List<String> lstIdArchivage;

  /**
   * Code du statut du document
   */
  private String codeStatutDocument;

  /**
   * Identifiant du SIP
   */
  private Long idSip;

  /**
   * Identifiant du lot de versement
   */
  private Long idLotVersement;

  /**
   * Code RND
   */
  private String codeRND;

  /**
   * True: une recherche sur les documents qui ne sont pas encore dans un SIP
   */
  private boolean searchForIdSipNull;


  /**
   * @return the lstIdArchivage
   */
  public List<String> getLstIdArchivage() {
    return lstIdArchivage;
  }

  /**
   * @param lstIdArchivage
   *          the lstIdArchivage to set
   */
  public void setLstIdArchivage(final List<String> lstIdArchivage) {
    this.lstIdArchivage = lstIdArchivage;
  }

  /**
   * @return the idSip
   */
  public Long getIdSip() {
    return idSip;
  }

  /**
   * @param idSip
   *          the idSip to set
   */
  public void setIdSip(final Long idSip) {
    this.idSip = idSip;
  }

  /**
   * @return the idStatutDocument
   */
  public String getCodeStatutDocument() {
    return codeStatutDocument;
  }

  /**
   * @param codeStatutDocument
   *          the codeStatutDocument to set
   */
  public void setCodeStatutDocument(final String codeStatutDocument) {
    this.codeStatutDocument = codeStatutDocument;
  }

  /**
   * @return the idLotVersement
   */
  public Long getIdLotVersement() {
    return idLotVersement;
  }

  /**
   * @param idLotVersement
   *          the idLotVersement to set
   */
  public void setIdLotVersement(final Long idLotVersement) {
    this.idLotVersement = idLotVersement;
  }

  /**
   * @return the codeRND
   */
  public String getCodeRND() {
    return codeRND;
  }

  /**
   * @param codeRND
   *          the codeRND to set
   */
  public void setCodeRND(final String codeRND) {
    this.codeRND = codeRND;
  }


  /**
   * @return the searchForIdSipNull
   */
  public boolean isSearchForIdSipNull() {
    return searchForIdSipNull;
  }

  /**
   * @param searchForIdSipNull
   *          the searchForIdSipNull to set
   */
  public void setSearchForIdSipNull(final boolean searchForIdSipNull) {
    this.searchForIdSipNull = searchForIdSipNull;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String toString() {
    return "CriteresRechercheDocument [lstIdArchivage=" + lstIdArchivage + ", codeStatutDocument=" + codeStatutDocument + ", idSip=" + idSip
        + ", idLotVersement="
        + idLotVersement + ", codeRND=" + codeRND + ", searchForIdSipNull=" + searchForIdSipNull + "]";
  }


}
