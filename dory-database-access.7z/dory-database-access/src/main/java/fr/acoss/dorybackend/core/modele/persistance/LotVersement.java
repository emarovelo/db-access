package fr.acoss.dorybackend.core.modele.persistance;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Version;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;

import fr.acoss.dorybackend.technique.modele.persistance.AbstractPersistanceMere;

/**
 * Classe de persistance de la table lot_versement
 * .
 * Clef technique
 * id : séquence autoincrementé
 */
@Entity(name = "lot_versement")
public class LotVersement extends AbstractPersistanceMere implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -6349850563455164074L;

  /** Champ id. */
  @Id
  @SequenceGenerator(name = "name_lot_versement_id_seq", sequenceName = "lot_versement_id_seq", initialValue = 1, allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "name_lot_versement_id_seq")
  private Long id;

  /** Champ nom. */
  @NotNull
  @NotBlank
  private String nom;

  /** Champ urldepot. */
  @NotNull
  @NotBlank
  @Column(name = "url_depot")
  private String urlDepot;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "code_statut_lot_versement", nullable = false)
  private StatutLotVersement statutLotVersement;

  /** Champ code statut_lot_versement. */
  @Column(name = "code_statut_lot_versement", insertable = false, updatable = false)
  private String codeStatutLotVersement;


  /** Champ date creation. */
  @Column(name = "dt_creation", updatable = false)
  @CreatedDate
  private OffsetDateTime dateCreation;

  /**
   * Champ date maj.
   * Utilisé pour gérer les accès concurrents.
   * 
   */
  @Column(name = "dt_maj")
  @Version
  private OffsetDateTime dateMaj;

  @OneToMany(
             mappedBy = "lotVersement",
             cascade = CascadeType.ALL,
             orphanRemoval = true)
  private final List<Document> documents = new ArrayList<>();

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the nom
   */
  public String getNom() {
    return nom;
  }

  /**
   * @param nom
   *          the nom to set
   */
  public void setNom(final String nom) {
    this.nom = nom;
  }

  /**
   * @return the urldepot
   */
  public String getUrlDepot() {
    return urlDepot;
  }

  /**
   * @param urldepot
   *          the urldepot to set
   */
  public void setUrlDepot(final String urldepot) {
    urlDepot = urldepot;
  }

  /**
   * @return the statutLotVersement
   */
  public StatutLotVersement getStatutLotVersement() {
    return statutLotVersement;
  }

  /**
   * @param statutLotVersement
   *          the statutLotVersement to set
   */
  public void setStatutLotVersement(final StatutLotVersement statutLotVersement) {
    this.statutLotVersement = statutLotVersement;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  /**
   * @return the documents
   */
  public List<Document> getDocuments() {
    return documents;
  }



  /**
   * Permet d'ajouter un document à ce lot de versement
   * 
   * @param log
   */
  public void addDocument(final Document document) {
    documents.add(document);
    document.setLotVersement(this);
  }

  /**
   * Permet la suppression un document associé a ce lot de versement
   * 
   * @param document
   */
  public void removeDocument(final Document document) {
    documents.remove(document);
    document.setLotVersement(null);
  }
}
