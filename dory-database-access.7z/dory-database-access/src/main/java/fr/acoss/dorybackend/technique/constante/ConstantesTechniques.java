package fr.acoss.dorybackend.technique.constante;

/**
 * Ensemble des constantes techniques
 */
public final class ConstantesTechniques {

  /**
   * Séparateur niv1
   */
  public final static String SEPARATEUR_NIV1 = "-";

  /**
   * Code uuid pour MDC de logback
   */
  public final static String LOGBACK_UUID_CODE = "uuid";

  /**
   * Code user web pour MDC de logback
   */
  public final static String LOGBACK_WEBUSER_CODE = "webuser";

  /**
   * Nom du profil spring pour le déploiement de l'application sur un serveur
   */
  public final static String SPRING_PROFIL_PRODUCTION = "production";

  /**
   * Nom du profil spring pour les tests unitaires
   */
  public final static String SPRING_PROFIL_TU = "test";

}
