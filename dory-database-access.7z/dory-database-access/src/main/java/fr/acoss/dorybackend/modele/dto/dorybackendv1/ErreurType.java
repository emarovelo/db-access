package fr.acoss.dorybackend.modele.dto.dorybackendv1;

import java.util.Objects;


@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2019-10-23T13:59:31.160Z")
public class ErreurType   {

  private String code = null;
  private String message = null;
  private String description = null;

  /**
   * Code de l&#39;erreur
   **/
  public String getCode() {
    return code;
  }
  public void setCode(final String code) {
    this.code = code;
  }

  /**
   * Message de l&#39;erreur
   **/
  public String getMessage() {
    return message;
  }
  public void setMessage(final String message) {
    this.message = message;
  }

  /**
   * Description de l&#39;erreur
   **/
  public String getDescription() {
    return description;
  }
  public void setDescription(final String description) {
    this.description = description;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final ErreurType erreurType = (ErreurType) o;
    return Objects.equals(code, erreurType.code) &&
        Objects.equals(message, erreurType.message) &&
        Objects.equals(description, erreurType.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, message, description);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class ErreurType {\n");

    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

