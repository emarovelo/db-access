package fr.acoss.dorybackend.core.mappeur;

import java.util.List;

import fr.acoss.dorybackend.core.modele.persistance.LogDocument;
import fr.acoss.dorybackend.modele.dto.LogDocumentType;
import fr.xebia.extras.selma.CollectionMappingStrategy;
import fr.xebia.extras.selma.IoC;
import fr.xebia.extras.selma.Mapper;

/**
 * Interface de mapping des logDocument entre entité et DTO.
 */
@Mapper(withIoC = IoC.SPRING,
withCollectionStrategy = CollectionMappingStrategy.ALLOW_GETTER,
withIgnoreFields = {"document", "dateCreation", "dateMaj"})
public interface LogDocumentMappeur {

  /**
   * Mappe un objet LogDocumenType en LogDocument.
   *
   * @param logDocumenType
   *          LogDocumentType
   * @return LogDocument
   */
  LogDocument toLogDocument(LogDocumentType logDocumenType);

  /**
   * Mappe un objet LogDocument en LogDocumentType.
   *
   * @param logDocument
   *          LogDocument
   * @return LogDocumentType
   */
  LogDocumentType toLogDocumentType(LogDocument logDocument);

  /**
   * Mappe une liste d'objets LogDocument en liste LogDocumentType.
   *
   * @param logDocuments
   *          List<LogDocument>
   * @return List<LogDocumentType>
   */
  List<LogDocumentType> toLogDocumentType(List<LogDocument> LogDocument);

  /**
   * Mappe une liste d'objets LogDocumentType en liste LogDocument.
   *
   * @param logDocuments
   *          List<LogDocumentType>
   * @return List<LogDocument>
   */
  List<LogDocument> toLogDocument(List<LogDocumentType> LogDocumentType);
}
