package fr.acoss.dorybackend.core.layer.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dorybackend.core.modele.persistance.VitamAccessInfoConfig;

/**
 * Interface DAO de gestion des VitamAccessInfoConfig (les information permettants appeler les APIs exposées par VITAM)
 */
public interface VitamAccessInfoConfigDao extends JpaRepository<VitamAccessInfoConfig, Long> {

  /**
   * Recherche par code (INGEST/ACCESS)
   * 
   * @param code
   *          String INGEST ou ACCESS
   * @return Optional<VitamAccessInfoConfig>
   */
  Optional<VitamAccessInfoConfig> findByCode(String code);

}
