package fr.acoss.dorybackend.technique.configuration;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import fr.acoss.dorybackend.technique.enumeration.EnumCleCodeErreur;
import fr.acoss.dorybackend.technique.enumeration.EnumCleLibelle;

/**
 * Classe de gestion des libellés et messages
 * <br/>
 * Permet de récupérer les libellés contenus dans les fichiers de propriétés du module dorybackend-configuration
 * Les fichiers sont chargés par la configuration spring via le bean messageSource
 */
@Component
public class Libelles {

  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(Libelles.class);

  /**
   * Constructeur
   */
  public Libelles() {
    LOGGER.info("Construction du Bean Libelles");

  }

  /**
   * Bean injecté par Spring
   */
  @Autowired
  private MessageSource messageSource;

  /**
   * Permet de récupérer un libellé et de le compléter avec le tableau d'objet
   *
   * @param key
   *          EnumLibelle correspondant à la clé
   * @param obj
   *          tableau d'objet pour faire les remplacement
   * @return le libellé ou le code demandé si non trouvé
   */
  public String getMessage(final EnumCleLibelle key, final Object... obj) {

    final String retour = messageSource.getMessage(key.getCode(), obj, Locale.FRANCE);
    if ("".equals(retour) || retour == null || "null".equals(retour)) {
      return key.getCode();
    }
    LOGGER.trace("Récupération du message {}, valeur {}", key.getCode(), retour);
    return retour;
  }

  /**
   * Permet de récupérer un libellé
   *
   * @param key
   *          EnumLibelle correspondant à la clé
   * @return le libellé ou le code demandé si non trouvé
   */
  public String getMessage(final EnumCleLibelle key) {
    return getMessage(key, (Object[]) null);
  }

  /**
   * Permet de récupérer un libellé et de le compléter avec le tableau d'objet
   * Note : la méthode est privée pour usage interne sinon utiliser avec EnumLibelle
   *
   * @param key
   * @param tableau
   *          d'objet pour substitution
   * @return message
   */
  private String getMessage(final String key, final Object... objs) {
    final String retour = messageSource.getMessage(key, objs, Locale.FRANCE);
    if ("".equals(retour) || retour == null || "null".equals(retour)) {
      return key;
    }
    return retour;
  }

  /**
   * Permet de récupérer un libellé
   * Note : la méthode est privée pour usage interne sinon utiliser avec EnumLibelle
   *
   * @param key
   * @return message
   */
  private String getMessage(final String key) {
    return getMessage(key, (Object[]) null);
  }

  /**
   * <b> Spécifique pour la gestion des exceptions </b> <br/>
   * Récupère la description associée à un codeErreur
   *
   * @param cleCodeErreur
   *          EnumCleCodeErreur le code de l'erreur
   * @return le libellé de la description
   */
  public String getDescriptionFromCodeErreur(final EnumCleCodeErreur cleCodeErreur) {
    // la clé est codeerreur.description
    return getMessage(new StringBuffer(cleCodeErreur.getValeur()).append(".").append(getMessage(EnumCleLibelle.DESCRIPTION)).toString());
  }

  /**
   * <b> Spécifique pour la gestion des exceptions </b><br/>
   * Récupère le message formaté associé à un codeErreur
   *
   * @param cleCodeErreur
   *          EnumCleCodeErreur le code de l'erreur
   * @return le libellé de la description
   */
  public String getMessageFromCodeErreur(final EnumCleCodeErreur cleCodeErreur) {
    // la clé est codeerreur.message
    return getMessage(new StringBuffer(cleCodeErreur.getValeur()).append(".").append(getMessage(EnumCleLibelle.MESSAGE)).toString());
  }

  /**
   * <b> Spécifique pour la gestion des exceptions </b><br/>
   * Récupère le message associé à un codeErreur
   *
   * @param cleCodeErreur
   *          EnumCleCodeErreur le code de l'erreur
   * @param objs
   *          d'objet pour substitution
   * @return le libellé de la description
   */
  public String getMessageFromCodeErreur(final EnumCleCodeErreur cleCodeErreur, final Object... objs) {
    // la clé est codeerreur.message
    return getMessage(new StringBuffer(cleCodeErreur.getValeur()).append(".").append(getMessage(EnumCleLibelle.MESSAGE)).toString(), objs);
  }

  /**
   * <b> Spécifique pour la gestion des exceptions </b><br/>
   * Récupère le code associé à un codeErreur
   *
   * @param cleCodeErreur
   *          EnumCleCodeErreur le code de l'erreur
   * @return le libellé de la description
   */
  public String getCodeFromCodeErreur(final EnumCleCodeErreur cleCodeErreur) {
    // la clé est codeerreur.code
    return getMessage(new StringBuffer(cleCodeErreur.getValeur()).append(".").append(getMessage(EnumCleLibelle.ERRORCODE)).toString());
  }

}
