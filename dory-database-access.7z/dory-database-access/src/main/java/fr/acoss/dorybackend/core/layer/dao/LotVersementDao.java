package fr.acoss.dorybackend.core.layer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dorybackend.core.modele.persistance.LotVersement;

/**
 * Interface DAO de gestion des lots de versement
 */
public interface LotVersementDao extends JpaRepository<LotVersement, Long>, LotVersementDaoCustom {

}
