package fr.acoss.dorybackend.technique.contexte;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import fr.acoss.dorybackend.technique.constante.ConstantesTechniques;

/**
 * Cette classe représente le contexte de l'application blanche.
 * Ce contexte est géré dans spring et a une portée request. <br/>
 * <br/>
 * Il est accessible sur l'ensemble des couches et permet de récupérer les informations relatives
 * à la request et notamment des informations portées dans les headers de webservice.<br/>
 * Il contient aussi le type de service lecture / ecriture.
 */
public class ContexteUtilisateur {
  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(ContexteUtilisateur.class);

  /**
   * Indique si le service en cours d'appel est un service de lecture ou de lecture/écriture
   * Cette valeur est positionnée par l'aspect des webservice et est lue par la routingDataSource
   */
  private boolean readOnlyService;

  /**
   * uuid de la request
   */
  private String uuid;
  
  /**
   * Identifiant utilisateur internet.
   */
  private String webUser;

  /**
   * Constructeur.
   */
  public ContexteUtilisateur() {
    LOGGER.trace("Construction du ContexteUtilisateurBack");
  }

  /**
   * Positionne l'uuid dans le contexte MDC
   *
   * @param uuid
   */
  public void setUuid(final String uuid) {
    this.uuid = uuid;
    MDC.put(ConstantesTechniques.LOGBACK_UUID_CODE, uuid);
  }

  /**
   * Nettoie le MDC.
   */
  public void clearLogContext() {
    MDC.clear();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String toString() {
    return String.format(" UUID : %s , Service de lecture seule : %s, UserId : %s ", getUuid(), isReadOnlyService(), getUuid());
  }

  /**
   * récupère l'uuid de request stocké dans le contexte
   *
   * @return
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * @return the readOnlyService
   */
  public boolean isReadOnlyService() {
    return readOnlyService;
  }

  /**
   * @param readOnlyService
   *          the readOnlyService to set
   */
  public void setReadOnlyService(final boolean readOnlyService) {
    this.readOnlyService = readOnlyService;
  }
  
  public String getWebUser() {
	return webUser;
  }

  public void setWebUser(String webUser) {
	this.webUser = webUser;
	MDC.put(ConstantesTechniques.LOGBACK_WEBUSER_CODE, webUser);
  }

}
