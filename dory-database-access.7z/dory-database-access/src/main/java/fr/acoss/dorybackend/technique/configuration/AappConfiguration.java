package fr.acoss.dorybackend.technique.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import fr.acoss.dorybackend.technique.contexte.ContexteUtilisateur;

/**
 * Configuration de la webapp, en complément du fichier xml qui permet de garder la configuration en aop de la gestion des transactions
 */
@Configuration
@EnableAspectJAutoProxy
public class AappConfiguration {

  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(AappConfiguration.class);

  /**
   * Création du bean contexteUtilisateur qui permet de stocker des informations sur chaque request
   *
   * @return ContexteUtilisateur
   */
  @Bean
  public ContexteUtilisateur contexteUtilisateur() {
    LOGGER.trace("Construction du ContexteUtilisateurBack");
    return new ContexteUtilisateur();
  }


}
