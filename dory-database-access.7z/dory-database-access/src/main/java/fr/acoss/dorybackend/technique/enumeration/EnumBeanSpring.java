package fr.acoss.dorybackend.technique.enumeration;

import fr.acoss.dorybackend.technique.configuration.SpringContextManager;

/**
 * Enumération permettant de lister les bean spring utilisables depuis le ContextManager (pour accès en dehors des classes managées)
 *
 * @see SpringContextManager
 */
public enum EnumBeanSpring {
                            SPRING_BEAN_LIBELLES("libelles");
 
  /**
   * Code lié au fichier de propriété
   */
  private String nomBean;

  /**
   * Constructeur
   */
  private EnumBeanSpring(final String nomBean) {
    this.nomBean = nomBean;
  }

  /**
   * Récupère le code ie la clé du fichier de propriété
   *
   * @return cle
   */
  public String getNomBeanSpring() {
    return nomBean;
  };
}
