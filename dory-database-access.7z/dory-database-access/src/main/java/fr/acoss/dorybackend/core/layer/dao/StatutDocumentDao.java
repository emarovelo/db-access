package fr.acoss.dorybackend.core.layer.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dorybackend.core.modele.persistance.StatutDocument;

/**
 * Interface DAO de gestion de la table statut_document
 */
public interface StatutDocumentDao extends JpaRepository<StatutDocument, Long> {

  /**
   * Recherche d'un statut à partir de son code
   * 
   * @param code
   *          String
   * @return Optional<Statut>
   */
  Optional<StatutDocument> findByCode(String code);

}
