package fr.acoss.dorybackend.core.modele.persistance;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import fr.acoss.dorybackend.technique.modele.persistance.AbstractPersistanceMere;

/**
 * Classe de persistance de la table st_statut_sip.
 * Permet de representer les diffrents statuts d'un SIP (voir Entité Sip)
 */
@Entity(name = "st_statut_sip")
public class StatutSip extends AbstractPersistanceMere implements Serializable {

  private static final long serialVersionUID = 7766629440748441767L;

  /** Champ id. */
  @Id
  @SequenceGenerator(name = "name_st_statut_sip_id_seq", sequenceName = "st_statut_sip_id_seq", initialValue = 1, allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "name_st_statut_sip_id_seq")
  private Long id;

  @NotNull
  @Column(unique = true)
  private String code;

  /** Champ date creation. */
  @Column(name = "dt_creation", updatable = false)
  private OffsetDateTime dateCreation;

  /**
   * Champ date maj.
   * Utilisé pour gérer les accès concurrents.
   * 
   */
  @Column(name = "dt_maj")
  @Version
  private OffsetDateTime dateMaj;

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the code
   */
  public String getCode() {
    return code;
  }

  /**
   * @param code
   *          the code to set
   */
  public void setCode(final String code) {
    this.code = code;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;

  }

}
