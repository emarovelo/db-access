package fr.acoss.dorybackend.core.mappeur;

import java.util.List;

import fr.acoss.dorybackend.core.modele.persistance.LotVersement;
import fr.acoss.dorybackend.modele.dto.dorybackendv1.LotVersementType;
import fr.xebia.extras.selma.CollectionMappingStrategy;
import fr.xebia.extras.selma.IoC;
import fr.xebia.extras.selma.Mapper;

/**
 * Interface de mapping des lots de versement entre entité et DTO.
 */
@Mapper(withIoC = IoC.SPRING,
withCollectionStrategy = CollectionMappingStrategy.ALLOW_GETTER,
        withIgnoreFields = {"documents", "datecreation", "datemaj"})
public interface LotVersementMappeur {

  /**
   * Mappe une liste d'objets LotVersement en liste LotVersementType.
   *
   * @param lstLotVersement
   *          List<LotVersement>
   * @return List<LotVersementType>
   */
  List<LotVersementType> toLotVersementType(List<LotVersement> lstLotVersement);

  /**
   * Mappe un objet LotVersement en LotVersementType.
   *
   * @param lotVersement
   *          LotVersement
   * @return LotVersementType
   */
  LotVersementType toLotVersementType(LotVersement lotVersement);

  /**
   * Mappe un objet LotVersementType en LotVersement.
   *
   * @param lotVersement
   *          LotVersementType
   * @return LotVersement
   */
  LotVersement toLotVersement(LotVersementType lotVersement);

  /**
   * Mappe un objet LotVersementType en LotVersement.
   *
   * @param lotVersement
   *          LotVersementType
   * @param lotVersementToMaj
   *          LotVersement
   * @return LotVersement
   */
  LotVersement toLotVersement(LotVersementType lotVersement, LotVersement lotVersementToMaj);

}
