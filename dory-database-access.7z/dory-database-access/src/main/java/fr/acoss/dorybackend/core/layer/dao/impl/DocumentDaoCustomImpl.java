package fr.acoss.dorybackend.core.layer.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.query.QueryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import fr.acoss.dorybackend.core.layer.dao.DocumentDaoCustom;
import fr.acoss.dorybackend.core.layer.dao.composite.CriteresRechercheDocument;
import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.Document_;
import fr.acoss.dorybackend.core.modele.persistance.LogDocument;
import fr.acoss.dorybackend.core.modele.persistance.StatutDocument;
import fr.acoss.dorybackend.core.modele.persistance.TraceStatutDocument;
import fr.acoss.dorybackend.core.utils.PagingHelper;
import fr.acoss.dorybackend.core.utils.SortingHelper;

/**
 * Implémentation du DAO représentant l'objet Document
 */
@Repository
public class DocumentDaoCustomImpl implements DocumentDaoCustom {

  /**
   * Entity Manager
   */
  @PersistenceContext
  protected EntityManager entityManager;

  @Autowired
  private SortingHelper sortingHelper;

  private static final int BATCH_SIZE = 5;

  /**
   * injection logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(DocumentDaoCustomImpl.class);

  /**
   * {@inheritDoc}
   */
  @Override
  public List<Document> rechercherDocuments(final CriteresRechercheDocument criteres) {
    DocumentDaoCustomImpl.LOGGER.debug("Recherche des documents selon les critères : {}", criteres);

    final CriteriaBuilder cb = entityManager.getCriteriaBuilder();

    final CriteriaQuery<Document> query = cb.createQuery(Document.class);
    final Root<Document> root = query.from(Document.class);
    query.distinct(true);

    // Criteres de recherche
    query.where(toQueryPredicate(criteres, cb, root));

    // Fetch logs ?? here

    // Construction criteres de tri
    if (!CollectionUtils.isEmpty(criteres.getTri())) {
      final Sort sort = sortingHelper.toSort(criteres.getTri());
      query.orderBy(QueryUtils.toOrders(sort, root, cb));
    }

    // Pagination
    final TypedQuery<Document> tq = entityManager.createQuery(query);

    final int maxResult = criteres.getSize() == null ? PagingHelper.DEFAULT_PAGE_SIZE : criteres.getSize();
    tq.setMaxResults(maxResult);

    int firstResult = criteres.getCurrentPage() == null ? 0 : criteres.getCurrentPage();
    firstResult = firstResult * maxResult;
    tq.setFirstResult(firstResult);

    return tq.getResultList();

  }

  @Override
  public long compterDocuments(final CriteresRechercheDocument criteres) {
    final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
    final CriteriaQuery<Long> query = builder.createQuery(Long.class);
    final Root<Document> root = query.from(Document.class);
    query.select(builder.countDistinct(root));
    query.where(toQueryPredicate(criteres, builder, root));
    final TypedQuery<Long> tq = entityManager.createQuery(query);
    return tq.getSingleResult();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void changerStatutDocsTo(final List<String> lstIdArchivage, final StatutDocument newStatutDocs) {

    /*
     * Recherche de tous les documents qui correspond à la liste d'id d'archivage passée en paramètre
     */
    final CriteresRechercheDocument criteres = new CriteresRechercheDocument();

    final List<String> critereIdArchivage = new ArrayList<>();
    for (final String idArchivage : lstIdArchivage) {
      if (idArchivage != null) {
        critereIdArchivage.add(idArchivage);
      }
    }

    criteres.setLstIdArchivage(critereIdArchivage);

    final List<Document> lstDocument = rechercherDocuments(criteres);

    /*
     * Mise à jour du statut des documents retrouvés.
     * Pour chaque document mis à jour, ajouter aussi une ligne dans la table historique_statut_document
     */
    TraceStatutDocument tmpTraceStatutDocument;
    Document document;
    for (int i = 0; i < lstDocument.size(); i++) {
      document = lstDocument.get(i);
      document.setStatut(newStatutDocs);

      tmpTraceStatutDocument = new TraceStatutDocument();
      tmpTraceStatutDocument.setStatutCode(newStatutDocs.getCode());
      tmpTraceStatutDocument.setMessage("Nouveau statut: " + newStatutDocs.getCode());

      document.addTraceStatutDocument(tmpTraceStatutDocument);

      entityManager.persist(entityManager.merge(document));

      // manage update statements in batches
      if (i > 0 && i % BATCH_SIZE == 0) {
        entityManager.flush();
        entityManager.clear();
      }

    }

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void addLogsToDocument(final String idArchivage, final List<LogDocument> lstLogDoc) {
    /*
     * Recherche de tous les documents qui correspond à la liste d'id d'archivage passée en paramètre
     */
    final CriteresRechercheDocument criteres = new CriteresRechercheDocument();

    final List<String> critereIdArchivage = new ArrayList<>();

    critereIdArchivage.add(idArchivage);

    criteres.setLstIdArchivage(critereIdArchivage);

    final List<Document> lstDocument = rechercherDocuments(criteres);

    if (lstDocument.size() > 0) {
      final Document document = lstDocument.get(0);
      LogDocument logDocument;
      for (int i = 0; i < lstLogDoc.size(); i++) {
        logDocument = lstLogDoc.get(i);
        document.addLog(logDocument);

        entityManager.persist(entityManager.merge(document));

        // manage update statements in batches
        if (i > 0 && i % BATCH_SIZE == 0) {
          entityManager.flush();
          entityManager.clear();
        }
      }

    }

  }

  private Predicate[] toQueryPredicate(final CriteresRechercheDocument criteres,
                                       final CriteriaBuilder criteriaBuilder, final Root<Document> root) {
    // Criteres de recherche
    final List<Predicate> predicates = new ArrayList<>();

    if (criteres != null) {
      // code du statut du document
      String codeStatutDocument = criteres.getCodeStatutDocument();
      if (codeStatutDocument != null && !codeStatutDocument.trim().isEmpty()) {
        codeStatutDocument = codeStatutDocument.trim();
        predicates.add(criteriaBuilder.equal(root.get(Document_.codeStatutDocument), codeStatutDocument));
      }

      // id du sip
      if (criteres.getIdSip() != null) {
        predicates.add(criteriaBuilder.equal(root.get(Document_.idSip), criteres.getIdSip()));
      } else if (criteres.isSearchForIdSipNull()) {
        predicates.add(criteriaBuilder.isNull(root.get(Document_.idSip)));
      }

      // id du lot de versement
      if (criteres.getIdLotVersement() != null) {
        predicates.add(criteriaBuilder.equal(root.get(Document_.idLot), criteres.getIdLotVersement()));
      }

      // Liste id d'archivage ou uuid
      final List<String> criteresIdArchivage = criteres.getLstIdArchivage();

      if (criteresIdArchivage != null && !criteresIdArchivage.isEmpty()) {
        final List<Predicate> lstIdArchivagePredicates = new ArrayList<>();

        for (String idArchivage : criteresIdArchivage) {

          if (idArchivage != null && !idArchivage.trim().isEmpty()) {
            idArchivage = idArchivage.trim();
            lstIdArchivagePredicates.add(criteriaBuilder.equal(root.get(Document_.uuid), idArchivage));

          }
        }

        if (!lstIdArchivagePredicates.isEmpty()) {
          if (lstIdArchivagePredicates.size() > 1) {
            predicates.add(criteriaBuilder.or(lstIdArchivagePredicates.toArray(new Predicate[] {})));

          } else {
            predicates.add(lstIdArchivagePredicates.get(0));
          }
        }

      }
    }
    // Add some predicates if needed

    return predicates.toArray(new Predicate[] {});
  }

}
