package fr.acoss.dorybackend.core.layer.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import fr.acoss.dorybackend.core.layer.dao.SipDaoCustom;
import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.Sip;
import fr.acoss.dorybackend.core.modele.persistance.StatutDocument;
import fr.acoss.dorybackend.core.modele.persistance.StatutSip;

/**
 * Implémentation du DAO représentant l'objet Sip
 */
@Repository
public class SipDaoCustomImpl implements SipDaoCustom {

  /**
   * Entity Manager
   */
  @PersistenceContext
  protected EntityManager entityManager;

  private static final int BATCH_SIZE = 100;

  /**
   * injection logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(SipDaoCustomImpl.class);

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional
  public Sip creerSip(final String nom, final String urlDepot, final List<Document> lstDocument, final StatutSip initStatutSip,
                      final StatutDocument statutInitDocument) {
    SipDaoCustomImpl.LOGGER.info("Création d'un nouveau SIP dont le nom est: " + nom + ", l'url de dépôt est: " + urlDepot);
    final Sip sipToSave = new Sip();
    sipToSave.setNom(nom);
    sipToSave.setUrlDepot(urlDepot);
    sipToSave.setStatut(initStatutSip);

    if (lstDocument != null) {
      Document document;
      for (int i = 0; i < lstDocument.size(); i++) {
        document = lstDocument.get(i);
        document = entityManager.find(Document.class, document.getId());
        document.setStatut(statutInitDocument);
        sipToSave.addDocument(document);

        entityManager.persist(sipToSave);

        SipDaoCustomImpl.LOGGER.info("Le document dont l'id d'archivage est " + document.getUuid() + " a bien été associé au nouveau SIP dont le nom est: "
            + nom + ", l'url de dépôt est: " + urlDepot);
        // manage update statements in batches
        if (i > 0 && i % BATCH_SIZE == 0) {
          entityManager.flush();
          entityManager.clear();
        }
      }
    }

    return sipToSave;
  }

}
