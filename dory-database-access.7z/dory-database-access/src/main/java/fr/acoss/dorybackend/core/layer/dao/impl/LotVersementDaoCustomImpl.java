package fr.acoss.dorybackend.core.layer.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.query.QueryUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import fr.acoss.dorybackend.core.layer.dao.LotVersementDaoCustom;
import fr.acoss.dorybackend.core.layer.dao.composite.CriteresRechercheLotVersement;
import fr.acoss.dorybackend.core.modele.persistance.LotVersement;
import fr.acoss.dorybackend.core.modele.persistance.LotVersement_;
import fr.acoss.dorybackend.core.utils.PagingHelper;
import fr.acoss.dorybackend.core.utils.SortingHelper;

/**
 * Implémentation du DAO représentant l'objet LotVersement
 */
@Repository
public class LotVersementDaoCustomImpl implements LotVersementDaoCustom {

  /**
   * Entity Manager
   */
  @PersistenceContext
  protected EntityManager entityManager;

  @Autowired
  private SortingHelper sortingHelper;

  /**
   * injection logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(LotVersementDaoCustomImpl.class);

  /**
   * {@inheritDoc}
   */
  @Override
  public List<LotVersement> rechercherLotVersement(final CriteresRechercheLotVersement criteres) {
    LotVersementDaoCustomImpl.LOGGER.debug("Recherche des lots de versement selon les critères : {}", criteres);

    final CriteriaBuilder cb = entityManager.getCriteriaBuilder();

    final CriteriaQuery<LotVersement> query = cb.createQuery(LotVersement.class);
    final Root<LotVersement> root = query.from(LotVersement.class);
    query.distinct(true);

    // Criteres de recherche
    query.where(toQueryPredicate(criteres, cb, root));

    // Construction criteres de tri
    if (!CollectionUtils.isEmpty(criteres.getTri())) {
      final Sort sort = sortingHelper.toSort(criteres.getTri());
      query.orderBy(QueryUtils.toOrders(sort, root, cb));
    }

    // Pagination
    final TypedQuery<LotVersement> tq = entityManager.createQuery(query);

    final int maxResult = criteres.getSize() == null ? PagingHelper.DEFAULT_PAGE_SIZE : criteres.getSize();
    tq.setMaxResults(maxResult);

    int firstResult = criteres.getCurrentPage() == null ? 0 : criteres.getCurrentPage();
    firstResult = firstResult * maxResult;
    tq.setFirstResult(firstResult);

    return tq.getResultList();

  }

  @Override
  public long compterLotVersement(final CriteresRechercheLotVersement criteres) {
    final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
    final CriteriaQuery<Long> query = builder.createQuery(Long.class);
    final Root<LotVersement> root = query.from(LotVersement.class);
    query.select(builder.countDistinct(root));
    query.where(toQueryPredicate(criteres, builder, root));
    final TypedQuery<Long> tq = entityManager.createQuery(query);
    return tq.getSingleResult();
  }

  private Predicate[] toQueryPredicate(final CriteresRechercheLotVersement criteres,
                                       final CriteriaBuilder cb, final Root<LotVersement> root) {
    // Criteres de recherche
    final List<Predicate> predicates = new ArrayList<>();

    // id
    if (criteres.getId() != null) {
      predicates.add(cb.equal(root.get(LotVersement_.id), criteres.getId()));
    }

    // nom
    String nom = criteres.getNom();
    if (nom != null && !nom.trim().isEmpty()) {
      nom = nom.trim();
      predicates.add(cb.equal(root.get(LotVersement_.nom), nom));
    }

    // statut
    String statut = criteres.getCodeStatutLotVersement();
    if (statut != null && !statut.trim().isEmpty()) {
      statut = statut.trim();
      predicates.add(cb.equal(root.get(LotVersement_.codeStatutLotVersement), statut));
    }

    // Add some predicates if needed
    return predicates.toArray(new Predicate[] {});
  }
}
