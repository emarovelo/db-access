package fr.acoss.dorybackend.modele.dto.dorybackendv1;

import java.time.OffsetDateTime;
import java.util.Objects;

public class StatutLotVersementType {

  private Long id = null;

  private String code = null;

  private OffsetDateTime dateCreation = null;

  private OffsetDateTime dateMaj = null;

  public StatutLotVersementType id(final Long id) {
    this.id = id;
    return this;
  }

  /**
   * Indentifiant du statut
   * 
   * @return id
   **/
  public Long getId() {
    return id;
  }

  public void setId(final Long id) {
    this.id = id;
  }

  public StatutLotVersementType code(final String code) {
    this.code = code;
    return this;
  }

  /**
   * code unique du statut
   * 
   * @return code
   **/
  public String getCode() {
    return code;
  }

  public void setCode(final String code) {
    this.code = code;
  }

  public StatutLotVersementType dateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
    return this;
  }

  /**
   * Date de creation
   * 
   * @return dateCreation
   **/
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;
  }

  public StatutLotVersementType dateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
    return this;
  }

  /**
   * Date de derniere mise a jour (obligatoire pour les services de maj)
   * 
   * @return dateMaj
   **/
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }

  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final StatutLotVersementType statutLotVersementType = (StatutLotVersementType) o;
    return Objects.equals(id, statutLotVersementType.id) &&
        Objects.equals(code, statutLotVersementType.code) &&
        Objects.equals(dateCreation, statutLotVersementType.dateCreation) &&
        Objects.equals(dateMaj, statutLotVersementType.dateMaj);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, dateCreation, dateMaj);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class StatutLotVersementType {\n");

    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    dateCreation: ").append(toIndentedString(dateCreation)).append("\n");
    sb.append("    dateMaj: ").append(toIndentedString(dateMaj)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
