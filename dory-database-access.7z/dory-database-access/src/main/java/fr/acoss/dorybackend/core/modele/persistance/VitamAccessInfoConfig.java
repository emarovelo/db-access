package fr.acoss.dorybackend.core.modele.persistance;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Version;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;

import fr.acoss.dorybackend.technique.modele.persistance.AbstractPersistanceMere;

/**
 * Classe de persistance de la table vitamaccess
 * .
 * Clef technique
 * id : séquence autoincrementé
 */
@Entity(name = "vitam_access_info_config")
public class VitamAccessInfoConfig extends AbstractPersistanceMere implements Serializable {

  private static final long serialVersionUID = -416762025543221388L;

  /** Champ id. */
  @Id
  @SequenceGenerator(name = "name_vitam_access_info_config_id_seq", sequenceName = "vitam_access_info_config_id_seq", initialValue = 1, allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "name_vitam_access_info_config_id_seq")
  private Long id;

  /** Champ code. */
  @NotNull
  @NotBlank
  @Column(unique = true)
  private String code;

  /** Champ certificat */
  @Column(name = "ssl_client_cert")
  private String sslClientCert;

  /** Champ tenant_id */
  @Column(name = "tenant_id")
  private String tenantId;

  /** Champ application_id */
  @Column(name = "application_id")
  private String applicationId;

  /** Champ context_id */
  @Column(name = "context_id")
  private String contextId;

  /** Champ access_contract_id */
  @Column(name = "access_contract_id")
  private String accessContractId;

  /** Champ date creation. */
  @Column(name = "dt_creation", updatable = false)
  @CreatedDate
  private OffsetDateTime dateCreation;

  /**
   * Champ date maj.
   * Utilisé pour gérer les accès concurrents.
   * 
   * @See fr.recouv.appliblanche.technique.layer.dao.AbstractGenericDaoImpl.java#findByChampForUpdate()
   */
  @Column(name = "dt_maj")
  @Version
  private OffsetDateTime dateMaj;

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the code
   */
  public String getCode() {
    return code;
  }

  /**
   * @param code
   *          the code to set
   */
  public void setCode(final String code) {
    this.code = code;
  }

  /**
   * @return the sslClientCert
   */
  public String getSslClientCert() {
    return sslClientCert;
  }

  /**
   * @param sslClientCert
   *          the sslClientCert to set
   */
  public void setSslClientCert(final String sslClientCert) {
    this.sslClientCert = sslClientCert;
  }

  /**
   * @return the tenantId
   */
  public String getTenantId() {
    return tenantId;
  }

  /**
   * @param tenantId
   *          the tenantId to set
   */
  public void setTenantId(final String tenantId) {
    this.tenantId = tenantId;
  }

  /**
   * @return the applicationId
   */
  public String getApplicationId() {
    return applicationId;
  }

  /**
   * @param applicationId
   *          the applicationId to set
   */
  public void setApplicationId(final String applicationId) {
    this.applicationId = applicationId;
  }

  /**
   * @return the contextId
   */
  public String getContextId() {
    return contextId;
  }

  /**
   * @param contextId
   *          the contextId to set
   */
  public void setContextId(final String contextId) {
    this.contextId = contextId;
  }

  /**
   * @return the accessContractId
   */
  public String getAccessContractId() {
    return accessContractId;
  }

  /**
   * @param accessContractId
   *          the accessContractId to set
   */
  public void setAccessContractId(final String accessContractId) {
    this.accessContractId = accessContractId;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateCreation() {
    return dateCreation;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateCreation(final OffsetDateTime dateCreation) {
    this.dateCreation = dateCreation;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public OffsetDateTime getDateMaj() {
    return dateMaj;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateMaj(final OffsetDateTime dateMaj) {
    this.dateMaj = dateMaj;
  }
}
