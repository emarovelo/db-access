package fr.acoss.dorybackend.core.utils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * Classe gérant le tri 
 */
@Component
public class SortingHelper {

	/**
	 * Transforme uns liste de criteres de tri en objet Sort utilisé par les DAO  
	 * @param criteresTri
	 * @return Sort
	 */
	public Sort toSort(List<String> criteresTri) {
		if (!CollectionUtils.isEmpty(criteresTri)) {
			List<Order> orders = criteresTri.stream().map(critere -> {
				return toOrder(critere);
			}).filter(Objects::nonNull).collect(Collectors.toList());
			return Sort.by(orders);
		}
		return Sort.unsorted();
	}
	
	/**
	 * @param critere
	 * @return un objet Order permettant de définir l'ordre d'un tri
	 */
	public Order toOrder(String critere) {
		if (critere.contains(":")) {
			String[] split = critere.split(":");
			if (split != null && split.length == 2) {
				String property = split[0];
				String direction = split[1];
				return new Order(Direction.fromString(direction), property);
			}
		}
		return null;
	}

}
