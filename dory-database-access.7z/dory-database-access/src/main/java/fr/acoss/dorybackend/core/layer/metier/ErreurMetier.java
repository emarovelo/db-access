package fr.acoss.dorybackend.core.layer.metier;

/**
 * Couche métier de gestion des erreurs
 */
public interface ErreurMetier {

  /**
   * Provoque une erreur de création en base de données pour un champ trop long
   */
  void creerErreurValidationEnBase();

}