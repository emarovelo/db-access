package fr.acoss.dorybackend.technique.configuration;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

/**
 * Configuration Spring pour les accès JPA
 */
@Configuration
public class JpaTransactionConfiguration {
  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(CoreConfiguration.class);

  /**
   * Package contenant les entités JPA
   */
  public static final String PACKAGE_JPA_SCAN = "fr.acoss.dorybackend.core.modele.persistance";

  /**
   * Timeout JPA
   */
  public static final int JPA_TIMEOUT = 299;


  /**
   * Construction du jpaVendorAdapter
   *
   * @param dialect
   * @return HibernateJpaVendorAdapter
   */
  @Bean
  public HibernateJpaVendorAdapter jpaVendorAdapter(@Value("${hibernate.dialect}") final String dialect) {
    LOGGER.info("Construction du bean jpaVendorAdapter (dialect={})", dialect);
    final HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
    hibernateJpaVendorAdapter.setDatabase(Database.POSTGRESQL);
    hibernateJpaVendorAdapter.setDatabasePlatform(dialect);
    hibernateJpaVendorAdapter.setGenerateDdl(false);

    return hibernateJpaVendorAdapter;
  }

  /**
   * Construction de l'entityManagerFactory en positionnant la datasource et les propriétés supplémentaires
   *
   * @param datasource
   *          la datasource créé par Spring
   * @param jpaVendorAdapter
   *          JpaVendorAdapter
   * @return LocalContainerEntityManagerFactoryBean
   */
  @Bean
  public LocalContainerEntityManagerFactoryBean entityManagerFactory(@Qualifier("dataSource") final DataSource datasource,
                                                                     final JpaVendorAdapter jpaVendorAdapter) {
    LOGGER.info("Construction du bean entityManagerFactory (package to scan : {})", PACKAGE_JPA_SCAN);

    final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
    em.setDataSource(datasource);

    em.setPackagesToScan(new String[] {PACKAGE_JPA_SCAN});

    final JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
    em.setJpaVendorAdapter(vendorAdapter);

    em.setJpaVendorAdapter(jpaVendorAdapter);

    final Properties properties = new Properties();

    // propriété gérée dans le fichiers logback
    // properties.setProperty("hibernate.show_sql", "false"); @see logback.xml
    properties.setProperty("hibernate.format_sql", "true");

    // TODO PROJET : positionner les propriétés hibernate supplémentaires (activation cache)
    // properties.setProperty("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory");
    // properties.setProperty("hibernate.cache.use_query_cache", "true");
    // properties.setProperty("hibernate.cache.use_second_level_cache", "true");
    // properties.setProperty("hibernate.generate_statistics", "true");

    // enanble batching in creation
    properties.put("hibernate.jdbc.batch_size", "5");

    // To batch all insert statements of the same entity type
    properties.put("hibernate.order_inserts", "true");

    // enable batching in update
    properties.put("hibernate.order_updates", "true");
    properties.put("hibernate.batch_versioned_data", "true");

    em.setJpaProperties(properties);

    return em;
  }

  /**
   * Construction du transactionManager
   *
   * @param entityManagerFactory
   *          EntityManagerFactory
   * @return JpaTransactionManager
   */
  @Bean
  public JpaTransactionManager transactionManager(final EntityManagerFactory entityManagerFactory) {
    LOGGER.info("Construction du bean JpaTransactionManager. Timeout : {} ", JPA_TIMEOUT);
    final JpaTransactionManager jpaTransactionManager = new JpaTransactionManager(entityManagerFactory);
    jpaTransactionManager.setDefaultTimeout(JPA_TIMEOUT);

    return jpaTransactionManager;
  }
}
