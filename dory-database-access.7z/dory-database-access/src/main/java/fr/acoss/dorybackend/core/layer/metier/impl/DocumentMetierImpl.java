package fr.acoss.dorybackend.core.layer.metier.impl;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.acoss.dorybackend.core.layer.dao.DocumentDao;
import fr.acoss.dorybackend.core.layer.dao.StatutDocumentDao;
import fr.acoss.dorybackend.core.layer.metier.DocumentMetier;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheDocumentType;
import fr.acoss.dorybackend.core.mappeur.CriteresRechercheDocumentMappeur;
import fr.acoss.dorybackend.core.mappeur.DocumentMappeur;
import fr.acoss.dorybackend.core.mappeur.LogDocumentMappeur;
import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.StatutDocument;
import fr.acoss.dorybackend.modele.dto.DocumentType;
import fr.acoss.dorybackend.modele.dto.LogDocumentType;
import fr.acoss.dorybackend.modele.dto.StatutDocumentType;


/**
 * Couche métier de gestion des documents
 */
@Service
public class DocumentMetierImpl implements DocumentMetier {

  /**
   * injection du dao Document
   */
  @Resource
  private DocumentDao documentDao;

  /**
   * injection du dao StatutDocumentDao
   */
  @Resource
  private StatutDocumentDao statutDocumentDao;

  /**
   * injection du mappeur DTO / Entity Document
   */
  @Autowired
  private DocumentMappeur documentMappeur;

  /**
   * injection du mappeur DTO / Entity LogDocument
   */
  @Autowired
  private LogDocumentMappeur logDocumentMappeur;

  @Autowired
  private CriteresRechercheDocumentMappeur critereRechercheMappeur;

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional(readOnly = true)
  public List<DocumentType> rechercherDocuments(final CriteresRechercheDocumentType criteres) {

    // Appel DAO de recherche
    final List<Document> documents = documentDao.rechercherDocuments(critereRechercheMappeur.toCriteresRechercheDocument(criteres));

    // Mapping du résultat
    return documentMappeur.toDocumentType(documents);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional
  public void addLogsToDocument(final String idArchivage, final List<LogDocumentType> lstLogDoc) {
    documentDao.addLogsToDocument(idArchivage, logDocumentMappeur.toLogDocument(lstLogDoc));

  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional(readOnly = true)
  public long compterDocuments(final CriteresRechercheDocumentType criteres) {
    return documentDao.compterDocuments(critereRechercheMappeur.toCriteresRechercheDocument(criteres));
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional
  public void changerStatutDocsTo(final List<String> lstIdArchivage, final StatutDocumentType newStatutDocs) {
    final Optional<StatutDocument> statutDocument = statutDocumentDao.findByCode(newStatutDocs.getCode());

    if (statutDocument.isPresent()) {
      documentDao.changerStatutDocsTo(lstIdArchivage, statutDocument.get());
    }

  }

}
