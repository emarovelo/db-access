package fr.acoss.dorybackend.technique.configuration.aspect;

import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fr.acoss.dorybackend.technique.contexte.ContexteUtilisateur;


/**
 * Aspect positionné autour de l'appel de chaque méthode de service<br/>
 * Il permet de gérer les points suivants :
 * <ul>
 * <li>Log des appels</li>
 * <li>Positionnement du nom de la datasource dans le contexte utilisateur</li>
 * </ul>
 */
@Component
@Aspect
public class WebServiceAspect implements Ordered {

  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(WebServiceAspect.class);

  /**
   * injection du contexte utilisateur
   */
  @Autowired
  private ContexteUtilisateur contexteUtilisateur;

  /**
   * Pointcut pour l'execution de l'apsect @see {@link WebServiceAspect#around(ProceedingJoinPoint)}
   */
  @Pointcut("execution(* fr.acoss.dorybackend.core.layer.*.impl.*Impl.*(..))")
  public void apiPoincut() {
  }

  /**
   * Wrappeur des méthodes de webservices gérant l'AOP
   *
   * @param pointcut
   *          pointcut
   * @return valeur retournée par le webservice
   * @throws Throwable
   */
  @Around("apiPoincut()")
  public Object around(final ProceedingJoinPoint pointcut) throws Throwable {
    LOGGER.info("Appel du service - [{}], contexte : {}", pointcut.getSignature(), contexteUtilisateur.toString());

    Object retVal = null;

    // permet de positionner le type de service dans le contexteUtilisateur (ie en lecture ou en écriture)
    gestionServiceAnnotation(pointcut);

    // appel de la méthode du webservice
    retVal = pointcut.proceed();

    LOGGER.debug("Fin de l'appel du service - [{}]", pointcut.getSignature());
    // si pas d'erreur, l'aop renvoie le retour de la couche service pour passage dans SpringBoot
    return retVal;

  }

  /**
   * Gestion de l'annotation Transactionnal pour positionnement dans le contexte utilisateur de l'information readonly
   * Cette information permet le choix de la bonne datasource.
   *
   * @param pjp
   *          pointcut
   * @throws NoSuchMethodException
   */
  private void gestionServiceAnnotation(final ProceedingJoinPoint pjp) throws NoSuchMethodException {
    LOGGER.trace("Début de l'appel de serviceAnnotation");

    // Récupération de l'annotation Transactional sur la méthode de service qui est wrappée par l'AOP
    Transactional serviceAnnotation = null;
    final MethodSignature methodSignature = (MethodSignature) pjp.getSignature();
    Method targetMethod = methodSignature.getMethod();
    if (targetMethod.getDeclaringClass().isInterface()) {
      targetMethod = pjp.getTarget().getClass().getDeclaredMethod(pjp.getSignature().getName(),
                                                                  targetMethod.getParameterTypes());
    }
    serviceAnnotation = targetMethod.getAnnotation(Transactional.class);

    // si l'annotation est positionnée sur la méthode, il faut récupérer la valeur de la propriété readOnly et la positionner dans le contexteutilisateur
    // la datasource sera récupérée ensuite par la classe RoutingDataSource
    if (serviceAnnotation != null) {
      LOGGER.debug("Type de service lecture seule : {} ", serviceAnnotation.readOnly());
      contexteUtilisateur.setReadOnlyService(serviceAnnotation.readOnly());
    } else {
      // on loggue en warn pour indiquer qu'il manque l'annotation sur la méthode de service (mais il ne s'agit pas forcément d'une erreur)
      LOGGER.warn("L'annotation @Transactional n'est pas positionnée sur la méthode du service, le routage de datasource s'appuie sur la méthode. Par défault, la datasource en lecture/écriture sera utilisée");
    }

    LOGGER.trace("Fin de l'appel de serviceAnnotation");
  }

  /**
   * {@inheritDoc}
   * Pour ordonner l'aspect par rapport à la gestion de la transaction (ordre 2) (pour accéder à la bonne datasource)
   */
  @Override
  public int getOrder() {
    return 1;
  }
}
