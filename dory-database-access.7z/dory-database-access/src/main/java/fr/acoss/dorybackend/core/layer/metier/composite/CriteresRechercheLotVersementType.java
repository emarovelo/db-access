package fr.acoss.dorybackend.core.layer.metier.composite;

/**
 * DTO permettant de transmettre les criteres de recherche sur les lots de versement.
 */
public class CriteresRechercheLotVersementType extends CriteresRechercheType {

  /**
   * Champ id
   */
  private Long id;

  /**
   * Champ nom
   */
  private String nom;

  /**
   * Champ uldDepot
   */
  private String urldDepot;

  /**
   * Champ codeStatutLotVersement
   */
  private String codeStatutLotVersement;

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  /**
   * @param id
   *          the id to set
   */
  public void setId(final Long id) {
    this.id = id;
  }

  /**
   * @return the nom
   */
  public String getNom() {
    return nom;
  }

  /**
   * @param nom
   *          the nom to set
   */
  public void setNom(final String nom) {
    this.nom = nom;
  }

  /**
   * @return the urldDepot
   */
  public String getUrldDepot() {
    return urldDepot;
  }

  /**
   * @param urldDepot
   *          the urldDepot to set
   */
  public void setUrldDepot(final String urldDepot) {
    this.urldDepot = urldDepot;
  }

  /**
   * @return the codeStatutLotVersement
   */
  public String getCodeStatutLotVersement() {
    return codeStatutLotVersement;
  }

  /**
   * @param codeStatutLotVersement
   *          the codeStatutLotVersement to set
   */
  public void setCodeStatutLotVersement(final String codeStatutLotVersement) {
    this.codeStatutLotVersement = codeStatutLotVersement;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String toString() {
    return "CriteresRechercheLotVersementType [id=" + id + ", nom=" + nom + ", uldDepot=" + urldDepot + "]";
  }

}
