package fr.acoss.dorybackend.core.layer.metier.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.acoss.dorybackend.core.layer.dao.LotVersementDao;
import fr.acoss.dorybackend.core.layer.metier.LotVersementMetier;
import fr.acoss.dorybackend.core.layer.metier.composite.CriteresRechercheLotVersementType;
import fr.acoss.dorybackend.core.mappeur.CriteresRechercheLotVersementMappeur;
import fr.acoss.dorybackend.core.mappeur.DocumentMappeur;
import fr.acoss.dorybackend.core.mappeur.LotVersementMappeur;
import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.LotVersement;
import fr.acoss.dorybackend.modele.dto.DocumentType;
import fr.acoss.dorybackend.modele.dto.LotVersementType;


/**
 * Couche métier de gestion des lots de versement
 */
@Service
public class LotVersementMetierImpl implements LotVersementMetier {


  /**
   * injection du dao LotVersement
   */
  @Resource
  private LotVersementDao lotVersementDao;

  /**
   * injection du mappeur DTO / Entity LotVersement
   */
  @Autowired
  private LotVersementMappeur lotVersementMappeur;

  /**
   * injection du mappeur DTO / Entity Document
   */
  @Autowired
  private DocumentMappeur documentMappeur;

  @Autowired
  private CriteresRechercheLotVersementMappeur criteresRechercheLotVersementMappeur;


  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional(readOnly = true)
  public List<LotVersementType> rechercherLots(final CriteresRechercheLotVersementType criteres) {
    // Appel DAO de recherche
    final List<LotVersement> lstLotVersement = lotVersementDao.rechercherLotVersement(criteresRechercheLotVersementMappeur.toCriteresRechercheLotVersement(criteres));

    // Mapping du résultat
    return lotVersementMappeur.toLotVersementType(lstLotVersement);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional(readOnly = true)
  public LotVersementType recupererLot(final Long idLot) {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional
  public Long creerLot(final LotVersementType lotVersementType, final List<DocumentType> documents) {

    LotVersement lotVersement = lotVersementMappeur.toLotVersement(lotVersementType);

    if (lotVersement != null && documents != null) {
      Document tmpDocument;

      for (final DocumentType documentType : documents) {
        tmpDocument = documentMappeur.toDocument(documentType);
        lotVersement.addDocument(tmpDocument);
      }

      lotVersement = lotVersementDao.save(lotVersement);
    }

    return lotVersement == null ? null : lotVersement.getId();
  }

}
