package fr.acoss.dorybackend.technique.enumeration;

import fr.acoss.dorybackend.technique.configuration.Libelles;

/**
 * Enumération contenant les clés liées aux fichiers de propriétés
 *
 * @see Libelles
 *      Tout libellé ajouté dans les fichiers erreurs et labels doivent être mappés dans cet enum
 */
public enum EnumCleLibelle {

                            // Socle technique
                            ERRORCODE("exception.construction.code"),
                            MESSAGE("exception.construction.message"),
                            DESCRIPTION("exception.construction.description"),
                            ERREUR_VALIDATION("erreur.validation"),

  // Libelles metier

  ;

  /**
   * Code lié au fichier de propriété
   */
  private String code;

  /**
   * Constructeur
   */
  private EnumCleLibelle(final String code) {
    this.code = code;
  }

  /**
   * Récupère le code ie la clé du fichier de propriété
   *
   * @return code
   */
  public String getCode() {
    return code;
  }
}
