package fr.acoss.dorybackend.core.layer.dao.composite;

import java.util.List;

/**
 * Objet pêre des critères de recherche, contenant les paramètres de tri et de pagination.
 */
public class CriteresRecherche {
  
  /** Criteres de tri. */
  private List<String> tri;
  
  /** Page courante */
  private Integer currentPage;
  
  /** Nombre d'éléments demandés */
  private Integer size;

  /**
   * @return the tri
   */
  public List<String> getTri() {
    return tri;
  }

  /**
   * @param tri the tri to set
   */
  public void setTri(List<String> tri) {
    this.tri = tri;
  }

  /**
   * @return the currentPage
   */
  public Integer getCurrentPage() {
    return this.currentPage;
  }

  /**
   * @param currentPage the currentPage to set
   */
  public void setCurrentPage(Integer currentPage) {
    this.currentPage = currentPage;
  }

  /**
   * @return the size
   */
  public Integer getSize() {
    return size;
  }

  /**
   * @param size the size to set
   */
  public void setSize(Integer size) {
    this.size = size;
  }
}
