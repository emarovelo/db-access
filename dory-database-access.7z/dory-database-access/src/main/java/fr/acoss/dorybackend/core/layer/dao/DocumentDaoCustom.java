package fr.acoss.dorybackend.core.layer.dao;

import java.util.List;

import fr.acoss.dorybackend.core.layer.dao.composite.CriteresRechercheDocument;
import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.LogDocument;
import fr.acoss.dorybackend.core.modele.persistance.StatutDocument;

/**
 * Interface DAO de gestion des document
 */
public interface DocumentDaoCustom {

  /**
   * Recherche de la liste des documents en filtrant selon des criteres.
   *
   * @param criteres
   *          CriteresRechercheDocument
   * @return List<Document>
   */
  List<Document> rechercherDocuments(CriteresRechercheDocument criteres);

  /**
   * Permet de compter le nombre de documents selon le critère spécifié.
   * 
   * @param criteres
   *          CriteresRechercheDocument
   * @return le nombre documents correspondant aux criteres
   */
  long compterDocuments(final CriteresRechercheDocument criteres);

  /**
   * Permet de mettre à jour le statut des documents
   * 
   * @param lstIdArchivage:
   *          la liste d'id d'archivage
   * @param newStatutDocs:
   *          le nouveau statut
   */
  void changerStatutDocsTo(final List<String> lstIdArchivage, final StatutDocument newStatutDocs);

  /**
   * Permet de mettre à jour le statut des documents
   * 
   * @param idDocs
   *          : Liste d'edentifiant de document
   * @param newStatutDocs:
   *          le nouveau statut
   */

  /**
   * Ajout de logs sur le document
   * 
   * @param idDocument:
   *          id d'archivage du document
   * @param lstLogDoc:
   *          la liste de log à ajouter au document
   */
  void addLogsToDocument(String idArchivage, List<LogDocument> lstLogDoc);

}
