package fr.acoss.dorybackend.core.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import fr.acoss.dorybackend.core.layer.dao.composite.CriteresRecherche;

/**
 * Classe permettant de gérer les critères de pagination
 */
@Component
public class PagingHelper {

  @Autowired
  private SortingHelper sortingHelper;

  public static final int DEFAULT_PAGE_SIZE = 100;

  /**
   * Permet de convertir les CriteresRecherche en PageRequest utilisée par les DAO
   * @param criteresRecherche
   * @return PageRequest
   */
  public PageRequest convertCriteresToPageRequest(final CriteresRecherche criteresRecherche) {
    final int currentPage = criteresRecherche.getCurrentPage() == null ?  0 : criteresRecherche.getCurrentPage();
    final int size = criteresRecherche.getSize() == null ? DEFAULT_PAGE_SIZE : criteresRecherche.getSize();
    final Sort sort = sortingHelper.toSort(criteresRecherche.getTri());

    return PageRequest.of(currentPage, size, sort);
  }

}
