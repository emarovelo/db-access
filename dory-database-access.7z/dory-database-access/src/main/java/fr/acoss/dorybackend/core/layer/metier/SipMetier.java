package fr.acoss.dorybackend.core.layer.metier;

import java.util.List;
import java.util.Optional;

import fr.acoss.dorybackend.modele.dto.DocumentType;
import fr.acoss.dorybackend.modele.dto.SipType;


/**
 * Couche métier de gestion des sip
 */
public interface SipMetier {

  /**
   * Permet de créer un SIP
   * 
   * @param nom
   *          String
   * @param urlDepot
   *          String
   * @param lstDocumentType
   *          List<DocumentType>
   * @return SipType
   */
  Optional<SipType> creerSip(String nom, String urlDepot, List<DocumentType> lstDocumentType);

}
