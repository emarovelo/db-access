package fr.acoss.dorybackend.technique.exception;

import fr.acoss.dorybackend.technique.configuration.SpringContextFactory;
import fr.acoss.dorybackend.technique.enumeration.EnumCleCodeErreur;

/**
 * Exception technique de l'application
 */
public class ExceptionTechnique extends RuntimeException {

  private static final long serialVersionUID = -200347784761312022L;

  /**
   * Le message d'erreur
   */
  private final MessageErreur message;

  /**
   * Constructeur
   * 
   * @param cleCodeErreur
   */
  public ExceptionTechnique(final EnumCleCodeErreur cleCodeErreur) {
    super(SpringContextFactory.springContextManager().getLibelles().getCodeFromCodeErreur(cleCodeErreur));
    message = new MessageErreur(cleCodeErreur);
  }

  /**
   * Constructeur
   *
   * @param cleCodeErreur
   * @param ex
   */
  public ExceptionTechnique(final EnumCleCodeErreur cleCodeErreur, final Throwable ex) {
    super(SpringContextFactory.springContextManager().getLibelles().getCodeFromCodeErreur(cleCodeErreur), ex);
    message = new MessageErreur(cleCodeErreur);
  }

  /**
   * @return Le message.
   */
  public MessageErreur getMessageErreur() {
    return message;
  }

  /**
   * Retourne le message détaillé de l'exception technique : ici la concaténation des différents champs du message
   * {@inheritDoc}
   */
  @Override
  public String getMessage() {
    return new StringBuffer(message.getCodeErreur()).append("|").append(message.getMessage()).append("|").append(message.getDescription()).toString();
  }

}
