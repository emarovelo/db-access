package fr.acoss.dorybackend.technique.enumeration;

/**
 * Énumération des types de Datasource (lecture / écriture)
 * Permet notamment de choisir la datasource
 */
public enum EnumTypeDataSource {
                             /**
                              * Datasource accessible en lecture / ecriture <br/>
                              * Permet d'accéder à la base postgresql Master
                              */
                             DATASOURCE_ECRITURE,

                             /**
                              * Datasource uniquement en lecture seule <br/>
                              * Permet d'accéder à la base postgresql répliquée
                              */
                             DATASOURCE_LECTURE_SEULE;

  /**
   * Charger le type d'une datasource.
   *
   * @param dataSource
   *          datasource.
   */
  private EnumTypeDataSource() {
  }

}
