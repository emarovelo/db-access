package fr.acoss.dorybackend.core.layer.metier.impl;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.acoss.dorybackend.core.layer.dao.SipDao;
import fr.acoss.dorybackend.core.layer.dao.StatutDocumentDao;
import fr.acoss.dorybackend.core.layer.dao.StatutSipDao;
import fr.acoss.dorybackend.core.mappeur.DocumentMappeur;
import fr.acoss.dorybackend.core.mappeur.SipMappeur;
import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.StatutDocument;
import fr.acoss.dorybackend.core.modele.persistance.StatutSip;
import fr.acoss.dorybackend.modele.dto.DocumentType;
import fr.acoss.dorybackend.modele.dto.SipType;


/**
 * Couche métier de gestion des sip
 */
@Service
public class SipMetierImpl implements fr.acoss.dorybackend.core.layer.metier.SipMetier {

  /** Injection du loggeur */
  private static final Logger LOGGER = LoggerFactory.getLogger(SipMetierImpl.class);

  /**
   * injection du dao Sip
   */
  @Resource
  private SipDao sipDao;

  /**
   * injection du dao StatutSipDao
   */
  @Resource
  private StatutSipDao statutSipDao;

  /**
   * injection du dao StatutSipDao
   */
  @Resource
  private StatutDocumentDao statutDocumentDao;

  /**
   * injection du mappeur DTO / Entity Document
   */
  @Autowired
  private DocumentMappeur documentMappeur;

  /**
   * injection du mappeur DTO / Entity Sip
   */
  @Autowired
  private SipMappeur sipMappeur;

  /**
   * {@inheritDoc}
   */
  @Override
  @Transactional
  public Optional<SipType> creerSip(final String nom, final String urlDepot, final List<DocumentType> lstDocumentType) {

    SipMetierImpl.LOGGER.info("Création d'un SIP avec les données suivantes:\n nom: " + nom + " url de dépôt: " + urlDepot);

    final Optional<StatutSip> statutSip = statutSipDao.findByCode("SIP_INIT");
    final Optional<StatutDocument> statutDocument = statutDocumentDao.findByCode("INTEGRE_SIP");

    if (statutSip.isPresent() && statutDocument.isPresent()) {

      final List<Document> lstDocument = documentMappeur.toDocument(lstDocumentType);
      return Optional.ofNullable(sipMappeur.toSipType(sipDao.creerSip(nom, urlDepot, lstDocument, statutSip.get(), statutDocument.get())));

    }

    return Optional.empty();

  }


}
