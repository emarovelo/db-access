package fr.acoss.dorybackend.core.layer.metier.composite;

import java.util.List;

/**
 * DTO contenant les informations de pagination
 */
public class PageType<T> {
	
	/** La liste des objets de cette page **/
	private List<T> contenu;
	
	/** le numéro de la page courante **/
	private int currentPage;
	
	/** Nombre d’éléments demandés **/
	private int size;

	/** le nombre total d'éléments disponibles **/
	private long numberOfElements;
	
	/** le nombre total de pages disponibles **/
	private int totalPages;

	/**
	 * @return les liste des éléments contenus dans la page
	 */
	public List<T> getContenu() {
		return contenu;
	}

	/**
	 * @param contenu
	 */
	public void setContenu(List<T> contenu) {
		this.contenu = contenu;
	}

	/**
	 * @return le numéro de la page courante
	 */
	public int getCurrentPage() {
		return currentPage;
	}

	/**
	 * @param currentPage
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	/**
	 * @return nombre d’éléments demandés
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @param size
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * @return le nombre total d'éléments disponibles
	 */
	public long getNumberOfElements() {
		return numberOfElements;
	}

	/**
	 * @param numberOfElements
	 */
	public void setNumberOfElements(long numberOfElements) {
		this.numberOfElements = numberOfElements;
	}

	/**
	 * @return le nombre total de pages disponibles
	 */
	public int getTotalPages() {
		return totalPages;
	}

	/**
	 * @param totalPages
	 */
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

}
