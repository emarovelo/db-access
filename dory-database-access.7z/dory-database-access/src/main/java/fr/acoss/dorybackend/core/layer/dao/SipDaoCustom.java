package fr.acoss.dorybackend.core.layer.dao;

import java.util.List;

import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.Sip;
import fr.acoss.dorybackend.core.modele.persistance.StatutDocument;
import fr.acoss.dorybackend.core.modele.persistance.StatutSip;

/**
 * Interface DAO de gestion des document
 */
public interface SipDaoCustom {

  /**
   * Création d'un nouveau sip
   * 
   * @param nom
   *          String
   * @param urlDepot
   *          String
   * @param lstDocument
   * @param statutInitSip
   * @param statutInitDocument
   * @return Sip
   */
  Sip creerSip(String nom, String urlDepot, List<Document> lstDocument, StatutSip statutInitSip, StatutDocument statutInitDocument);
}
