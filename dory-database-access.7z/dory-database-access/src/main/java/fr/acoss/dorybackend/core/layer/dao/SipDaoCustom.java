package fr.acoss.dorybackend.core.layer.dao;

import java.util.List;

import fr.acoss.dorybackend.core.modele.persistance.Document;
import fr.acoss.dorybackend.core.modele.persistance.Sip;

/**
 * Interface DAO de gestion des document
 */
public interface SipDaoCustom {

  Sip creerSip(String nom, String urlDepot, List<Document> lstDocument);
}
