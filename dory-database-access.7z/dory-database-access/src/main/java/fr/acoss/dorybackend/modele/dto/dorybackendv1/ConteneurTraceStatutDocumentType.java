package fr.acoss.dorybackend.modele.dto.dorybackendv1;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.validation.annotation.Validated;

/**
 * ConteneurTraceStatutDocumentType
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-10-22T14:28:09.484+02:00")

public class ConteneurTraceStatutDocumentType   {
  private List<TraceStatutDocumentType> listTraceStatutDocumentType = null;

  private String idArchivage = null;

  public ConteneurTraceStatutDocumentType listTraceStatutDocumentType(final List<TraceStatutDocumentType> listTraceStatutDocumentType) {
    this.listTraceStatutDocumentType = listTraceStatutDocumentType;
    return this;
  }

  public ConteneurTraceStatutDocumentType addListTraceStatutDocumentTypeItem(final TraceStatutDocumentType listTraceStatutDocumentTypeItem) {
    if (listTraceStatutDocumentType == null) {
      listTraceStatutDocumentType = new ArrayList<>();
    }
    listTraceStatutDocumentType.add(listTraceStatutDocumentTypeItem);
    return this;
  }

  /**
   * Historique des statuts du document
   * @return listTraceStatutDocumentType
  **/
  public List<TraceStatutDocumentType> getListTraceStatutDocumentType() {
    return listTraceStatutDocumentType;
  }

  public void setListTraceStatutDocumentType(final List<TraceStatutDocumentType> listTraceStatutDocumentType) {
    this.listTraceStatutDocumentType = listTraceStatutDocumentType;
  }

  public ConteneurTraceStatutDocumentType idArchivage(final String idArchivage) {
    this.idArchivage = idArchivage;
    return this;
  }

  /**
   * La date du changement de statut du document
   * @return idArchivage
  **/
  public String getIdArchivage() {
    return idArchivage;
  }

  public void setIdArchivage(final String idArchivage) {
    this.idArchivage = idArchivage;
  }


  @Override
  public boolean equals(final java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final ConteneurTraceStatutDocumentType conteneurTraceStatutDocumentType = (ConteneurTraceStatutDocumentType) o;
    return Objects.equals(listTraceStatutDocumentType, conteneurTraceStatutDocumentType.listTraceStatutDocumentType) &&
        Objects.equals(idArchivage, conteneurTraceStatutDocumentType.idArchivage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(listTraceStatutDocumentType, idArchivage);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    sb.append("class ConteneurTraceStatutDocumentType {\n");
    
    sb.append("    listTraceStatutDocumentType: ").append(toIndentedString(listTraceStatutDocumentType)).append("\n");
    sb.append("    idArchivage: ").append(toIndentedString(idArchivage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(final java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

