package fr.acoss.dorybackend.core.layer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.acoss.dorybackend.core.modele.persistance.Sip;

/**
 * Interface DAO de gestion de la table sip
 */
public interface SipDao extends JpaRepository<Sip, Long>, SipDaoCustom {

}
