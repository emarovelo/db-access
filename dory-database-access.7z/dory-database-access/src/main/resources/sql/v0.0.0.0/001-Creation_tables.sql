SET default_tablespace = '';

SET default_with_oids = false;

DROP TABLE IF EXISTS pgdorybackend.st_statut_document cascade;
DROP TABLE IF EXISTS pgdorybackend.st_statut_sip cascade;
DROP TABLE IF EXISTS pgdorybackend.st_statut_lot_versement cascade;
DROP TABLE IF EXISTS pgdorybackend.si_sip cascade;
DROP TABLE IF EXISTS pgdorybackend.lo_lot_versement cascade;
DROP TABLE IF EXISTS pgdorybackend.do_document cascade;
DROP TABLE IF EXISTS pgdorybackend.lo_log_document;
DROP TABLE IF EXISTS pgdorybackend.hi_historique_statut_document;
DROP TABLE IF EXISTS pgdorybackend.vitam_access_info_config;

--
-- TOC entry 204 (class 1259 OID 16414)
-- Name: st_statut_document; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.st_statut_document (
    id bigint NOT NULL,
    code character varying(128) COLLATE pg_catalog."default" NOT NULL,
    dt_maj timestamp without time zone,
    dt_creation timestamp without time zone NOT NULL
);


ALTER TABLE pgdorybackend.st_statut_document OWNER TO pgdorybackend;

--
-- TOC entry 203 (class 1259 OID 16412)
-- Name: st_statut_document_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.st_statut_document_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.st_statut_document_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2912 (class 0 OID 0)
-- Dependencies: 203
-- Name: st_statut_document_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.st_statut_document_id_seq OWNED BY pgdorybackend.st_statut_document.id;


--
-- TOC entry 200 (class 1259 OID 16398)
-- Name: st_statut_sip; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.st_statut_sip (
    id bigint NOT NULL,
    code character varying(128) COLLATE pg_catalog."default" NOT NULL,
    dt_maj timestamp without time zone,
    dt_creation timestamp without time zone NOT NULL
);


ALTER TABLE pgdorybackend.st_statut_sip OWNER TO pgdorybackend;

--
-- TOC entry 199 (class 1259 OID 16396)
-- Name: st_statut_sip_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.st_statut_sip_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.st_statut_sip_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2913 (class 0 OID 0)
-- Dependencies: 199
-- Name: st_statut_sip_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.st_statut_sip_id_seq OWNED BY pgdorybackend.st_statut_sip.id;

--
-- TOC entry 200 (class 1259 OID 16398)
-- Name: st_statut_lot_versement; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.st_statut_lot_versement (
    id bigint NOT NULL,
    code character varying(128) COLLATE pg_catalog."default" NOT NULL,
    dt_maj timestamp without time zone,
    dt_creation timestamp without time zone NOT NULL
);


ALTER TABLE pgdorybackend.st_statut_lot_versement OWNER TO pgdorybackend;

--
-- TOC entry 199 (class 1259 OID 16396)
-- Name: st_statut_lot_versement_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.st_statut_lot_versement_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.st_statut_lot_versement_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2913 (class 0 OID 0)
-- Dependencies: 199
-- Name: st_statut_lot_versement_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.st_statut_lot_versement_id_seq OWNED BY pgdorybackend.st_statut_lot_versement.id;


--
-- TOC entry 198 (class 1259 OID 16390)
-- Name: si_sip; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.si_sip (
    id bigint NOT NULL,
    nom character varying(255) COLLATE pg_catalog."default" NOT NULL,
    url_depot character varying(255) COLLATE pg_catalog."default" NOT NULL,
    id_request character varying(255) COLLATE pg_catalog."default" ,
    id_statut_sip bigint NOT NULL,
    id_lot_versement bigint,
    dt_creation timestamp without time zone,
    dt_maj timestamp without time zone
);


ALTER TABLE pgdorybackend.si_sip OWNER TO pgdorybackend;

--
-- TOC entry 197 (class 1259 OID 16388)
-- Name: si_sip_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.si_sip_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.si_sip_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2914 (class 0 OID 0)
-- Dependencies: 197
-- Name: si_sip_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.si_sip_id_seq OWNED BY pgdorybackend.si_sip.id;





--
-- TOC entry 198 (class 1259 OID 16390)
-- Name: lo_lot_versement; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.lo_lot_versement (
    id bigint NOT NULL,
    nom character varying(255) COLLATE pg_catalog."default" NOT NULL,
    url_depot character varying(255) COLLATE pg_catalog."default" NOT NULL,
    code_statut_lot_versement character varying(128) COLLATE pg_catalog."default" NOT NULL,
    dt_creation timestamp without time zone,
    dt_maj timestamp without time zone
);


ALTER TABLE pgdorybackend.lo_lot_versement OWNER TO pgdorybackend;

--
-- TOC entry 197 (class 1259 OID 16388)
-- Name: lo_lot_versement_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.lo_lot_versement_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.lo_lot_versement_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2914 (class 0 OID 0)
-- Dependencies: 197
-- Name: lo_lot_versement_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.lo_lot_versement_id_seq OWNED BY pgdorybackend.lo_lot_versement.id;


--
-- TOC entry 202 (class 1259 OID 16406)
-- Name: do_document; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.do_document (
    id bigint NOT NULL,
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    contrat_service character varying(255) COLLATE pg_catalog."default",
    application_versante character varying(255) COLLATE pg_catalog."default",
    dt_maj timestamp without time zone,
    dt_creation timestamp without time zone NOT NULL,
    path_metadonnees character varying(255) COLLATE pg_catalog."default",
    path_document character varying(255) COLLATE pg_catalog."default",
	code_statut_document character varying(128) COLLATE pg_catalog."default" NOT NULL,
    metadonnees_document text COLLATE pg_catalog."default",
    hash_scelle text COLLATE pg_catalog."default",
    hash_non_scelle text COLLATE pg_catalog."default",
    bloc_horodate text COLLATE pg_catalog."default",
    cle_public_certificat text COLLATE pg_catalog."default",
    id_sip bigint,
    id_lot_versement bigint
);


ALTER TABLE pgdorybackend.do_document OWNER TO pgdorybackend;

--
-- TOC entry 201 (class 1259 OID 16404)
-- Name: do_document_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.do_document_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.do_document_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2915 (class 0 OID 0)
-- Dependencies: 201
-- Name: do_document_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.do_document_id_seq OWNED BY pgdorybackend.do_document.id;

--
-- TOC entry 202 (class 1259 OID 16406)
-- Name: lo_log_document; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.lo_log_document (
    id bigint NOT NULL,
    message text COLLATE pg_catalog."default" NOT NULL,
    id_document bigint NOT NULL,
    dt_maj timestamp without time zone,
    dt_creation timestamp without time zone NOT NULL
);


ALTER TABLE pgdorybackend.lo_log_document OWNER TO pgdorybackend;

--
-- TOC entry 201 (class 1259 OID 16404)
-- Name: lo_log_document_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.lo_log_document_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.lo_log_document_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2915 (class 0 OID 0)
-- Dependencies: 201
-- Name: lo_log_document_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.lo_log_document_id_seq OWNED BY pgdorybackend.lo_log_document.id;

--
-- TOC entry 202 (class 1259 OID 16406)
-- Name: hi_historique_statut_document; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.hi_historique_statut_document (
    id bigint NOT NULL,
    code_statut text COLLATE pg_catalog."default" NOT NULL,
    message text COLLATE pg_catalog."default" NOT NULL,
    id_document bigint NOT NULL,
    dt_maj timestamp without time zone,
    dt_creation timestamp without time zone NOT NULL
);


ALTER TABLE pgdorybackend.hi_historique_statut_document OWNER TO pgdorybackend;

--
-- TOC entry 201 (class 1259 OID 16404)
-- Name: hi_historique_statut_document_id_seq_name; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.hi_historique_statut_document_id_seq_name
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.hi_historique_statut_document_id_seq_name OWNER TO pgdorybackend;

--
-- TOC entry 2915 (class 0 OID 0)
-- Dependencies: 201
-- Name: hi_historique_statut_document_id_seq_name; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.hi_historique_statut_document_id_seq_name OWNED BY pgdorybackend.hi_historique_statut_document.id;

--
-- TOC entry 202 (class 1259 OID 16406)
-- Name: vitam_access_info_config; Type: TABLE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE TABLE pgdorybackend.vitam_access_info_config (
    id bigint NOT NULL,
    code character varying(255) COLLATE pg_catalog."default" NOT NULL,
    ssl_client_cert text COLLATE pg_catalog."default",
    tenant_id character varying(255) COLLATE pg_catalog."default",
    application_id character varying(255) COLLATE pg_catalog."default",
    context_id character varying(255) COLLATE pg_catalog."default",
    access_contract_id character varying(255) COLLATE pg_catalog."default",
    dt_maj timestamp without time zone,
    dt_creation timestamp without time zone NOT NULL
);


ALTER TABLE pgdorybackend.vitam_access_info_config OWNER TO pgdorybackend;

--
-- TOC entry 201 (class 1259 OID 16404)
-- Name: vitam_access_info_config_id_seq; Type: SEQUENCE; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE SEQUENCE pgdorybackend.vitam_access_info_config_id_seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    NO MAXVALUE
    CACHE 1
    NO CYCLE;


ALTER TABLE pgdorybackend.vitam_access_info_config_id_seq OWNER TO pgdorybackend;

--
-- TOC entry 2915 (class 0 OID 0)
-- Dependencies: 201
-- Name: vitam_access_info_config_id_seq; Type: SEQUENCE OWNED BY; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER SEQUENCE pgdorybackend.vitam_access_info_config_id_seq OWNED BY pgdorybackend.vitam_access_info_config.id;


--
-- TOC entry 2762 (class 2604 OID 16417)
-- Name: st_statut_document id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_document ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.st_statut_document_id_seq'::regclass);


--
-- TOC entry 2760 (class 2604 OID 16401)
-- Name: st_statut_sip id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_sip ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.st_statut_sip_id_seq'::regclass);



--
-- TOC entry 2760 (class 2604 OID 16401)
-- Name: st_statut_lot_versement id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_lot_versement ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.st_statut_lot_versement_id_seq'::regclass);

--
-- TOC entry 2759 (class 2604 OID 16393)
-- Name: si_sip id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.si_sip ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.si_sip_id_seq'::regclass);


--
-- TOC entry 2759 (class 2604 OID 16393)
-- Name: lo_lot_versement id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.lo_lot_versement ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.lo_lot_versement_id_seq'::regclass);

--
-- TOC entry 2761 (class 2604 OID 16409)
-- Name: do_document id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.do_document ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.do_document_id_seq'::regclass);


--
-- TOC entry 2761 (class 2604 OID 16409)
-- Name: lo_log_document id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.lo_log_document ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.lo_log_document_id_seq'::regclass);


--
-- TOC entry 2761 (class 2604 OID 16409)
-- Name: hi_historique_statut_document id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.hi_historique_statut_document ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.hi_historique_statut_document_id_seq_name'::regclass);


--
-- TOC entry 2761 (class 2604 OID 16409)
-- Name: vitam_access_info_config id; Type: DEFAULT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.vitam_access_info_config ALTER COLUMN id SET DEFAULT nextval('pgdorybackend.vitam_access_info_config_id_seq'::regclass);


--
-- TOC entry 2772 (class 2606 OID 16419)
-- Name: st_statut_document pk_st_statut_document; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_document
    ADD CONSTRAINT pk_st_statut_document PRIMARY KEY (id);

--
-- TOC entry 2766 (class 2606 OID 16403)
-- Name: st_statut_sip pk_st_statut_sip; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_sip
    ADD CONSTRAINT pk_st_statut_sip PRIMARY KEY (id);

    
--
-- TOC entry 2766 (class 2606 OID 16403)
-- Name: st_statut_lot_versement pk_st_statut_lot_versement; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_lot_versement
    ADD CONSTRAINT pk_st_statut_lot_versement PRIMARY KEY (id);
      

--
-- TOC entry 2764 (class 2606 OID 16395)
-- Name: si_sip pk_si_sip; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.si_sip
    ADD CONSTRAINT pk_si_sip PRIMARY KEY (id);
    
--
-- TOC entry 2764 (class 2606 OID 16395)
-- Name: si_sip pk_si_sip; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.lo_lot_versement
    ADD CONSTRAINT pk_lot_vesrement PRIMARY KEY (id);


--
-- TOC entry 2768 (class 2606 OID 16411)
-- Name: do_document pk_do_document; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.do_document
    ADD CONSTRAINT pk_do_document PRIMARY KEY (id);


--
-- TOC entry 2768 (class 2606 OID 16411)
-- Name: lo_log_document pk_lo_log_document; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.lo_log_document
    ADD CONSTRAINT pk_lo_log_document PRIMARY KEY (id);
    
    
--
-- TOC entry 2768 (class 2606 OID 16411)
-- Name: hi_historique_statut_document pk_hi_historique_statut_document; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.hi_historique_statut_document
    ADD CONSTRAINT pk_hi_historique_statut_document PRIMARY KEY (id);
    
    
--
-- TOC entry 2768 (class 2606 OID 16411)
-- Name: vitam_access_info_config pk_vitam_access_info_config; Type: CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.vitam_access_info_config
    ADD CONSTRAINT pk_vitam_access_info_config PRIMARY KEY (id);
    
    
--
-- TOC entry 2770 (class 1259 OID 16420)
-- Name: idx_si_sip_on_id_st_statut_sip; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_si_sip_on_id_st_statut_sip ON pgdorybackend.si_sip USING btree (id_statut_sip);


--
-- TOC entry 2769 (class 1259 OID 16421)
-- Name: idx_si_sip_on_id_lo_lot_versement; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_si_sip_on_id_lo_lot_versement ON pgdorybackend.si_sip USING btree (id_lot_versement);

--
-- TOC entry 2769 (class 1259 OID 16421)
-- Name: idx_do_document_on_code_statut_do_document; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_do_document_on_code_statut_do_document ON pgdorybackend.do_document USING btree (code_statut_document);


--
-- TOC entry 2769 (class 1259 OID 16421)
-- Name: idx_do_document_on_id_si_sip; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_do_document_on_id_si_sip ON pgdorybackend.do_document USING btree (id_sip);


--
-- TOC entry 2769 (class 1259 OID 16421)
-- Name: idx_do_document_on_id_lo_lot_versement; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_do_document_on_id_lo_lot_versement ON pgdorybackend.do_document USING btree (id_lot_versement);

--
-- TOC entry 2769 (class 1259 OID 16421)
-- Name: idx_lo_lot_versement_on_code_statut_lo_lot_versement; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_lo_lot_versement_on_code_statut_lo_lot_versement ON pgdorybackend.lo_lot_versement USING btree (code_statut_lot_versement);


--
-- TOC entry 2769 (class 1259 OID 16421)
-- Name: idx_lo_log_document_on_id_document; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_lo_log_document_on_id_document ON pgdorybackend.lo_log_document USING btree (id_document);


--
-- TOC entry 2769 (class 1259 OID 16421)
-- Name: idx_lo_log_document_on_id_document; Type: INDEX; Schema: pgdorybackend; Owner: pgdorybackend
--

CREATE INDEX idx_hi_historique_statut_document_on_id_document ON pgdorybackend.hi_historique_statut_document USING btree (id_document);


--
-- TOC entry 2774 (class 2606 OID 16427)
-- Name: st_statut_document uk_to_code; Type: UNIQUE; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_document
    ADD CONSTRAINT uk_st_statut_document_to_code UNIQUE (code);
    
--
-- TOC entry 2774 (class 2606 OID 16427)
-- Name: st_statut_sip uk_to_code; Type: UNIQUE; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_sip
    ADD CONSTRAINT uk_st_statut_sip_to_code UNIQUE (code);


--
-- TOC entry 2774 (class 2606 OID 16427)
-- Name: do_document uk_to_uuid; Type: UNIQUE; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.do_document
    ADD CONSTRAINT uk_to_uuid UNIQUE (uuid);
    
--
-- TOC entry 2774 (class 2606 OID 16427)
-- Name: st_statut_lot_versement uk_to_code; Type: UNIQUE; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.st_statut_lot_versement
    ADD CONSTRAINT uk_st_statut_lot_versement_to_code UNIQUE (code);

--
-- TOC entry 2774 (class 2606 OID 16427)
-- Name: si_sip fk_si_sip_to_st_statut_sip; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.si_sip
    ADD CONSTRAINT fk_si_sip_to_st_statut_sip FOREIGN KEY (id_statut_sip) REFERENCES pgdorybackend.st_statut_sip(id);

--
-- TOC entry 2773 (class 2606 OID 16422)
-- Name: si_sip fk_si_sip_to_lo_lot_versement; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.si_sip
    ADD CONSTRAINT fk_si_sip_to_lo_lot_versement FOREIGN KEY (id_lot_versement) REFERENCES pgdorybackend.lo_lot_versement(id);
    
--
-- TOC entry 2773 (class 2606 OID 16422)
-- Name: do_document fk_do_document_to_statut_do_document; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.do_document
    ADD CONSTRAINT fk_do_document_to_statut_do_document FOREIGN KEY (code_statut_document) REFERENCES pgdorybackend.st_statut_document(code);
    
    
--
-- TOC entry 2773 (class 2606 OID 16422)
-- Name: do_document fk_do_document_to_si_sip; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.do_document
    ADD CONSTRAINT fk_do_document_to_si_sip FOREIGN KEY (id_sip) REFERENCES pgdorybackend.si_sip(id);


--
-- TOC entry 2773 (class 2606 OID 16422)
-- Name: do_document fk_do_document_to_lo_lot_versement; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.do_document
    ADD CONSTRAINT fk_do_document_to_lo_lot_versement FOREIGN KEY (id_lot_versement) REFERENCES pgdorybackend.lo_lot_versement(id);
    
--
-- TOC entry 2773 (class 2606 OID 16422)
-- Name: lo_lot_versement fk_lo_lot_versement_to_st_statut_lot_versement; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.lo_lot_versement
    ADD CONSTRAINT fk_lo_lot_versement_to_st_statut_lot_versement FOREIGN KEY (code_statut_lot_versement) REFERENCES pgdorybackend.st_statut_lot_versement(code);
    
    
--
-- TOC entry 2773 (class 2606 OID 16422)
-- Name: lo_log_document fk_lo_log_document_to_document; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.lo_log_document
    ADD CONSTRAINT fk_lo_log_document_to_do_document FOREIGN KEY (id_document) REFERENCES pgdorybackend.do_document(id);

    
    
--
-- TOC entry 2773 (class 2606 OID 16422)
-- Name: hi_historique_statut_document fk_hi_historique_statut_document_to_document; Type: FK CONSTRAINT; Schema: pgdorybackend; Owner: pgdorybackend
--

ALTER TABLE ONLY pgdorybackend.hi_historique_statut_document
    ADD CONSTRAINT fk_hi_historique_statut_document_to_do_document FOREIGN KEY (id_document) REFERENCES pgdorybackend.do_document(id);   
 
--
-- TOC entry 2911 (class 0 OID 0)
-- Dependencies: 7
-- Name: SCHEMA pgdorybackend; Type: ACL; Schema: -; Owner: pgdorybackend
--

GRANT ALL ON SCHEMA pgdorybackend TO postgres;


-- Completed on 2019-08-05 14:25:55

--
-- PostgreSQL database dump complete
--


--
-- 
-- st_statut_document
--
--
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('INIT_DEPOT', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('DEPOSE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('SCELLE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('HORODATE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('INTEGRATION_SIP_EN_COURS', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('INTEGRE_SIP', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('ARCHIVE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('ERREUR', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_document(
	code, dt_maj, dt_creation)
	VALUES ('RND_ERREUR', NOW(), NOW());

--
-- 
-- st_statut_sip
--
--
INSERT INTO pgdorybackend.st_statut_sip(
	code, dt_maj, dt_creation)
	VALUES ('SIP_INIT', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_sip(
	code, dt_maj, dt_creation)
	VALUES ('EN_COURS_VERSEMENT', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_sip(
	code, dt_maj, dt_creation)
	VALUES ('SIP_A_VERSE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_sip(
	code, dt_maj, dt_creation)
	VALUES ('ERREUR_VERSEMENT', NOW(), NOW());

--
-- 
-- st_statut_lot_versement
--
--
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('INIT_DEPOT', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('DEPOSE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('SCELLE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('HORODATE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('CREATION_SIP', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('INTEGRE_SIP', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('ARCHIVE', NOW(), NOW());
INSERT INTO pgdorybackend.st_statut_lot_versement(
	code, dt_maj, dt_creation)
	VALUES ('ERREUR', NOW(), NOW());
